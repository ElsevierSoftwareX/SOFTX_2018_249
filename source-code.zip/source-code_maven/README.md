AgDataBox-API

It's necessary:

Production environment:
 -Java 8
 -Apache Tomcat 9
 -PostgreSQL 8
 -Postgis

Build:
 -Java 8
 -Apache Maven 3.5
 