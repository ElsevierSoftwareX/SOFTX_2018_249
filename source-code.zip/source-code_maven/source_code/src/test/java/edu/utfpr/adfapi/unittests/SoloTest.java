package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Solo;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class SoloTest {
    
    public SoloTest() {
    }
    
   public Solo criaSoloWithToken(){
        Solo a = new Solo();
        a.setDescricaoPT("JUnit Solo");
        
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/solo",a);
        
        Solo aux = extract.body().as(Solo.class);
        a.setCodigo(aux.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return a;
    }
    
    @Test
    public void criaSoloWithoutToken(){
        Solo a = new Solo();
        a.setDescricaoPT("JUnit Solo");
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/solo",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateSoloWithoutToken(Solo a){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/solo",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateSoloWithToken(Solo a){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/solo",a);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    public void removeSoloWithToken(Solo a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/solo/"+a.getCodigo());
        System.out.println(extract.body().asString());
        Assert.assertTrue(extract.statusCode()==200);
    }
    public void removeSoloWithoutToken(Solo a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/solo/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void CRUDWithToken(){
        Solo a = criaSoloWithToken();
        updateSoloWithToken(a);
        removeSoloWithToken(a);
    }
    
    @Test
    public void CRUDWithoutToken(){
        Solo a = criaSoloWithToken(); //Just to have something to try to update
        
        criaSoloWithoutToken();
        updateSoloWithoutToken(a);
        removeSoloWithoutToken(a);
        
        //Dont let trash in the DB
        removeSoloWithToken(a);
    }
    
    
    @Test
    public void getAllSolosWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/solo");
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    @Test
    public void getAllSolosWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/solo");
        Assert.assertTrue(extract.statusCode()==200);
    }

}
