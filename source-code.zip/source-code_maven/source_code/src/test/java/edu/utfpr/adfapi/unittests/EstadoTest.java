package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Ignore;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class EstadoTest {
    
    private static final int PAIS_ID = 1;
    
    public EstadoTest() {
    }
   
    @Test
    public void getEstadoWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/estado/"+PAIS_ID);
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    @Test
    public void getEstadoWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/estado/"+PAIS_ID);
        Assert.assertTrue(extract.statusCode()==200);
    }

}
