package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Ignore;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class PaisTest {
    
    public PaisTest() {
    }
    
    @Test
    public void getAllPaisesWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/pais");
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    @Test
    public void getAllPaisesWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/pais");
        Assert.assertTrue(extract.statusCode()==200);
    }
    
}
