package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.ObjectMapperConfig;
import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.mapper.factory.GsonObjectMapperFactory;
import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;

/**
 *
 * @author Rodrigo
 */
public class APIConfig {

    public static final String TEST_TOKEN = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJUZXN0YW5kbyJ9.ni6f7e5trPMzbny4nWCbPYbrEQT1HD3tD8Yekn4yO1nuNAa6GdrRhDZ2ojDM9YIQa0msoUgUTJ-GaY3ouAaW8Q";

    public static ExtractableResponse<Response> getWithoutToken(String url) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json")
                .when().get(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> postWithoutToken(String url, Object body) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").body(body)
                .when().post(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> putWithoutToken(String url, Object body) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").body(body)
                .when().put(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> deleteWithoutToken(String url) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json")
                .when().delete(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> getWithToken(String url) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").header("Authorization", TEST_TOKEN)
                .when().get(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> postWithToken(String url, Object body) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").header("Authorization", TEST_TOKEN).body(body)
                .when().post(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> putWithToken(String url, Object body) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").header("Authorization", TEST_TOKEN).body(body)
                .when().put(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static ExtractableResponse<Response> deleteWithToken(String url) {
        return RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json").header("Authorization", TEST_TOKEN)
                .when().delete(edu.utfpr.adfapi.config.CONFIG.BASE_URL + url)
                .then()
                .extract();
    }

    public static void init(){
        RestAssured.config = RestAssuredConfig.config().objectMapperConfig(new ObjectMapperConfig().gsonObjectMapperFactory(
                new GsonObjectMapperFactory() {

                    @Override
                    public Gson create(Class type, String string) {
                        return new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").create();
                    }
                }
        ));
    }
    
    public APIConfig() {
    }

}
