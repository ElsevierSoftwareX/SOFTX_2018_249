package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Atributo;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class AtributoTest {
    
    public AtributoTest() {
    }
    
    public Atributo criaAtributoWithToken() {
        Atributo a = new Atributo();
        a.setDescricaoPT("JUnit Atributo");
        a.setSiglaPT("JUnit");
        //a.setUnidadeMedidaPT("Erros");
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/atributo", a);

        Atributo aux = extract.body().as(Atributo.class);
        a.setCodigo(aux.getCodigo());

        Assert.assertTrue(extract.statusCode() == 200);

        return a;
    }

    @Test
    public void criaAtributoWithoutToken() {
        Atributo a = new Atributo();
        a.setDescricaoPT("JUnit Atributo");
        a.setSiglaPT("JUnit");
        //a.setUnidadeDeMedida("Erros");
        
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/atributo", a);
        Assert.assertTrue(extract.statusCode() == 401);
    }

    public void updateAtributoWithoutToken(Atributo a) {
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/atributo", a);
        Assert.assertTrue(extract.statusCode() == 401);
    }

    public void updateAtributoWithToken(Atributo a) {
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/atributo", a);
        Assert.assertTrue(extract.statusCode() == 200);
    }

    public void removeAtributoWithToken(Atributo a) {
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/atributo/" + a.getCodigo());
        System.out.println(extract.body().asString());
        Assert.assertTrue(extract.statusCode() == 200);
    }

    public void removeAtributoWithoutToken(Atributo a) {
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/atributo/" + a.getCodigo());
        Assert.assertTrue(extract.statusCode() == 401);
    }

    @Test
    public void CRUDWithToken() {
        Atributo a = criaAtributoWithToken();
        updateAtributoWithToken(a);
        removeAtributoWithToken(a);
    }

    @Test
    public void CRUDWithoutToken() {
        Atributo a = criaAtributoWithToken(); //Just to have something to try to update

        criaAtributoWithoutToken();
        updateAtributoWithoutToken(a);
        removeAtributoWithoutToken(a);

        //Dont let trash in the DB
        removeAtributoWithToken(a);
    }

    @Test
    public void getAllAtributosWithoutToken() {
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/atributo");
        Assert.assertTrue(extract.statusCode() == 401);
    }

    @Test
    public void getAllAtributosWithToken() {
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/atributo");
        Assert.assertTrue(extract.statusCode() == 200);
    }
}
