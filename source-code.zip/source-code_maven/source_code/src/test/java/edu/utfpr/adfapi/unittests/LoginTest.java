package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Usuario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    public Usuario criaUsuario(){        
        Usuario usuario = new Usuario();
        usuario.setNome("JUnit Test");
        usuario.setEmail("AplLoginJUnitTest@AplLoginJUnitTest.com");
        usuario.setSenha("1234");
        
        ExtractableResponse<Response> extract = RestAssured.given().contentType(ContentType.JSON).header("Accept","application/json").body(usuario)
                //.expect().statusCode(200)//FUNCIONA
                .when().post("http://localhost:8080/SDUM/api/usuario")
                .then()
                .extract();
        
        Usuario aux = extract.body().as(Usuario.class);
        usuario.setCodigo(aux.getCodigo());
        //usuario.setToken(aux.getToken());
        
        System.out.println("USUARIO: "+ usuario.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return usuario;
    }
    
    public void deleteUsuarioWithToken(Usuario usuario){
        ExtractableResponse<Response> extract = RestAssured.given().contentType(ContentType.JSON).header("Accept","application/json").header("Authorization","eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJUZXN0YW5kbyJ9.ni6f7e5trPMzbny4nWCbPYbrEQT1HD3tD8Yekn4yO1nuNAa6GdrRhDZ2ojDM9YIQa0msoUgUTJ-GaY3ouAaW8Q")
                //.expect().statusCode(200)//FUNCIONA
                .when().delete("http://localhost:8080/SDUM/api/usuario/"+usuario.getCodigo())
                .then()
                .extract();
        
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    @Test
    public void login(){
        Usuario u = criaUsuario();
        
        ExtractableResponse<Response> extract = RestAssured.given().contentType(ContentType.JSON).header("Accept","application/json")
                .body("{ \"email\": \""+u.getEmail()+"\", \"password\": \""+u.getSenha()+"\"}")
                //.expect().statusCode(200)//FUNCIONA
                .when().post("http://localhost:8080/SDUM/api/login")
                .then()
                .extract();
        
        Assert.assertTrue(extract.statusCode()==200);
        
        deleteUsuarioWithToken(u);
    } 
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
