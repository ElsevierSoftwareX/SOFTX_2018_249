package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Usuario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */

@Ignore
public class UsuarioTest {
    
   
    public UsuarioTest() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    public Usuario criaUsuario(){        
        Usuario usuario = new Usuario();
        usuario.setNome("JUnit Test");
        usuario.setEmail("teste@teste.com");
        usuario.setSenha("1234");
        
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/usuario", usuario);
        
        usuario.setCodigo(extract.body().as(Usuario.class).getCodigo());
        System.out.println("USUARIO: "+ usuario.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return usuario;
    }
    
    @Test
    public void getAllUsuariosWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/usuario");
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void getAllUsuariosWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/usuario");
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    @Test
    public void getUsuarioWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/usuario/1");
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void getUsuarioWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/usuario/1");
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    
    public void updateUsuarioWithoutToken(Usuario usuario){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/usuario",usuario);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    
    public void updateUsuarioWithToken(Usuario usuario){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/usuario",usuario);
        Assert.assertTrue(extract.statusCode()==200);
        
        usuario = extract.body().as(Usuario.class);
    }
    
    
    
    public void deleteUsuarioWithoutToken(Usuario usuario){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/usuario/"+usuario.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    
    public void deleteUsuarioWithToken(Usuario usuario){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/usuario/"+usuario.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    
    @Test
    public void createUpdateDeleteWithoutToken(){
        Usuario usuario = criaUsuario();
        updateUsuarioWithoutToken(usuario);
//        deleteUsuarioWithoutToken(usuario);
        
        // Just to don't let trash in the DataBase
        deleteUsuarioWithToken(usuario);
    }
    
    @Test
    public void createUpdateDeleteWithToken(){
        Usuario usuario = criaUsuario();
        updateUsuarioWithToken(usuario);
        deleteUsuarioWithToken(usuario);
    }
    
}
