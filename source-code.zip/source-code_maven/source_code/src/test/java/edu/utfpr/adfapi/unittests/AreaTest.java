package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Area;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class AreaTest {
    
    public AreaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    
    public Area criaAreaWithToken(){
        Area a = new Area();
        a.setDescricao("Area JUnit Test");
        
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/area",a);
        
        Area aux = extract.body().as(Area.class);
        a.setCodigo(aux.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return a;
    }
    
    @Test
    public void criaAreaWithoutToken(){
        Area a = new Area();
        a.setDescricao("Area JUnit Test");
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/area",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateAreaWithoutToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/area",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateAreaWithToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/area",a);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    public void removeAreaWithToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/area/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
    public void removeAreaWithoutToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/area/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void CRUDWithToken(){
        Area a = criaAreaWithToken();
        getAreaWithToken(a);
        updateAreaWithToken(a);
        removeAreaWithToken(a);
        
        
        
    }
    
    @Test
    public void CRUDWithoutToken(){
        Area a = criaAreaWithToken(); //Just to have something to try to update
        
        criaAreaWithoutToken();
        getAllAreasWithoutToken();
        updateAreaWithoutToken(a);
        removeAreaWithoutToken(a);
        
        //Dont let trash in the DB
        removeAreaWithToken(a);
    }
    
    
    @Test
    public void getAllAreasWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/area");
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    @Test
    public void getAllAreasWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/area");
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    
    public void getAreaWithoutToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/area/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    
    public void getAreaWithToken(Area a){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/area/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
