package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.Mapa;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class GradeTest {
    
    public GradeTest() {
    }
    
   public Mapa criaGradeWithToken(){
        Mapa a = new Mapa();
        a.setDescricao("JUnit Descricao");
//        a.setData(Date.from(Instant.now()));
        //a.setNomeDaTabela("JUnit Test");
        a.setTamanhoX(1);
        a.setTamanhoY(2);
        a.setTipoGeometria("JUnit");
        a.setTipoInterpolador("JUnit Interpolador");
        a.setExpoente(1);
        a.setRaio(1);
        a.setNumeroPontos(2);
        
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/grade",a);
        
        Mapa aux = extract.body().as(Mapa.class);
        a.setCodigo(aux.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return a;
    }
    
    @Test
    public void criaGradeWithoutToken(){
        Mapa a = new Mapa();
        a.setDescricao("JUnit Descricao");
//        a.setData(Date.from(Instant.now()));
        //a.setNomeDaTabela("JUnit Test");
       a.setTamanhoX(1);
        a.setTamanhoY(2);
        a.setTipoGeometria("JUnit");
        a.setTipoInterpolador("JUnit Interpolador");
        a.setExpoente(1);
        a.setRaio(1);
        a.setNumeroPontos(2);
        
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/grade",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateGradeWithoutToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/grade",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateGradeWithToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/grade",a);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    public void removeGradeWithToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/grade/"+a.getCodigo());
        System.out.println(extract.body().asString());
        Assert.assertTrue(extract.statusCode()==200);
    }
    public void removeGradeWithoutToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/grade/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void CRUDWithToken(){
        Mapa a = criaGradeWithToken();
        getGradeWithToken(a);
        updateGradeWithToken(a);
        removeGradeWithToken(a);
    }
    
    @Test
    public void CRUDWithoutToken(){
        Mapa a = criaGradeWithToken(); //Just to have something to try to update
        
        criaGradeWithoutToken();
        getGradeWithoutToken(a);
        updateGradeWithoutToken(a);
        removeGradeWithoutToken(a);
        
        //Dont let trash in the DB
        removeGradeWithToken(a);
    }
    
    
    
    public void getGradeWithoutToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/grade/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    
    public void getGradeWithToken(Mapa a){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/grade/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
}
