package edu.utfpr.adfapi.unittests;


import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.ZonaManejo;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rodrigo
 */
@Ignore
public class ZonaDeManejoTest {
    
    public ZonaDeManejoTest() {
    }
    
    public ZonaManejo criaZonaDeManejoWithToken(){
        ZonaManejo a = new ZonaManejo();
        a.setDescricao("JUnit Descricao");
//        a.setData(Date.from(Instant.now()));
        a.setNomeTabela("JUnit Test");
        a.setNumeroClasses(1);
        a.setMetodo("JUnit");
        
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/zonamanejo",a);
        
        ZonaManejo aux = extract.body().as(ZonaManejo.class);
        a.setCodigo(aux.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return a;
    }
    
    @Test
    public void criaZonaDeManejoWithoutToken(){
                ZonaManejo a = new ZonaManejo();
        a.setDescricao("JUnit Descricao");
//        a.setData(Date.from(Instant.now()));
        a.setNomeTabela("JUnit Test");
        a.setNumeroClasses(1);
        a.setMetodo("JUnit");
        
        
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/zonamanejo",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateZonaDeManejoWithoutToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/zonamanejo",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateZonaDeManejoWithToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/zonamanejo",a);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    public void removeZonaDeManejoWithToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/zonamanejo/"+a.getCodigo());
        System.out.println(extract.body().asString());
        Assert.assertTrue(extract.statusCode()==200);
    }
    public void removeZonaDeManejoWithoutToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/zonamanejo/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void CRUDWithToken(){
        ZonaManejo a = criaZonaDeManejoWithToken();
        getZonaDeManejoWithToken(a);
        updateZonaDeManejoWithToken(a);
        removeZonaDeManejoWithToken(a);
    }
    
    @Test
    public void CRUDWithoutToken(){
        ZonaManejo a = criaZonaDeManejoWithToken(); //Just to have something to try to update
        
        criaZonaDeManejoWithoutToken();
        getZonaDeManejoWithoutToken(a);
        updateZonaDeManejoWithoutToken(a);
        removeZonaDeManejoWithoutToken(a);
        
        //Dont let trash in the DB
        removeZonaDeManejoWithToken(a);
    }
    
    
    
    public void getZonaDeManejoWithoutToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/zonamanejo/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    
    public void getZonaDeManejoWithToken(ZonaManejo a){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/zonamanejo/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
    
}
