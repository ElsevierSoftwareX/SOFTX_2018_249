package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import edu.utfpr.adfapi.model.GradeAmostral;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class GradeAmostralTest {
    
    public GradeAmostralTest() {
    }
    
    public GradeAmostral criaGradeAmostralWithToken(){
        GradeAmostral a = new GradeAmostral();
        a.setDescricao("JUnit Test");
        a.setTamx(1);
        a.setTamy(2); 
        
        ExtractableResponse<Response> extract = APIConfig.postWithToken("api/gradeamostral",a);
        
        GradeAmostral aux = extract.body().as(GradeAmostral.class);
        a.setCodigo(aux.getCodigo());
        
        Assert.assertTrue(extract.statusCode()==200);
        
        return a;
    }
    
    @Test
    public void criaGradeAmostralWithoutToken(){
        GradeAmostral a = new GradeAmostral();
        a.setDescricao("JUnit Test");
        a.setTamx(1);
        a.setTamy(2);
        
        
        ExtractableResponse<Response> extract = APIConfig.postWithoutToken("api/gradeamostral",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateGradeAmostralWithoutToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.putWithoutToken("api/gradeamostral",a);
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    public void updateGradeAmostralWithToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.putWithToken("api/gradeamostral",a);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    public void removeGradeAmostralWithToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithToken("api/gradeamostral/"+a.getCodigo());
        System.out.println(extract.body().asString());
        Assert.assertTrue(extract.statusCode()==200);
    }
    public void removeGradeAmostralWithoutToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.deleteWithoutToken("api/gradeamostral/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);
    }
    
    @Test
    public void CRUDWithToken(){
        GradeAmostral a = criaGradeAmostralWithToken();
        getGradeAmostralWithToken(a);
        updateGradeAmostralWithToken(a);
        removeGradeAmostralWithToken(a);
    }
    
    @Test
    public void CRUDWithoutToken(){
        GradeAmostral a = criaGradeAmostralWithToken(); //Just to have something to try to update
        
        criaGradeAmostralWithoutToken();
        getGradeAmostralWithoutToken(a);
        updateGradeAmostralWithoutToken(a);
        removeGradeAmostralWithoutToken(a);
        
        //Dont let trash in the DB
        removeGradeAmostralWithToken(a);
    }
    
    
    
    public void getGradeAmostralWithoutToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/gradeamostral/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    
    public void getGradeAmostralWithToken(GradeAmostral a){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/gradeamostral/"+a.getCodigo());
        Assert.assertTrue(extract.statusCode()==200);
    }
    
}
