package edu.utfpr.adfapi.unittests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Ignore;

/**
 *
 * @author Rodrigo
 */
@Ignore
public class CidadeTest {
    
    private static final int ESTADO_ID = 1;
    public CidadeTest() {
    }
    

    
    @Test
    public void getAllCidadesWithoutToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithoutToken("api/cidade/estado/"+ESTADO_ID);
        Assert.assertTrue(extract.statusCode()==401);   
    }
    
    @Test
    public void getAllCidadesWithToken(){
        ExtractableResponse<Response> extract = APIConfig.getWithToken("api/cidade/estado/"+ESTADO_ID);
        Assert.assertTrue(extract.statusCode()==200);
    }
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
