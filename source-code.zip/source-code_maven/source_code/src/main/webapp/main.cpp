#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int montarArquivo(){
  FILE *ordenado, *invertido, *randomico;
  int tam, x;
  char nomeArquivo[255];
  printf("Informe o tamanho do arquivo: ");
  scanf("%d", &tam);

  sprintf(nomeArquivo, "Ordenado.txt");
  ordenado = fopen(nomeArquivo, "w");
  for (x=1;x<=tam;x++){
    fprintf(ordenado, "%d\n", x);
  }
  fclose(ordenado);

  sprintf(nomeArquivo, "Invertido.txt");
  invertido = fopen(nomeArquivo, "w");
  for (x=tam;x>=1;x--){
    fprintf(invertido, "%d\n", x);
  }
  fclose(invertido);

  srand(time(NULL));
  sprintf(nomeArquivo, "Randomico.txt");
  randomico = fopen(nomeArquivo, "w");
  for (x=tam;x>=1;x--){
    fprintf(randomico, "%d\n", rand()%tam);
  }
  fclose(randomico);

  return tam;
}
void bubbleSort(int v[], int n) {
    clock_t inicio = clock();
    int i, j, aux;
    for (i = 1; i < n; i++) {
        for (j = 0; j < n - 1; j++) {
            if (v[j] > v[j + 1]) {
                aux          = v[j];
                v[j]     = v[j + 1];
                v[j + 1] = aux;
            }
        }
    }
    double tempo = (double)(clock() - inicio) / CLOCKS_PER_SEC;
    cout << endl << "TEMPO: " << tempo << endl;
}
void insertionSort(int v[], int n){
    clock_t inicio = clock();
    //printf("TEMPO 1: %.10f\n", (double) inicio);
    int i, j, aux, y;
//    for (i = 1; i < 1000; i++) {
    for (i = 1; i < n; i++) {
        aux = v[i];
        //cout<< v[i] << " ";
        y = i - 1;
        while(y >= 0 && aux < v[y]){
            v[y+1] = v[y];
            y = y - 1;
 //           getch();

        }
        v[y+1] = aux;
    }
    double tempo = (double)(clock() - inicio) / (double) CLOCKS_PER_SEC;
     //cout << endl << "TEMPO: " << tempo << endl;
    //printf("TEMPO 2: %.10f\n", (double) clock());
    printf("TEMPO: %.10f\n",tempo);
}
int main(){
    int op;
    bool sair = false;
    std::ifstream file;
    int tam =2500, *v, i;
    while(!sair){
        printf("1 - Gerar Arquivos\n2 - Bubble\n3 - Insert\n4 - Quick\n5 - Sair\n\n\t");
        cin >> op;
        switch(op){
        case 1:
            tam = montarArquivo();
            break;
        case 2:
            v = (int *)malloc(tam * sizeof(int));
            file.open("Ordenado.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Ordenado.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("Ordenado - ");
            bubbleSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            file.open("Invertido.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Invertido.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("\nInvertido - ");
            bubbleSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            file.open("Randomico.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Randomico.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("\nRandomico - ");
            bubbleSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            printf("\n");
            system("pause");
            break;
        case 3:
            v = (int *)malloc(tam * sizeof(int));
            file.open("Ordenado.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Ordenado.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("Ordenado - ");
            insertionSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            file.open("Invertido.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Invertido.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("\nInvertido - ");
            insertionSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            file.open("Randomico.txt",ios::in);
            for(i = 0; i < tam; i++){
                if(!(file >> v[i])){
                    printf("\nFalha ao carregar um dado de Randomico.txt\n\n");
                    system("pause");
                    break;
                }
            }
            printf("\nRandomico - ");
            insertionSort(v,tam);
//            for(int c = 0; c < tam; c++) printf("\n\n%d ",v[c]);
//            puts("\n");
            file.close();
            printf("\n");
            system("pause");
            break;
        case 4:

            break;
        case 5:
            sair = true;
            break;
        default: sair = false;
        }
        system("cls");
    }


    return 0;
}
