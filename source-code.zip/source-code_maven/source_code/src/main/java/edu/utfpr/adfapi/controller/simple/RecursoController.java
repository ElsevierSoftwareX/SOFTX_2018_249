
package edu.utfpr.adfapi.controller.simple;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.auth.model.PermissaoRecurso;
import edu.utfpr.adfapi.auth.model.Recurso;
import edu.utfpr.adfapi.controller.GenericSimpleController;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/recurso")
public class RecursoController {

    @Inject
    private GenericSimpleController<Recurso> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new Recurso());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Recurso(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Recurso entity) {
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Recurso entity) {
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Recurso(), codigo);
    }
}
