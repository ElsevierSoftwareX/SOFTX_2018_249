
package edu.utfpr.adfapi.config;

import java.util.List;
/**
 *
 * @author Jasse
 */
public class Resource{
    
    private String nome;
    private List<String> dependencias;

    public Resource() {
    }

    public Resource(String nome, List<String> dependencias) {
        this.nome = nome;
        this.dependencias = dependencias;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<String> getDependencias() {
        return dependencias;
    }

    public void setDependencias(List<String> dependencias) {
        this.dependencias = dependencias;
    }

    /*@Override
    public int compareTo(Object object) {
        Resource otherResource = (Resource) object;
        //JOptionPane.showMessageDialog(null, "Comparando: "+ this+" e "+otherResource);
        //return (this.nome.compareTo(otherResource.getNome())==-1  ) ? -1: (this.nome.compareTo(otherResource.getNome())==1) ? 1:0;
       //return (this.nome.compareTo(otherResource.getNome())==-1  ) ? -1: 1;
       
       if(nome.compareTo(otherResource.getNome())==-1) {
           return 1;
       }
       return -1;
    }*/
}
