/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.swing.JOptionPane;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.geolatte.geom.MultiPolygon;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;


/**
 *
 * @author Jasse
 */  
@Entity
@Table (name="tb_area", uniqueConstraints=@UniqueConstraint(columnNames={"are_descricao", "are_usucodigo"}, name="uk_area"))
public class Area implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="are_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="are_descricao", length=100) @NotNull(message="Descricao é um campo obrigatório") private String descricao;
    @Column(name="are_tamanho", columnDefinition="Decimal", nullable = false) @NotNull(message="Tamanho é um campo obrigatório") private double tamanho;
    @Column(name="the_geom", columnDefinition="geometry(MultiPolygon, 4326)", nullable=false) private MultiPolygon theGeom;
    @Transient @NotNull(message="Geometria é um campo obrigatório") private String geom;
    @ManyToOne (fetch=FetchType.EAGER)
    @JoinColumn(name="are_tiposolocodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_area_tiposolo")) 
    @NotNull (message="Solo é um campo obrigatório") private Solo solo;
    @ManyToOne (fetch=FetchType.EAGER) 
    @JoinColumn(name="are_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_area_usuario")) 
    @NotNull (message="Usuario é um campo obrigatório") private Usuario usuario; 
    @Temporal(TemporalType.DATE) @Column (name="are_datacadastro", nullable=true) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    

    public Area() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Solo getSolo() {
        return solo;
    }

    public void setSolo(Solo solo) {
        this.solo = solo;
    }

    public MultiPolygon getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (MultiPolygon)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(MultiPolygon geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getDescricao() {
        return descricao;
        //return "Tudo funcionando perfeitamente";
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.codigo);
        hash = 97 * hash + Objects.hashCode(this.descricao);
        hash = 97 * hash + Objects.hashCode(this.theGeom);
        hash = 97 * hash + Objects.hashCode(this.solo);
        hash = 97 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Area other = (Area) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.theGeom, other.theGeom)) {
            return false;
        }
        if (!Objects.equals(this.solo, other.solo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }
    
    public void print(){
        JOptionPane.showMessageDialog(null, "Funcionou");
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
