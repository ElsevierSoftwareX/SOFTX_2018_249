/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.geolatte.geom.MultiPolygon;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_logarea")
public class LogArea implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="log_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="log_descricao", length=100) private String descricao;
    @Column(name="log_tamanho", columnDefinition="Decimal", nullable = false) @NotNull private double tamanho;
    @Column(name="log_tiposolocodigo", columnDefinition="Integer", nullable=false) private Integer codigoSolo;
    @Column(columnDefinition="geometry(MultiPolygon, 4326)") @NotNull private MultiPolygon theGeom;
    @Transient private String geom;
    @Column(name="log_usucodigo", columnDefinition="Integer", nullable=false) @NotNull private Integer codigoUsuario; //Dono da Area
    @Temporal(TemporalType.DATE) @Column (name="log_datacadastro", nullable=true) private Date dataCadastro;
    @Temporal(TemporalType.DATE) @Column (name="are_dataalteracao", nullable=false) @NotNull private Date dataAlteracao;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="log_tipomodificacao", length=60, nullable=true) private String tipoAlteracao; // Difere da Safra
    @Column (name=" log_arecodigo", nullable=false, columnDefinition="Integer") @NotNull private Integer codigoArea;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull
    @JoinColumn (name=" log_usucodigoalteracao", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_logarea_usuarioalteracao"))
    private Usuario usuario;
    
    

    public LogArea() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public Integer getCodigoSolo() {
        return codigoSolo;
    }

    public void setCodigoSolo(Integer codigoSolo) {
        this.codigoSolo = codigoSolo;
    }

    public Integer getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(Integer codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }
    
        public MultiPolygon getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (MultiPolygon)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(MultiPolygon geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getDataAlteracao() {
        return dataAlteracao;
    }

    public void setDataAlteracao(Date dataAlteracao) {
        this.dataAlteracao = dataAlteracao;
    }

    public String getTipoAlteracao() {
        return tipoAlteracao;
    }

    public void setTipoAlteracao(String tipoAlteracao) {
        this.tipoAlteracao = tipoAlteracao;
    }

    public Integer getCodigoArea() {
        return codigoArea;
    }

    public void setCodigoArea(Integer codigoArea) {
        this.codigoArea = codigoArea;
    }

    public Usuario getUsuarioAlterou() {
        return usuario;
    }

    public void setUsuarioAlterou(Usuario usuarioAlterou) {
        this.usuario = usuarioAlterou;
    }

    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
