/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import edu.utfpr.adfapi.auth.model.Permissao;
import edu.utfpr.adfapi.auth.model.PermissaoRecurso;
import edu.utfpr.adfapi.auth.model.Recurso;
import edu.utfpr.adfapi.auth.model.Token;
import edu.utfpr.adfapi.config.CONFIG;
import edu.utfpr.adfapi.dao.PermissaoDAO;
import edu.utfpr.adfapi.dao.UsuarioDAO;
import edu.utfpr.adfapi.model.Usuario;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.impl.TextCodec;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.inject.Inject;

/**
 *
 * @author Jasse
 */
public class JWTSigner {

    @Inject
    private UsuarioDAO dao;
    @Inject
    private PermissaoDAO pdao;
    private final String SCR = "Serenia-Fuleza/Humanitta-H4s4";

    public JWTSigner() {
    }

    public String generateToken(Token token) {

        Map<String, Object> claims = new HashMap<>();
        claims.put("id", token.getId());
        claims.put("nome", token.getNome());
        claims.put("permission", permission(Long.parseLong(token.getId())));
        LocalDateTime exp = LocalDateTime.now().plusHours(24);
        Date expDate = Date.from(exp.atZone(ZoneId.systemDefault()).toInstant());

        String jwtToken = Jwts.builder().setClaims(claims).setExpiration(expDate)
                .signWith(SignatureAlgorithm.HS512, TextCodec.BASE64.encode(SCR)).compact();

        return jwtToken;
    }

    public String generateToken(Usuario usuario) {
        try {
            List<Permissao> permList = pdao.findAllByUser(usuario);
            Map<String, HashSet<String>> mapOfList = new HashMap();

            for (Permissao permissao : permList) {
                String code = permissao.getCodigo() + "|" + permissao.getAutorizante().getCodigo() + "|" + permissao.getAutorizante().getNome() + "|" + permissao.getDataExpiracao().toString();

                HashSet<String> perms = new HashSet();
                for (PermissaoRecurso pr : pdao.findByPermissao(permissao)) {
                    String recName = pr.getRecurso().getNome();

                    if (!recName.startsWith("Pixel") && !recName.startsWith("Ponto")) {// && !CONFIG.isShared(pr.getRecurso().getNome())
                        recName = recName + "|" + pr.getDelete() + pr.getGet() + pr.getPost() + pr.getPut();
                        perms.add(recName);
                    }
                }
                mapOfList.put(code, perms);
            }
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", usuario.getCodigo() + "");
            claims.put("perms", mapOfList);

            LocalDateTime exp = LocalDateTime.now().plusHours(24);
            Date expDate = Date.from(exp.atZone(ZoneId.systemDefault()).toInstant());

            String jwtToken = Jwts.builder().setClaims(claims).setExpiration(expDate)
                    .signWith(SignatureAlgorithm.HS512, TextCodec.BASE64.encode(SCR)).compact();

            return jwtToken;
        } catch (Exception e) {
            throw e;
        }
    }

    public Claims verifyToken(String token) {
        try {
            Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
            return claims;// Só chega aqui se a assinatura do token for valida
        } catch (SignatureException e) {
            return null;
            //Invalid signature/claims
        }
    }

    public Long getUserId(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return Long.parseLong(claims.get("id", String.class));
    }

    public Long getDataExpiracao(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return Long.parseLong(claims.get("id", String.class));
    }
    public String getUserName(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return claims.get("nome", String.class);
    }

    public Map<String, HashSet<String>> getPermissions(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return (Map<String, HashSet<String>>) claims.get("perms");
    }

    public Map<String, List<String>> getPermCodes(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return (Map<String, List<String>>) claims.get("perms");
    }

    public List<Long> getPermission(String token) {
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        List<Long> permissions = new ArrayList();
        String[] objects = claims.get("permission", String.class).split(Pattern.quote("|"));
        for (String code : objects) {
            permissions.add(Long.parseLong(code));
        }

        return permissions;
    }

    public Claims parseToken(String token) {//Não está sendo usado
        Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(SCR)).parseClaimsJws(token).getBody();
        return claims;
    }

    public List<Permissao> getPermissoes(String token) {
        try {
            Map<String, List<String>> permCodes = getPermCodes(token);

            List<String> keys = new ArrayList(permCodes.keySet());
            List<Permissao> permissoes = new ArrayList();
            for (String key : keys) {
                List<Recurso> listRecs = new ArrayList();
                String[] objects = key.split(Pattern.quote("|"));
                Usuario autorizante = new Usuario();
                autorizante.setCodigo(Long.parseLong(objects[1]));
                autorizante.setNome(objects[2]);

                Permissao permissao = new Permissao();
                permissao.setCodigo(Long.parseLong(objects[0]));
                permissao.setAutorizante(autorizante);

                permissao.setDataExpiracao(new SimpleDateFormat("yyyy-MM-dd").parse(objects[3]));
                for (String objetos : permCodes.get(key)) {
                    Recurso recurso = new Recurso();
                    String[] recursos = objetos.split(Pattern.quote("|"));
                    recurso.setNome(recursos[0]);
                    recurso.setDelete(recursos[1].charAt(0) + "");
                    recurso.setGet(recursos[1].charAt(1) + "");
                    recurso.setPost(recursos[1].charAt(2) + "");
                    recurso.setPut(recursos[1].charAt(3) + "");
                    listRecs.add(recurso);
                }
                permissao.setRecursos(listRecs);
                permissoes.add(permissao);
            }
            return permissoes;
        } catch (NumberFormatException | ParseException e) {
            return null;
        }
    }

    public Permissao getPermissao(String token, Long codigo) {
        try {
            Map<String, List<String>> permCodes = getPermCodes(token);
            Permissao permissao = new Permissao();
            List<String> keys = new ArrayList(permCodes.keySet());
            boolean found=false;
            for (String key : keys) {
                
                List<Recurso> listRecs = new ArrayList();
                String[] objects = key.split(Pattern.quote("|"));

                if ((codigo + "").equals(objects[0])) {
                    found=true;
                    Usuario autorizante = new Usuario();
                    autorizante.setCodigo(Long.parseLong(objects[1]));
                    autorizante.setNome(objects[2]);
                    permissao.setCodigo(Long.parseLong(objects[0]));
                    permissao.setAutorizante(autorizante);

                    permissao.setDataExpiracao(new SimpleDateFormat("yyyy-MM-dd").parse(objects[3]));
                    for (String objetos : permCodes.get(key)) {
                        Recurso recurso = new Recurso();
                        String[] recursos = objetos.split(Pattern.quote("|"));
                        recurso.setNome(recursos[0]);
                        recurso.setDelete(recursos[1].charAt(0) + "");
                        recurso.setGet(recursos[1].charAt(1) + "");
                        recurso.setPost(recursos[1].charAt(2) + "");
                        recurso.setPut(recursos[1].charAt(3) + "");
                        listRecs.add(recurso);
                    }
                    permissao.setRecursos(listRecs);
                    break;
                }               
            }
            if(!found) return null;
            return permissao;
        } catch (NumberFormatException | ParseException e) {
            return null;
        }
    }

    public List<Permissao> getSimplePerm(String token) {
        try {
            Map<String, List<String>> permCodes = getPermCodes(token);

            List<String> keys = new ArrayList(permCodes.keySet());
            List<Permissao> permissoes = new ArrayList();
            for (String key : keys) {
                String[] objects = key.split(Pattern.quote("|"));
                Usuario autorizante = new Usuario();
                autorizante.setCodigo(Long.parseLong(objects[1]));
                autorizante.setNome(objects[2]);

                Permissao permissao = new Permissao();
                permissao.setCodigo(Long.parseLong(objects[0]));
                permissao.setAutorizante(autorizante);
                permissao.setDataExpiracao(new SimpleDateFormat("yyyy-MM-dd").parse(objects[3]));
                permissoes.add(permissao);
            }
            return permissoes;
        } catch (NumberFormatException | ParseException e) {
            return null;
        }
    }

    public boolean isValid(String token, String recurso, String metodo, Long autorizante) {
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date today= dateFormat.parse(dateFormat.format(Calendar.getInstance().getTime()));
            Map<String, List<String>> permCodes = getPermCodes(token);

            List<String> keys = new ArrayList(permCodes.keySet());
            for (String key : keys) {
                String[] objects = key.split(Pattern.quote("|"));
                Date expDate= dateFormat.parse(objects[3]);

                if(expDate.after(today)){
                    if (autorizante == Long.parseLong(objects[1])) {
                    
                    for (String objetos : permCodes.get(key)) {
                        String[] recursos = objetos.split(Pattern.quote("|"));
                        if (recurso.equalsIgnoreCase(recursos[0])) {
                            metodo=metodo.toLowerCase();
                            
                            switch (metodo) {
                                case "delete": {
                                    if (recursos[1].charAt(0) == 'T') {
                                        return true;//expDate.before(today);  
                                    }
                                }
                                case "get": {
                                    if (recursos[1].charAt(1) == 'T') {
                                        //JOptionPane.showMessageDialog(null, "Get aprovado. Permissçao: "+objects[0]);
                                        return true;//expDate.before(today); 
                                    }
                                }
                                case "post": {
                                    if (recursos[1].charAt(2) == 'T') {
                                        //JOptionPane.showMessageDialog(null, "Post aprovado. Permissçao: "+objects[0]);
                                        return true;//expDate.before(today);
                                    }
                                }
                                case "put": {
                                    if (recursos[1].charAt(3) == 'T') {
                                        //JOptionPane.showMessageDialog(null, "Put aprovado. Permissçao: "+objects[0]);
                                        return true;//expDate.before(today); 
                                    }
                                }
                            }
                        }
                    }
                }
                }
                
            }
            
        } catch (NumberFormatException e) {
            throw e;
        } catch (ParseException ex) {
            Logger.getLogger(JWTSigner.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private String permission(Long autorizado) {
        String codes = "";
        try {
            List<Permissao> permission = dao.getPermissoes(autorizado);
            if (permission.size() == 0) {
                return codes;
            }
            for (Permissao permissao : permission) {
                codes += "|" + permissao.getCodigo();
            }
            codes = (codes.trim()).substring(1);

        } catch (Exception ex) {
            Logger.getLogger(JWTSigner.class.getName()).log(Level.SEVERE, null, ex);
        }
        return codes;
    }
}
