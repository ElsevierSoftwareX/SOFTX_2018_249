/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author UTFPR
 */

@Entity
@Table (name="tb_solousuario", uniqueConstraints=@UniqueConstraint(columnNames={"sol_usucodigo", "sol_tipcodigo"}, name="uk_solousuario"))
public class SoloUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="sol_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="sol_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_solousuario_usuario")) private Usuario usuario;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Solo é um campo obrigatório")
    @JoinColumn (name="sol_tipcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_solousuario_tiposolo")) private Solo solo;


    public SoloUsuario() {
    }

    public SoloUsuario(Usuario usuario, Solo solo) {
        this.usuario = usuario;
        this.solo = solo;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Solo getSolo() {
        return solo;
    }

    public void setSolo(Solo solo) {
        this.solo = solo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.usuario);
        hash = 67 * hash + Objects.hashCode(this.solo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SoloUsuario other = (SoloUsuario) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.solo, other.solo)) {
            return false;
        }
        return true;
    }
    
    public Solo getMainResource() {
        return solo;
    }

    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
