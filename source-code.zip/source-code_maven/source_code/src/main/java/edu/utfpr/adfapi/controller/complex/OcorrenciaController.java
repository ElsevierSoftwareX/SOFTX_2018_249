
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.Area;
import edu.utfpr.adfapi.model.Ocorrencia;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/ocorrencia")
public class OcorrenciaController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<Area> depdao;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new Ocorrencia());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Ocorrencia(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Ocorrencia entity) {
        if (entity.getArea() != null) {
            if (entity.getArea().getCodigo() != null) {
                Area dependency = depdao.find(entity.getArea().getCodigo(), new Area());
                entity.setArea(dependency);
                entity.setUsuario(dependency.getUsuario());
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Ocorrencia entity) {
        if (entity.getArea() != null) {
            if (entity.getArea().getCodigo() != null) {
                Area dependency = depdao.find(entity.getArea().getCodigo(), new Area());
                entity.setArea(dependency);
                entity.setUsuario(dependency.getUsuario());
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Ocorrencia(), codigo);
    }
}
