/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.persistence.Column;
import javax.persistence.JoinColumn;

/**
 *
 * @author Jasse
 */
public class Reflection {

    private Method getMethod;
    private Method setMethod;
    private Field field;
    private Column column;
    private JoinColumn jColumn;

    public Reflection(Method getMethod, Method setMethod, Field field, Column column, JoinColumn jColumn) {
        this.getMethod = getMethod;
        this.setMethod = setMethod;
        this.field = field;
        this.column = column;
        this.jColumn = jColumn;
    }

    public String toString() {
        String col = (column != null) ? column.name() : "null";
        String jCol = (column != null) ? jColumn.name() : "null";
        String fie = (field != null) ? field.getName() : "null";
        String get = (getMethod != null) ? getMethod.getName() : "null";
        String set = (setMethod != null) ? setMethod.getName() : "null";

        return "Field: " + fie + ". Get: " + get + ". Set: " + set + ". Column: " + col + ". JoinColumn: " + jCol;
    }

    public String print() {
        return "ACEITOU";
    }

    public Method getGetMethod() {
        return getMethod;
    }

    public void setGetMethod(Method getMethod) {
        this.getMethod = getMethod;
    }

    public Method getSetMethod() {
        return setMethod;
    }

    public void setSetMethod(Method setMethod) {
        this.setMethod = setMethod;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public Column getColumn() {
        return column;
    }

    public void setColumn(Column column) {
        this.column = column;
    }

    public JoinColumn getjColumn() {
        return jColumn;
    }

    public void setjColumn(JoinColumn jColumn) {
        this.jColumn = jColumn;
    }
}
