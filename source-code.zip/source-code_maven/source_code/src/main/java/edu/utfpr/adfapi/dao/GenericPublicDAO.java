
package edu.utfpr.adfapi.dao;

import edu.utfpr.adfapi.config.CONFIG;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.config.Reflection;
import edu.utfpr.adfapi.model.Usuario;
import edu.utfpr.adfapi.controller.GenericPublicController;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.JoinColumn;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 *
 * @author Jasse
 * @param <E>
 * @param <A>
 */
public class GenericPublicDAO<E, A> {

    @Inject
    private EntityManager manager;

    private final String idioma = "PT";

    public GenericPublicDAO() {

    }

    public E create(E entity, A association) throws Exception {

        E found = findByDescricao(getDescricao(entity, idioma), (Class<E>) entity.getClass());
        
        if (found == null) { //Entity does not exists                   
            manager.persist(entity);            
            association = setAssociation(association, entity);
        } else {       
            association = setAssociation(association, found, entity);
            entity = found;
            if ((A) findAssociation(association, idioma) != null) {
                return null;// Already exists. Nothing was created
            }
        }
        manager.persist(association);
        return entity;// Exclude user
    }

    public E update(E entity, A association) throws Exception {
        association = setAssociation(association, entity);

        if ((A) findAssociation(association, idioma) == null) {
            manager.merge(entity);
            return entity;
        }
        return null;// With the given description this user has already one association
    }

    public E delete(E entity, A association) throws Exception {
        association = setAssociation(association, entity);
        association = (A) findAssociation(association, idioma);
        if (association != null) {
            manager.remove(association);
        } else {
            if (!existsAssociation(association, entity)) {
                manager.remove(entity);
            }
        }
        return entity;// Exclude user
    }

    public E find(A association) {
        
        return this.findEntity(association);
    }

    public List<E> findByDescricao(E entity, String idioma) {
        return getEntities(entity, idioma);
    }

    public List<E> findAllByDescricao(String value, Class<E> type) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u where u." + getDescricaoField(type, idioma) + " like :value");
            query.setParameter("value", "%" + value + "%");
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    private E findByDescricao(String value, Class<E> type) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u where u." + getDescricaoField(type, idioma) + " = :value");
            query.setParameter("value", value);
            return (E) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    public List<E> findAllByUser(A association) {
        return this.findEntities(association);
    }

    private String getDescricaoField(Class<E> type, String idioma) {
        try {
            Field field = type.getDeclaredField("descricao");
            return field.getName();

        } catch (NoSuchFieldException e) {

            try {
                Field field = type.getDeclaredField("nome");
                return field.getName();
            } catch (NoSuchFieldException ex) {
                for (Field field : type.getDeclaredFields()) {
                    if (field.getName().equalsIgnoreCase("descricao" + idioma)) {
                        return field.getName();
                    }
                }
                Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (SecurityException ex) {
            Logger.getLogger(GenericPublicController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private String getDescricao(E entity, String idioma) throws NoSuchMethodException {
        try {
            String method = "get" + getDescricaoField((Class<E>) entity.getClass(), idioma);
            if (method.contains("escricao")) {
                method = method.replace("descricao", "Descricao");
            } else {
                method = method.replace("nome", "Nome");
            }
            Method getDescricao = entity.getClass().getDeclaredMethod(method, null);
            return (String) getDescricao.invoke(entity, null);
        } catch (NoSuchMethodException ex) {
            throw ex;
        } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }

    private List<E> getEntities(E entity, String idioma) {
        List<E> list = new ArrayList();
        try {
            String method = "";
            String field = getDescricaoField((Class<E>) entity.getClass(), idioma);
            if (field.contains("escricao")) {
                method = ("get" + field).replace("descricao", "Descricao");
            } else {
                method = ("get" + field).replace("nome", "Nome");
            }
            Method getDescricao = entity.getClass().getDeclaredMethod(method, null);
            Query query = manager.createQuery("from " + entity.getClass().getSimpleName() + " u where u." + field + " like :value");
            query.setParameter("value", "%" + (String) getDescricao.invoke(entity, null) + "%");
            list = query.getResultList();
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(GenericPublicController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    private A setAssociation(A association, E entity) {
        try {
            Usuario user = new Usuario();
            for (Method method : entity.getClass().getDeclaredMethods()) {
                if ("getUsuario".equalsIgnoreCase(method.getName())) {
                    user = (Usuario) method.invoke(entity, null);
                    break;
                }
            }
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    for (Method method : association.getClass().getDeclaredMethods()) {

                        if (method.getName().equalsIgnoreCase("set" + field.getName())) {
                            method.invoke(association, entity);
                        }
                        if (method.getName().equalsIgnoreCase("setUsuario")) {
                            method.invoke(association, user);
                        }
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, e);
        }

        return association;
    }
    
    private A setAssociation(A association, E entity, E found) {
        try {
            Usuario user = new Usuario();
            for (Method method : found.getClass().getDeclaredMethods()) {
                if ("getUsuario".equalsIgnoreCase(method.getName())) {
                    user = (Usuario) method.invoke(found, null);
                    break;
                }
            }
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    for (Method method : association.getClass().getDeclaredMethods()) {

                        if (method.getName().equalsIgnoreCase("set" + field.getName())) {
                            method.invoke(association, entity);
                        }
                        if (method.getName().equalsIgnoreCase("setUsuario")) {
                            method.invoke(association, user);
                        }
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, e);
        }

        return association;
    }

    private A findAssociation(A association, String idioma) throws NoSuchMethodException {
        Method getUsuario = null, getMain = null;
        String main = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    main = field.getName() + "." + this.getDescricaoField((Class<E>) field.getType(), idioma);

                    for (Method method : association.getClass().getDeclaredMethods()) {
                        if (method.getName().equalsIgnoreCase("get" + field.getName())) {
                            getMain = method;
                        }
                        if (method.getName().equalsIgnoreCase("getUsuario")) {
                            getUsuario = method;
                        }
                    }
                }
            }

            String selectQuery = "from " + association.getClass().getSimpleName() + " a WHERE a.usuario = ? and a." + main + " = ?";
            Query query = manager.createQuery(selectQuery);

            query.setParameter(1, getUsuario.invoke(association, null));
            query.setParameter(2, getDescricao((E) getMain.invoke(association, null), idioma));
            return (A) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private E findEntity(A association) {
        Method getUsuario = null, getMain = null, getCodigo = null;
        String main = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    main = field.getName();
                    getCodigo = field.getType().getClass().getDeclaredMethod("getCodigo", null);
                    for (Method method : association.getClass().getDeclaredMethods()) {
                        if (method.getName().equalsIgnoreCase("get" + field.getName())) {
                            getMain = method;
                        }
                        if (method.getName().equalsIgnoreCase("getUsuario")) {
                            getUsuario = method;
                        }
                    }
                }
            }

            String selectQuery = "from " + association.getClass().getSimpleName() + " a WHERE a.usuario = ? and a." + main + ".codigo = ?";
            Query query = manager.createQuery(selectQuery);
            query.setParameter(2, getCodigo.invoke(getMain.invoke(association, null), null));
            query.setParameter(1, getUsuario.invoke(association, null));
            return (E) getMain.invoke((A) query.getSingleResult(), null);
        } catch (NoResultException e) {
            return null;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public boolean inUseEntity(A association, E entity) throws NoSuchMethodException {
        String main = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    main = field.getName() + "." + this.getDescricaoField((Class<E>) field.getType(), idioma);
                }
            }

            Query query = manager.createQuery("from " + association.getClass().getSimpleName() + " a WHERE a." + main + " = ?");
            query.setParameter(1, getDescricao(entity, idioma));
            return query.getResultList().size() > 1;// mais de uma ocorrencia desse 
        } catch (NoResultException e) {
            return false;
        }
    }

    public boolean existsAssociation(A association, E entity) throws NoSuchMethodException {
        String main = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    main = field.getName() + "." + this.getDescricaoField((Class<E>) field.getType(), idioma);
                }
            }

            Query query = manager.createQuery("from " + association.getClass().getSimpleName() + " a WHERE a." + main + " = ?");
            query.setParameter(1, getDescricao(entity, idioma));
            return query.getResultList().size() > 0;// Pelo menos uma ocorrencia desse 
        } catch (NoResultException e) {
            return false;
        }
    }

    public E find(A association, Long codigo, Usuario usuario) {
        Method getMain = null;
        String main = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    main = field.getName();
                    for (Method method : association.getClass().getDeclaredMethods()) {
                        if (method.getName().equalsIgnoreCase("get" + field.getName())) {
                            getMain = method;
                        }
                    }
                }
            }

            Query query = manager.createQuery("from " + association.getClass().getSimpleName() + " a WHERE a." + main + ".codigo = ? and a.usuario = ?");
            query.setParameter(1, codigo);
            query.setParameter(2, usuario);
            return (E) getMain.invoke((A) query.getSingleResult(), null);
        } catch (NoResultException e) {
            return null;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | SecurityException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private List<E> findEntities(A association) {
        List<E> entities = new ArrayList();
        Method getUsuario = null, getMain = null;
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {

                    for (Method method : association.getClass().getDeclaredMethods()) {
                        if (method.getName().equalsIgnoreCase("get" + field.getName())) {
                            getMain = method;
                        }
                        if (method.getName().equalsIgnoreCase("getUsuario")) {
                            getUsuario = method;
                        }
                    }
                }
            }

            String selectQuery = "from " + association.getClass().getSimpleName() + " a WHERE a.usuario = ?";
            Query query = manager.createQuery(selectQuery);
            query.setParameter(1, getUsuario.invoke(association, null));

            List<A> associations = query.getResultList();
            for (A a : associations) {
                entities.add((E) getMain.invoke(a, null));
            }
            return entities;
        } catch (NoResultException e) {
            return entities;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public List<E> findAllByUser(A association, Usuario usuario) {
        List<E> entities = new ArrayList();
        Method getMain = null;
        String order = "";
        try {
            for (Field field : association.getClass().getDeclaredFields()) {
                if ((field.getName() + "Usuario").equalsIgnoreCase(association.getClass().getSimpleName())) {
                    for (Method method : association.getClass().getDeclaredMethods()) {
                        if (method.getName().equalsIgnoreCase("get" + field.getName())) {
                            getMain = method;
                            order = field.getName();
                        }
                    }
                }
            }
            if (getMain == null) {
                return entities;
            }
            String selectQuery = "from " + association.getClass().getSimpleName() + " a WHERE a.usuario = ? order by (" + order + ".codigo)";
            Query query = manager.createQuery(selectQuery);
            query.setParameter(1, usuario);

            List<A> associations = query.getResultList();
            for (A a : associations) {
                entities.add((E) getMain.invoke(a, null));
            }
            return entities;
        } catch (NoResultException e) {
            return entities;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(GenericPublicDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public String validateDepsUser(E entity, Usuario usuario) {
        Inspector insp = new Inspector(entity);
        try {
            for (int i = 0; i < insp.size(); i++) {
                Reflection ref = insp.getReflection(i);
                JoinColumn jColumn = ref.getjColumn();

                if (jColumn != null && !ref.getField().getName().equals("usuario")) {
                    Inspector inspDep = new Inspector(ref.getField().getType());
                    Long depCode = (Long) inspDep.getGetMethod("codigo").invoke(ref.getGetMethod().invoke(entity, null), null);
                    Object dep = find(depCode, (Class<E>) ref.getField().getType());
                    if(dep==null) return ref.getField().getType().getSimpleName();
                    ref.getSetMethod().invoke(entity, find(depCode, (Class<E>) dep.getClass()));//ref.getField().getType().newInstance()));
                    if (CONFIG.isShared(ref.getField().getType().getSimpleName())) {

                        String main = ref.getField().getType().getSimpleName();
                        Query query = manager.createQuery("from " + main + "Usuario" + " a WHERE a.usuario = ? and a." + main.toLowerCase() + " = ?");
                        query.setParameter(1, usuario);

                        query.setParameter(2, find(depCode, (Class<E>) dep.getClass()));

                        if (query.getResultList().isEmpty()) {
                            return ref.getField().getType().getSimpleName();
                        }
                        return "true";
                    }

                    Method getUsuario = ref.getField().getType().getDeclaredMethod("getUsuario", null);
                    Usuario user = (Usuario) getUsuario.invoke(ref.getGetMethod().invoke(entity, null), null);
                    if (!usuario.equals(user)) {
                        return ref.getField().getType().getSimpleName();
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException | InvocationTargetException e) {
            Logger.getLogger(GenericComplexDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        
        return "true";
    }
    
    public E find(Long id, Class<E> type) { // Just find the entity with this ID
        try {
            return manager.find(type, id);
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
}
