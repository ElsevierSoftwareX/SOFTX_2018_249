/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_marca", uniqueConstraints=@UniqueConstraint(columnNames={"mar_descricao", "mar_usucodigo"}, name="uk_marca"))
public class Marca implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="mar_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="mar_descricao", length=100, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="mar_datacadastro", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull(message="Usuario é um campo obrigatório")
    @JoinColumn (name="mar_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_marca_usuario"))
    private Usuario usuario;

    public Marca() {
    }

    public Marca(String descricao, Date dataCadastro, Usuario usuario) {
        this.descricao = descricao;
        this.dataCadastro = dataCadastro;
        this.usuario = usuario;
    }
  
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

     public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Marca other = (Marca) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        return Objects.equals(this.descricao, other.descricao);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.descricao);
        hash = 67 * hash + Objects.hashCode(this.dataCadastro);
        hash = 67 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public String toString() {
        return "Marca{" + "codigo=" + codigo + ", descricao=" + descricao + '}';
    }
    
    public boolean hasAssociation(){
        return true;
    }

    public MarcaUsuario getAssociation(){
        MarcaUsuario entity  = new MarcaUsuario();
        entity.setUsuario(usuario);
        entity.setMarca(this);
        return entity;
    } 
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
