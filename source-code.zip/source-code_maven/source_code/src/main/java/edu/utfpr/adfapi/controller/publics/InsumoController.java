
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.Insumo;
import edu.utfpr.adfapi.model.InsumoUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/insumo")
public class InsumoController {

    @Inject
    private GenericPublicController<Insumo, InsumoUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new InsumoUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        
        controller.get(value, new Insumo());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new InsumoUsuario(), new Insumo(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Insumo entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new InsumoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Insumo entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new InsumoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Insumo(), new InsumoUsuario(), codigo);
    }
}
