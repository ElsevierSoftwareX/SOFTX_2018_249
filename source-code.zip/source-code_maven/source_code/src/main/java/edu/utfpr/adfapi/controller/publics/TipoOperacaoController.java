
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.dao.GenericPublicDAO;
import edu.utfpr.adfapi.model.TipoOperacao;
import edu.utfpr.adfapi.model.TipoOperacaoUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/tipooperacao")
public class TipoOperacaoController {

    @Inject
    private GenericPublicController<TipoOperacao, TipoOperacaoUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new TipoOperacaoUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new TipoOperacao());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new TipoOperacaoUsuario(), new TipoOperacao(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(TipoOperacao entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new TipoOperacaoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(TipoOperacao entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new TipoOperacaoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new TipoOperacao(), new TipoOperacaoUsuario(), codigo);
    }
}
