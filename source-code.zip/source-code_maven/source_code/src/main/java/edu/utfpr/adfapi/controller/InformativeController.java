
package edu.utfpr.adfapi.controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Put;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.view.Results;
import com.google.common.reflect.ClassPath;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.config.CONFIG;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.config.Reflection;
import edu.utfpr.adfapi.config.Resource;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.persistence.JoinColumn;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/info")
public class InformativeController {

    @Inject
    private Result result;
    @Inject
    HttpServletResponse resp;

    @APIRestrito
    @Post("/{entity}")
    public void post(String entity) {
        try {
            Map<String, String> map = setInfo(entity);
            map.remove("codigo");
            result.use(Results.json()).withoutRoot().from(map).serialize();
        } catch (Exception ex) {
            Logger.getLogger(InformativeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @APIRestrito
    @Put("/{entity}")
    public void put(String entity) {
        result.use(Results.json()).withoutRoot().from(setInfo(entity)).serialize();
    }

    @APIRestrito
    @Get("/recursos")
    public void get(Long codigo) {
        try {
            result.use(Results.json()).withoutRoot().from(entities()).include("dependencias").serialize();
        } catch (Exception ex) {
            Logger.getLogger(InformativeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Map<String, String> setInfo(String entity) {

        Map<String, String> map = new HashMap();
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
                if (info.getName().startsWith("edu.utfpr.adfapi.model.")) {
                    final Class<?> clazz = info.load();
                    if (clazz.getSimpleName().equalsIgnoreCase(entity)) {
                        Class classe = Class.forName(clazz.getName());
                        for (Field field : classe.getDeclaredFields()) {
                            map.put(field.getName(), field.getType().getSimpleName());
                        }
                    }
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(InformativeController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            map.put("erro", "Classe [ " + entity + " ] não encontrada");
        }

        map.remove("dataCadastro");
        map.remove("dataExpiracao");
        if (map.containsKey("theGeom")) {
            map.put("geom", "String: [" + map.get("theGeom") + "] em formato Well-Known Text (WKT)");
        }
        map.remove("theGeom");
        map.remove("usuario");
        return new TreeMap<String, String>(map);
    }

    public List<Resource> entities() {
        Set<Resource> resources = new HashSet<>();

        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
                Resource resource = new Resource();

                if (info.getName().startsWith("edu.utfpr.adfapi.model.")) {
                    String classe = info.getSimpleName();
                    if (!classe.contains("Usuario") && !classe.startsWith("Pixel") && !classe.startsWith("Log") && !classe.startsWith("Ponto") 
                            && !CONFIG.isShared(classe) && !classe.startsWith("Geometria")) {//  && !classe.equals("TipoOcorrencia")

                        Set<String> deps = new HashSet<>();
                        resource.setNome(info.getSimpleName());
                        Inspector insp = new Inspector(Class.forName(info.getName()));
                        for (int i = 0; i < insp.size(); i++) {
                            Reflection ref = insp.getReflection(i);
                            JoinColumn jColumn = ref.getjColumn();
                            if (jColumn != null) {
                                if (!ref.getField().getType().getSimpleName().equals("Usuario")) {
                                    deps.add(ref.getField().getType().getSimpleName());
                                }
                            }
                            List<String> list = new ArrayList<String>(deps);
                            resource.setDependencias(list);
                        }
                        resources.add(resource);
                    }
                }
            }
            return sort(new ArrayList(resources));
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(InformativeController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private List<Resource> sort(List<Resource> list) {
        for (int i = 0; i < list.size(); i++) {
            int index = i;
            for (int j = i; j < list.size(); j++) {
                if (list.get(j).getNome().compareTo(list.get(index).getNome()) < 0) {
                    index = j;
                }
            }
            Resource small = list.get(index);
            list.set(index, list.get(i));
            list.set(i, small);
        }
        return list;
    }
}
