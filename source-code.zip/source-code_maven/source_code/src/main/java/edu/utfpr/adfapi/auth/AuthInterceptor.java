/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import br.com.caelum.vraptor.Accepts;
import br.com.caelum.vraptor.AroundCall;
import br.com.caelum.vraptor.Intercepts;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.controller.ControllerMethod;
import br.com.caelum.vraptor.interceptor.SimpleInterceptorStack;
import edu.utfpr.adfapi.startup.LoginController;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author Rodrigo
 */
@Intercepts
@RequestScoped
public class AuthInterceptor {

    @Inject private UsuarioSessao sessao;
    @Inject private Result result;

    public AuthInterceptor() {
    }

    @Accepts
    public boolean accepts(ControllerMethod method) {
        return method.containsAnnotation(Restrito.class);
    }

    @AroundCall
    public void filtrar(SimpleInterceptorStack stack) {
        if (!sessao.isLogado()) {
            result.redirectTo(LoginController.class).loginForm();
        }
        stack.next();
    }
}
