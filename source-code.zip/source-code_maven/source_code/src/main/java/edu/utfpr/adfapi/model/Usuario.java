/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import br.com.caelum.vraptor.serialization.SkipSerialization;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Email;


/**
 *
 * @author Erminio Jasse
 */
@Entity
@Table (name="tb_usuario", uniqueConstraints={
    @UniqueConstraint(columnNames="usu_fone", name="uk_usuariofone"),
    @UniqueConstraint(columnNames="usu_email", name="uk_usuarioemail")
})
/*@NamedNativeQuery(name="Usuario.findAll", query="select * from tb_usuario", resultClass=Usuario.class)*/
public class Usuario implements Serializable{

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY) @Column(name="usu_codigo") private Long codigo;
    @Column (name="usu_nome", length=60, nullable = false) @NotNull private String nome;
    @Column (name="usu_email", length=90, nullable = true) @Email private String email;
    @Column (name="usu_perfil", length=15, nullable=true) private String perfil;
    @Column (name="usu_fone", length=15, nullable=false) @NotNull (message="Telefone é um campo obrigatório") private String telefone;
    @Column (name="usu_senha", length=60, nullable=false) @NotNull (message="Senha é um campo obrigatório") @SkipSerialization private String senha;
    @Temporal(TemporalType.DATE) @Column (name="usu_datacadastro", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @Temporal(TemporalType.DATE) @Column (name="usu_dataexpiracao", nullable=false) @NotNull (message="DataExpiração é um campo obrigatório") private Date dataExpiracao;
    

    public Usuario() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getDataExpiracao() {
        return dataExpiracao;
    }

    public void setDataExpiracao(Date dataExpiracao) {
        this.dataExpiracao = dataExpiracao;
    }
  
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.codigo);
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + Objects.hashCode(this.email);
        hash = 97 * hash + Objects.hashCode(this.telefone);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.telefone, other.telefone)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        return true;
    }
}
