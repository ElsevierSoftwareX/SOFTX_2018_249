/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_insumousuario", uniqueConstraints=@UniqueConstraint(columnNames={"ins_inscodigo", "ins_usucodigo"}, name="uk_insumousuario"))
public class InsumoUsuario  implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="ins_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Insumo é um campo obrigatório")
    @JoinColumn (name="ins_inscodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumousuario_insumo")) private Insumo insumo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="ins_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumousuario_usuario")) private Usuario usuario;

    public InsumoUsuario() {
    }

    public InsumoUsuario(Insumo insumo, Usuario usuario) {
        this.insumo = insumo;
        this.usuario = usuario;
    }
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }
    
    public Insumo getInsumo() {
        return insumo;
    }

    public void setInsumo(Insumo insumo) {
        this.insumo = insumo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final InsumoUsuario other = (InsumoUsuario) obj;
       
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.insumo, other.insumo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    } 

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.insumo);
        hash = 41 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public String toString() {
        return "Insumo{" + "codigo=" + codigo + ", insumo=" + insumo + '}';
    }
    
    public Insumo getMainResource() {
        return insumo;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
