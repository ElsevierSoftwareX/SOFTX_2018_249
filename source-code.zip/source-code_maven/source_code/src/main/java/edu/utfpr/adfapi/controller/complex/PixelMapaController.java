
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.Mapa;
import edu.utfpr.adfapi.model.PixelMapa;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/pixelmapa")
public class PixelMapaController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<Mapa> depdao;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new PixelMapa());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new PixelMapa(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes(MediaType.APPLICATION_JSON)
    public void create(PixelMapa entity) {
        if (entity.getMapa() != null) {
            if (entity.getMapa().getCodigo() != null) {
                Mapa dependency = depdao.find(entity.getMapa().getCodigo(), new Mapa());
                entity.setMapa(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(PixelMapa entity) {
        if (entity.getMapa() != null) {
            if (entity.getMapa().getCodigo() != null) {
                Mapa dependency = depdao.find(entity.getMapa().getCodigo(), new Mapa());
                entity.setMapa(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new PixelMapa(), codigo);
    }
}
