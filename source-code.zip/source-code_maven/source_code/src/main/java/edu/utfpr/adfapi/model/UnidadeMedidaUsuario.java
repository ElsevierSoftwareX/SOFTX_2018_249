/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_unidademedidausuario", uniqueConstraints=@UniqueConstraint(columnNames={"uni_usucodigo", "uni_unicodigo"}, name="uk_unidademedidausuario"))
public class UnidadeMedidaUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="uni_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UnidadeMedida é um campo obrigatório")
    @JoinColumn (name="uni_unicodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_unidademedidausuario_unidademedida")) 
    private UnidadeMedida unidadeMedida;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="uni_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_nidademedidausuario_usuario")) 
    private Usuario usuario;


    public UnidadeMedidaUsuario() {
    }

    public UnidadeMedidaUsuario(UnidadeMedida unidadeMedida, Usuario usuario) {
        this.unidadeMedida = unidadeMedida;
        this.usuario = usuario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public UnidadeMedida getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setUnidadeMedida(UnidadeMedida unidademedida) {
        this.unidadeMedida = unidademedida;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UnidadeMedidaUsuario other = (UnidadeMedidaUsuario) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.unidadeMedida, other.unidadeMedida)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.unidadeMedida);
        hash = 59 * hash + Objects.hashCode(this.usuario);
        return hash;
    } 
    
    public UnidadeMedida getMainResource() {
        return unidadeMedida;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
