
package edu.utfpr.adfapi.controller;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.BeanValidator;
import edu.utfpr.adfapi.auth.JWTSigner;
import edu.utfpr.adfapi.model.Usuario;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.dao.GenericPublicDAO;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.persistence.JoinColumn;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jasse
 * @param <E>
 * @param <A>
 */
public class GenericPublicController<E, A>{

    @Inject
    private Result result;
    @Inject
    private GenericPublicDAO<E, A> dao;
    @Inject
    private GenericSimpleDAO<Usuario> udao;
    @Inject
    BeanValidator validator;
    @Inject
    private JWTSigner jwts;
    @Inject
    private HttpServletRequest req;

    public void get(A association) {
        List <E> list = dao.findAllByUser(association, getUserFromToken());
        if (list.isEmpty()) {
            this.response(404, null, "all");
        } else {
            result.use(Results.json()).withoutRoot().from(list).include(fields(list.get(0).getClass())).serialize(); //.include(fields(entity)).serialize();
        }
    }

    public void get(String value, E entity) {
        List<E> list = dao.findAllByDescricao(value, (Class<E>) entity.getClass());
        
        if (list == null) {
            this.response(404, entity, "all");
        } else {
            result.use(Results.json()).withoutRoot().from(list).include(fields(entity)).serialize();
        }
    }

    public void get(A association, E entity, Long codigo) {
        entity = dao.find(association, codigo, getUserFromToken());
        if (entity == null) {
            response(404, entity, "single");
        } else {
            if (!(Objects.equals(getUserFromToken().getCodigo(), userCodigo(entity)))) {
                this.response(403, entity, "");
            } else {
                this.response(200, entity, "entity"); //"Recurso sem usuario associado"
            }
        }
    }

    public void post(E entity, A association, Long codigo) {// codigo=entity.getCodigo
        if (codigo != null) {
            response(400, entity, "nothere");//Codigo nao permitido aqui
            return;
        } 

        String flag = dao.validateDepsUser(entity, getUserFromToken());
    
        if(!flag.equals("true")){
            response(403, entity, flag);
        } 
        else
        if (entity == null) {
            this.response(400, entity, "nullentity");
        } 
        else {
            entity = setDataCadastro(entity);
            Inspector insp = new Inspector(entity);
            if (!insp.getDependencyProblems(entity).isEmpty()) {
                response(400, entity, "dependencies");
                return;
            }
            if (validator.temErros(entity)) {
                response(400, entity, "validation"); //Bad request       
            } else {
                try {
                    E other = (E) entity.getClass().newInstance();
                    entity = dao.create(entity, association);
                    if(entity==null){
                        response(409, other, "");
                    }else
                    response(201, entity, ""); //Recurso criado

                } catch (Exception e) { //Ocorreu uma excepcao por alguma razao
                    exception(e);            
                }
            }
        }
    }

    public void put(E entity, A association, Long codigo) {// the entity, its ID (entity.getCodigo)

        if (codigo == null) {
            response(400, entity, "nocode");//Codigo nao permitido aqui
            return;
        }
        String flag= dao.validateDepsUser(entity, getUserFromToken());

        if(!flag.equals("true")){
            response(403, entity, flag);
        }
        else {
            try {
                E existingEntity = dao.find(association, codigo, getUserFromToken());
                if (existingEntity == null) {
                    response(404, entity, "single");
                    return;
                }
                if (dao.inUseEntity(association, existingEntity)) {
                    response(409, entity, "inuse");
                    return;
                }
                entity = setDataCadastro(entity, existingEntity);
                Inspector insp = new Inspector(entity);
                if (!insp.getDependencyProblems(entity).isEmpty()) {
                    response(400, entity, "dependencies");
                    return;
                }
            } catch (NoSuchMethodException e) {
                exception(e);
            }
        }
        if (validator.temErros(entity)) {
            response(400, entity, "validation"); //Bad request       
        } else {
            try {
                E other = (E) entity.getClass().newInstance();
                entity = dao.update(entity, association);
                if (entity == null) {
                    response(409, other, "");
                } else {
                    response(200, entity, "entity"); //Recurso atualizado
                }
            } catch (Exception e) { //Ocorreu uma excepcao por alguma razao
                exception(e);
            }
        }
    }

    public void delete(E entity, A association, Long codigo) {
        entity = dao.find(association, codigo, getUserFromToken());
        if (entity == null) {
            response(404, entity, "single");
        }
        else{
            Long user = null;
            Inspector insp = new Inspector(entity);
            if (insp.hasUser()) {
                user = userCodigo(entity);
            }
            if (user == null) {//Provavelmente nunca irá acontecer
                this.response(400, entity, "nouser"); //"Recurso sem usuario associado"    
            } else if (!(Objects.equals(this.getUserFromToken().getCodigo(), user))) {
                this.response(403, entity, "");
            } else {
                try {
                    dao.delete(entity, association);
                    this.response(200, entity, "delete");
                } catch (Exception e) {
                    this.response(500, entity, "");
                }
            }
        }
    }

    private String unique(String key) {
        for (int i = 0; i < key.length(); i++) {
            if (key.charAt(i) == '(') {
                return key.substring(i - 1, key.length() - 15);
            }
        }
        return key;
    }

    private String foreignKey(String key) {
        for (int i = 0; i < key.length(); i++) {
            if (key.charAt(i) == '(') {
                return key.substring(i - 1, key.length() - 1);
            }
        }
        return key;
    }

    private void exception(Exception e) {
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
        String message = "";
        for (Throwable t = e.getCause(); t != null; t = t.getCause()) {
            String[] cases = {"unique constraint", "foreign key constraint"};

            int i;
            for (i = 0; i < cases.length; i++) {
                if (t.toString().contains(cases[i])) {
                    break;
                }
            }

            switch (i) {
                case 0: {
                    message = "Chave duplicada: " + unique(t.toString()) + "ja existe";
                    break;
                }

                case 1: {
                    message = "Chave ausente: " + this.foreignKey(t.toString());
                    message = message.replace("is not present in table", "nao esta presente na tabela");
                    message = message.replace("tb_", "");
                    break;
                }
                default: {
                }
            }
        }
        if ("".equals(message)) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            message = e.getMessage();
        }
        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", message)).serialize();
    }

    public void response(int code, E entity, String type) {
        SimpleMessage message = new SimpleMessage("", "");
        switch (code) {
            case 200: {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                if (type.equalsIgnoreCase("delete")) {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Recurso removido")).serialize();
                } else {
                    if (type.equalsIgnoreCase("entity")) {
                        result.use(Results.json()).withoutRoot().from(entity).include(fields(entity)).serialize();
                    } else {
                        result.use(Results.json()).withoutRoot().from("Opcao errada").serialize();
                    }
                }
                break;
            }
            case 201: {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
                result.use(Results.json()).withoutRoot().from(entity).include(fields(entity)).serialize();
                break;
            }
            case 400: {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                if (entity == null) {
                    message = new SimpleMessage("null", "Objeto nulo");
                }
                if (type.equalsIgnoreCase("nocode")) {
                    message = new SimpleMessage("codigo", "Recurso sem codigo associado");
                }
                if (type.equalsIgnoreCase("nouser")) {
                    message = new SimpleMessage("usuario", "Recurso sem usuario associado");
                }
                if (type.equalsIgnoreCase("nothere")) {
                    message = new SimpleMessage("codigo", "Chave <codigo> nao permitida");
                }
                if(type.equalsIgnoreCase("dependencies")){
                    result.use(Results.json()).withoutRoot().from(new Inspector(entity).getDependencyProblems(entity)).serialize();
                }
                else
                if (type.equalsIgnoreCase("validation")) {
                    result.use(Results.json()).withoutRoot().from(validator.getErros(entity)).serialize();
                } else {
                    result.use(Results.json()).withoutRoot().from(message).serialize();
                }
                break;
            }
            case 403: {// Só se tiver autorização pode
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                if(!type.equalsIgnoreCase("")) 
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage(type, type+" associado a outro usuario ou não existente")).serialize();
                else result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissao", "Recurso associado a outro usuario")).serialize();
                break;
            }
            case 404: {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                if (type.equalsIgnoreCase("single")) {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
                } else {
                    if (type.equalsIgnoreCase("all")) {
                        result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
                    }
                }
                break;
            }
            case 409: {// Só se tiver autorização pode
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CONFLICT);
                if(type.equalsIgnoreCase("inuse")){
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage(entity.getClass().getSimpleName(), "Recurso em uso por outro usuario")).serialize();
                }
                else{
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage(entity.getClass().getSimpleName(), "Recurso ja existe")).serialize();
                }
                break;
            }
            case 500: {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage(entity.getClass().getSimpleName(), "A API nao pode efetuar a operacao")).serialize();
            }
        }
    }

    private String[] fields(E entity) {
        String[] found = new String[10];

        int i = 0;
        for (Field field : entity.getClass().getDeclaredFields()) {
            JoinColumn joinColumn = field.getAnnotation(JoinColumn.class);
            if (joinColumn != null) {
                found[i++] = field.getName();
            }
        }

        String[] fields = new String[i];
        for (int j = 0; j < i; j++) {
            fields[j] = found[j];
        }
        return fields;
    }
    
    private String[] fields(Class type) {
        String[] found = new String[10];

        int i = 0;
        for (Field field : type.getDeclaredFields()) {
            JoinColumn joinColumn = field.getAnnotation(JoinColumn.class);
            if (joinColumn != null) {
                found[i++] = field.getName();
            }
        }

        String[] fields = new String[i];
        for (int j = 0; j < i; j++) {
            fields[j] = found[j];
        }
        return fields;
    }

    public Usuario getUserFromToken() {
        try{
            return udao.find(Long.parseLong(req.getHeader("Autorizante")), Usuario.class);
        }
        catch(Exception e){
            return udao.find(jwts.getUserId(req.getHeader("Authorization")), Usuario.class);
        }      
    }
    
    private Long userCodigo(E entity) {
        if (entity == null) {
            return null;
        }
        try {
            Method getUser = entity.getClass().getMethod("getUsuario", null);
            Usuario usuario = ((Usuario) getUser.invoke(entity, null));
            if (usuario == null) {
                return null;
            }
            return usuario.getCodigo();
        } catch (NoSuchMethodException e) {
            return null;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | SecurityException e) {
            Logger.getLogger(GenericPublicController.class.getName()).log(Level.SEVERE, null, e);
        }
        return null;
    }
    
    private E setDataCadastro(E entity) {
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (field.getName().equalsIgnoreCase("dataCadastro")) {
                Inspector insp = new Inspector(entity);
                Method setDataCadastro = insp.getSetMethod("dataCadastro");
                try {
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
                    setDataCadastro.invoke(entity, dateFormat.parse(dateFormat.format(Calendar.getInstance().getTime())));
                    return entity;
                } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | ParseException ex) {
                    Logger.getLogger(GenericPublicController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return entity;
    }
    
    private E setDataCadastro(E entity, E source) {
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (field.getName().equalsIgnoreCase("dataCadastro")) {
                Inspector insp = new Inspector(entity);
                Method setDataCadastro = insp.getSetMethod("dataCadastro");
                Method getDataCadastro = insp.getGetMethod("dataCadastro");
                try {
                    setDataCadastro.invoke(entity, getDataCadastro.invoke(source, null));
                    return entity;
                } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    Logger.getLogger(GenericPublicController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return entity;
    }
}
