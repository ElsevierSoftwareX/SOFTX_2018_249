
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_noticia", uniqueConstraints=@UniqueConstraint(columnNames={"not_descricao", "not_catcodigo", "not_usucodigo"}, name="uk_noticia"))
public class Noticia implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="not_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="not_cabecalho", length=100, nullable=false) @NotNull (message="Cabecalho é um campo obrigatório") private String cabecalho;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="not_descricao", length=100, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_datacadastro", nullable=true) private Date dataCadastro;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_datainiciopublicacao", nullable=true) private Date inicioPublicacao;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_datafimpublicacao", nullable=true) private Date fimPublicacao;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="not_linknoticia", length=100, nullable=true) private String linkNoticia;
    @Transient @Temporal(TemporalType.TIMESTAMP) private Date dataAcesso;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Categoria é um campo obrigatório")
    @JoinColumn (name="not_catcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_noticia_categoria")) 
    private CategoriaNoticia categoria;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório") 
    @JoinColumn (name="not_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_noticia_usuario"))
    private Usuario usuario;

    public Noticia() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getCabecalho() {
        return cabecalho;
    }

    public void setCabecalho(String cabecalho) {
        this.cabecalho = cabecalho;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getInicioPublicacao() {
        return inicioPublicacao;
    }

    public void setInicioPublicacao(Date inicioPublicacao) {
        this.inicioPublicacao = inicioPublicacao;
    }

    public Date getFimPublicacao() {
        return fimPublicacao;
    }

    public void setFimPublicacao(Date fimPublicacao) {
        this.fimPublicacao = fimPublicacao;
    }

    public String getLinkNoticia() {
        return linkNoticia;
    }

    public void setLinkNoticia(String linkNoticia) {
        this.linkNoticia = linkNoticia;
    }

    public CategoriaNoticia getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaNoticia categoria) {
        this.categoria = categoria;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public Date getDataAcesso() {
        return dataAcesso;
    }

    public void setDataAcesso(Date dataAcesso) {
        this.dataAcesso = dataAcesso;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.descricao);
        hash = 83 * hash + Objects.hashCode(this.categoria);
        hash = 83 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Noticia other = (Noticia) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.categoria, other.categoria)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }   
}
