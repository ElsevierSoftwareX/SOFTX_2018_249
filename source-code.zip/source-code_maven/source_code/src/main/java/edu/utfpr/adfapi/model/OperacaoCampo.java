/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_operacaocampo", uniqueConstraints=@UniqueConstraint(columnNames={"ope_descricao", "ope_datainicio", "ope_usucodigo", "ope_tipcodigo", "ope_safcodigo", "ope_arecodigo"}, name="uk_operacaocampo"))
public class OperacaoCampo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="ope_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ope_descricao", length=100, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Temporal(TemporalType.TIMESTAMP) @Column (name="ope_datainicio", nullable=true) private Date inicio;
    @Temporal(TemporalType.TIMESTAMP) @Column (name="ope_datafim", nullable=true) private Date fim;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ope_obs", length=100) private String obs;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn (name="ope_arecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_operacaocampo_area")) private Area area;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="TipoOperacao é um campo obrigatório")
    @JoinColumn (name="ope_tipcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_operacaocampo_tipooperacao")) 
    private TipoOperacao tipoOperacao;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Safra é um campo obrigatório")
    @JoinColumn (name="ope_safcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_operacaocampo_safra")) private Safra safra; 
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="ope_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_operacaocampo_usuario")) private Usuario usuario;
    


    public OperacaoCampo() {
    }

    public OperacaoCampo(String descricao, Date inicio, Date fim, Area area, TipoOperacao tipoOperacao, Safra safra, String obs, Usuario usuario) {
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.area = area;
        this.tipoOperacao = tipoOperacao;
        this.safra = safra;
        this.obs = obs;
        this.usuario = usuario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFim() {
        return fim;
    }

    public void setFim(Date fim) {
        this.fim = fim;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public TipoOperacao getTipoOperacao() {
        return tipoOperacao;
    }

    public void setTipoOperacao(TipoOperacao tipoOperacao) {
        this.tipoOperacao = tipoOperacao;
    }

    public Safra getSafra() {
        return safra;
    }

    public void setSafra(Safra safra) {
        this.safra = safra;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OperacaoCampo other = (OperacaoCampo) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        if (!Objects.equals(this.safra, other.safra)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.descricao);
        hash = 53 * hash + Objects.hashCode(this.area);
        hash = 53 * hash + Objects.hashCode(this.safra);
        hash = 53 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
