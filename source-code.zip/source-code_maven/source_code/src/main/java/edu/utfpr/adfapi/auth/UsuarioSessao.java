/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;


import edu.utfpr.adfapi.model.Usuario;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author Rodrigo
 */
@SessionScoped
public class UsuarioSessao implements Serializable {

    private Usuario usuario;
   // @Inject
   // private HttpServletRequest request;
    
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public boolean isLogado() {
        return usuario != null;
    }

    public void logoff() {
        setUsuario(null);
        //request.getSession().invalidate();
    }

}
