
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.Veiculo;
import edu.utfpr.adfapi.model.VeiculoUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/veiculo")
public class VeiculoController {

    @Inject
    private GenericPublicController<Veiculo, VeiculoUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new VeiculoUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new Veiculo());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new VeiculoUsuario(), new Veiculo(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Veiculo entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new VeiculoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Veiculo entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new VeiculoUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Veiculo(), new VeiculoUsuario(), codigo);
    }
}
