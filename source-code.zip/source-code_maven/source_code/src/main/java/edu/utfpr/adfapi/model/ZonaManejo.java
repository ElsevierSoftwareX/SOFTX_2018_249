/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_zonamanejo")
public class ZonaManejo implements Serializable {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="zon_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="zon_descricao", length=100, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="zon_nometabela", length=30, nullable=false) @NotNull (message="NomeTabela é um campo obrigatório") private String nomeTabela;
    @Column (name="zon_nclasses", columnDefinition="int", nullable=false) @NotNull (message="NumeroClasses é um campo obrigatório") private int numeroClasses;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column (name="zon_metodo", length=60, nullable=false) @NotNull (message="Metodo é um campo obrigatório") private String metodo;   
    @Temporal(TemporalType.DATE) @Column (name="zon_data", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @Column (name="zon_niteracoes", columnDefinition="int") private int numeroIteracoes;
    @Column (name="zon_expoente", columnDefinition="float") private float expoente;
    @Column (name="zon_erro", columnDefinition="float") private float erro;
    @Column (name="zon_fpi", columnDefinition="float") private float fpi;
    @Column (name="zon_mpe", columnDefinition="float") private float mpe;
    //@Size(min=1, message ="Mínimo um mapa")@NotNull(message="Mapas é um campo obrigatório")
    @Transient private List<Mapa> mapas;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="zon_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_zonamanejo_usuario")) private Usuario usuario; 
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn(name="zon_arecodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_zonamanejo_area")) private Area area;

    public ZonaManejo() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNomeTabela() {
        return nomeTabela;
    }

    public void setNomeTabela(String nomeTabela) {
        this.nomeTabela = nomeTabela;
    }

    public int getNumeroClasses() {
        return numeroClasses;
    }

    public void setNumeroClasses(int numeroClasses) {
        this.numeroClasses = numeroClasses;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date data) {
        this.dataCadastro = data;
    }

    public int getNumeroIteracoes() {
        return numeroIteracoes;
    }

    public void setNumeroIteracoes(int numeroIteracoes) {
        this.numeroIteracoes = numeroIteracoes;
    }

    public float getExpoente() {
        return expoente;
    }

    public void setExpoente(float expoente) {
        this.expoente = expoente;
    }

    public float getErro() {
        return erro;
    }

    public void setErro(float erro) {
        this.erro = erro;
    }

    public float getFpi() {
        return fpi;
    }

    public void setFpi(float fpi) {
        this.fpi = fpi;
    }

    public float getMpe() {
        return mpe;
    }

    public void setMpe(float mpe) {
        this.mpe = mpe;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ZonaManejo other = (ZonaManejo) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.descricao);
        hash = 71 * hash + Objects.hashCode(this.nomeTabela);
        hash = 71 * hash + this.numeroClasses;
        hash = 71 * hash + Objects.hashCode(this.metodo);
        hash = 71 * hash + Objects.hashCode(this.usuario);
        hash = 71 * hash + Objects.hashCode(this.area);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }

    public List<Mapa> getMapas() {
        return mapas;
    }

    public void setMapas(List<Mapa> mapas) {
        this.mapas = mapas;
    }
    
    /*public void setMapa(Long codigo){
        mapas.add(codigo);
    }*/
    
}
