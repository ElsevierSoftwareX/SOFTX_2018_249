/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

/**
 *
 * @author UTFPR
 */
import com.vividsolutions.jts.geom.Point;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * A basic location based entity with just two attributes: location and description.
 * One named query has been defined to retrieve all entries.
 * 
 * While creating location instances, we will be setting the id by generating random UUIDs.
 * However we cannot use UUID as type for id, because it doesn't work with postgis.
 * I haven't resolved this issue yet so for now, we're making id a String.
 * 
 * @author Toaster
 * 
 */
@Entity
@Table(name="tb_location")
@NamedQuery(name = "Location.findAll", query = "from Location l")
public class Location implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) private String id;    
    private String description;    
    @Column(columnDefinition = "geometry(Point,4326)") private Point location;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "de.demo.entities.Location[ id=" + id + " ]";
    }
    
}
