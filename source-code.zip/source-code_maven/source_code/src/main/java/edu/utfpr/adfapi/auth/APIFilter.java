/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

/**
 *
 * @author Jasse
 */
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.SimpleMessage;
import java.io.*;  
import java.util.regex.Pattern;
import javax.inject.Inject;
import javax.servlet.*;  
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
    
    @WebFilter(filterName = "filtro1")
    public class APIFilter implements Filter{  
        
        @Override
        public void init(FilterConfig arg0) throws ServletException {
        }  
      
        @Override
        public void doFilter(ServletRequest request, ServletResponse response,  FilterChain chain) throws IOException, ServletException {  
            JSONObject json;
            String method= ((HttpServletRequest)request).getMethod();
   
            
            /*
            
            final ClassLoader loader = Thread.currentThread().getContextClassLoader();
            Class type=null;
            
            String classe = getObjeto((HttpServletRequest)request);
            for (final ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClasses()) {
                if (info.getName().startsWith("edu.utfpr.adfapi.model.")) {
                    final Class<?> clazz = info.load();
                    if(clazz.getSimpleName().equalsIgnoreCase(classe)){
                        JOptionPane.showMessageDialog(null, "Found: " + clazz.getSimpleName());
                        type=clazz;
                        //Object myBean = gson.fromJson(reader, Cultura.class);
                        //JOptionPane.showMessageDialog(null, "Cultura: "+gson.fromJson(reader, Cultura.class));
                        //return;
                    }
                    //JOptionPane.showMessageDialog(null, "AI: " + clazz.getSimpleName());
                }
                //chain.doFilter(request, response);
                //return;
            }
            BufferedReader reader = request.getReader();
            Gson gson = new Gson();
            Object mBean = gson.fromJson(reader, type);//Cultura.class);
            JOptionPane.showMessageDialog(null, "Cultura: "+mBean);    */
            
            //JOptionPane.showMessageDialog(null, "Found: "+this.getObjeto((HttpServletRequest)request));
            String objeto = getObjeto((HttpServletRequest)request);
            
            if(objeto.equals("login")){
                chain.doFilter(request, response);
                return;
            }
            
            if(objeto.equals("index.html")){
                //((HttpServletResponse)response).sendRedirect("/ADBAPI/doc.html");
        //return;
                chain.doFilter(request, response);
                return;
            }

            if(!(method.equalsIgnoreCase("Get")||method.equalsIgnoreCase("Post")||method.equalsIgnoreCase("Put")||method.equalsIgnoreCase("Delete"))){
   
                SimpleMessage sm=new SimpleMessage("Erro","Metodo nao permitido. Use Post, Get, Put ou Delete");
                json = new JSONObject(sm);
                HttpServletResponse res=(HttpServletResponse)response;
                res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
                res.setContentType("application/json");
                json.remove("severity");

                json.write(res.getWriter());
                return;
            }
       
            if(!"application/json".equals(request.getContentType())){
                SimpleMessage sm=new SimpleMessage("Erro","Formato nao suportado");
                json = new JSONObject(sm);
   
                HttpServletResponse res=(HttpServletResponse)response;
                res.setStatus(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE);
                res.setContentType("application/json");
                json.remove("severity");
                json.write(res.getWriter());
                
                return;
            }

            try{
                chain.doFilter(request, response);
            }
            catch(IOException | ServletException e){
                HttpServletResponse res=(HttpServletResponse)response;
                res.setContentType("application/json");
            }
        }  
        
        private String getObjeto(HttpServletRequest req){
            String[] objetos = req.getRequestURI().split (Pattern.quote ("/"));         
            try{
                return objetos[2];
            }
            catch(ArrayIndexOutOfBoundsException e){
                return "login";
            }
        }
        
        @Override
        public void destroy() {
        }  
    }  