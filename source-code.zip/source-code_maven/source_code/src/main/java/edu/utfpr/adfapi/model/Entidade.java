/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_entidadeclassificadora", uniqueConstraints=@UniqueConstraint(columnNames={"ent_descricao", "ent_cidade"}, name="uk_entidadeclassificadora"))
public class Entidade implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ent_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ent_descricao", length=100, nullable=false) @NotNull (message="Descrição é um campo obrigatório") private String descricao;
    @Size(max=3, message= "Maximo 3 carateres")
    @Column(name="ent_estado", length=3, nullable=true) private String estado;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ent_cidade", length=100, nullable=false) @NotNull (message="Cidade é um campo obrigatório") private String cidade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull(message="Usuario é um campo obrigatório")
    @JoinColumn (name="ent_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_entidadeclassificadora_usuario"))
    private Usuario usuario;

    public Entidade() {
    }

    public Entidade(String descricao, String estado, String cidade, Usuario usuario) {
        this.descricao = descricao;
        this.estado = estado;
        this.cidade = cidade;
        this.usuario = usuario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Entidade other = (Entidade) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.cidade, other.cidade)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }  

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + Objects.hashCode(this.descricao);
        hash = 23 * hash + Objects.hashCode(this.cidade);
        hash = 23 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
