
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.Variedade;
import edu.utfpr.adfapi.model.VariedadeUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/variedade")
public class VariedadeController {

    @Inject
    private GenericPublicController<Variedade, VariedadeUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new VariedadeUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new Variedade());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new VariedadeUsuario(), new Variedade(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_FORM_URLENCODED})
    public void post(Variedade entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new VariedadeUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes("application/json")
    public void put(Variedade entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new VariedadeUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Variedade(), new VariedadeUsuario(), codigo);
    }
}
