
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.auth.BeanValidator;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.Mapa;
import edu.utfpr.adfapi.model.MapaZonaManejo;
import edu.utfpr.adfapi.model.ZonaManejo;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/zonamanejo")
public class ZonaManejoController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<Mapa> mdao;
    @Inject
    private GenericComplexDAO<MapaZonaManejo> adao;
    @Inject
    private GenericComplexDAO<ZonaManejo> dao;
    @Inject
    private BeanValidator validator;
    private List<Mapa> mapas = new ArrayList();
    @Inject
    private Result result;

    @APIRestrito
    @Get("")
    public void get() {
        List<ZonaManejo> entities = dao.findAllByUser(controller.getUserFromToken().getCodigo(), new ZonaManejo());
        List<Mapa> mapas = new ArrayList<>();

        if (entities == null) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
        } else {
            for(int i=0; i< entities.size(); i++){
                List<MapaZonaManejo> mzms = adao.findByField(entities.get(i).getCodigo(), new MapaZonaManejo(), "map_zoncodigo");
                for (MapaZonaManejo mzm : mzms) {
                    mapas.add(mzm.getMapa());
                }
                entities.get(i).setMapas(mapas);
            }
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            this.result.use(Results.json()).withoutRoot().from(entities).include("mapas", "mapas.amostra", "area", "usuario").serialize();
        }
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        ZonaManejo entity = dao.find(codigo, new ZonaManejo());
        List<Mapa> mapas = new ArrayList<>();

        if (entity == null) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
        } else {
            List<MapaZonaManejo> mzms = adao.findByField(codigo, new MapaZonaManejo(), "map_zoncodigo");

            for (MapaZonaManejo mzm : mzms) {
                mapas.add(mzm.getMapa());
            }
            entity.setMapas(mapas);
            
            if (!Objects.equals(entity.getUsuario(), controller.getUserFromToken())) {
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("ZonaManejo", "Recurso associado a outro usuario")).serialize();
            }
            else{
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                this.result.use(Results.json()).withoutRoot().from(entity).include("mapas", "mapas.amostra", "area", "usuario").serialize();
            }

        }
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(ZonaManejo entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        List<Mapa> mapas = new ArrayList<>();
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
        String flag = dao.validateDepsUser(entity, controller.getUserFromToken());
        controller.setDataCadastro(entity);

        if (!flag.equals("true")) {
            if (!flag.equalsIgnoreCase("")) {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage(flag, flag + " associado a outro usuario ou não existente")).serialize();
                } else {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissao", "Recurso associado a outro usuario")).serialize();
                }
        }else
        if(validator.temErros(entity)){
            result.use(Results.json()).withoutRoot().from(validator.getErros(entity)).serialize();
        }
        else
        if(entity.getMapas()==null){
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("mapas", "Lista de mapas é obrigatório")).serialize();
        }
        else
        if(entity.getMapas().isEmpty()){
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("mapas", "Forneça pelo menos um mapa")).serialize();
        }
        else{
            for (Mapa mapa : entity.getMapas()) {
                Mapa other = mdao.find(mapa.getCodigo(), new Mapa());
                if (other == null) {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado. Verifique seus mapas")).serialize();
                    return;
                }
                if (!Objects.equals(entity.getUsuario(), controller.getUserFromToken())) {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Mapa.codigo", "Formato errado. Verifique os códigos dos mapas")).serialize();
                    return;
                }
                mapas.add(mapa);
            }

            try {
                entity = dao.create(entity);
                for (Mapa mapa : mapas) {
                    MapaZonaManejo association = new MapaZonaManejo();
                    association.setMapa(mapa);
                    association.setZonaManejo(entity);
                    adao.create(association);
                }
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
                this.result.use(Results.json()).withoutRoot().from(entity).include("mapas", "area", "usuario").serialize();
            } catch (Exception e) {
                controller.exception(e);
            }

        }
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(ZonaManejo entity) {
        
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
        if(entity==null){
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("null", "Lista de mapas é obrigatório")).serialize();
            return;
        }
        String flag = dao.validateDepsUser(entity, controller.getUserFromToken());

        if (!flag.equals("true")) {
            if (!flag.equalsIgnoreCase("")) {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage(flag, flag + " associado a outro usuario ou não existente")).serialize();
                } else {
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissao", "Recurso associado a outro usuario")).serialize();
                }
            return;
        }
        if(validator.temErros(entity)){
            result.use(Results.json()).withoutRoot().from(validator.getErros(entity)).serialize();
            return;
        }
        if(entity.getCodigo()==null){
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("codigo", "Recurso sem usuário associado")).serialize();
            return;
        }
        ZonaManejo existing = dao.find(entity.getCodigo(), new ZonaManejo());
        if(existing ==null){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
            return;
        }
        if(!Objects.equals(entity.getUsuario(), controller.getUserFromToken())){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissão", "Recurso associado a outro usuário")).serialize();
            return;
        }
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        else{         
            try {
                entity.setDataCadastro(existing.getDataCadastro());
                entity = dao.update(entity);
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
                this.result.use(Results.json()).withoutRoot().from(entity).include("mapas", "area", "usuario").serialize();
            } catch (Exception e) {
                controller.exception(e);
            }

        }
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        ZonaManejo entity = dao.find(codigo, new ZonaManejo());
        if (!Objects.equals(entity.getUsuario(), controller.getUserFromToken())) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissão", "Recurso associado a outro usuário")).serialize();
            return;
        }
        List<MapaZonaManejo> mzms = adao.findByField(codigo, new MapaZonaManejo(), "map_zoncodigo");
        try {
            for (MapaZonaManejo mzm : mzms) {
                adao.delete(mzm);
            }
            dao.delete(entity);
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Recurso removido")).serialize();
        } catch (Exception ex) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            this.result.use(Results.json()).withoutRoot().from(entity).include("Erro", "A API não pode executar a operação").serialize();
        }
    }
    
}
