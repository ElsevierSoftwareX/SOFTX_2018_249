
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.UnidadeMedida;
import edu.utfpr.adfapi.model.UnidadeMedidaUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/unidademedida")
public class UnidadeMedidaController {

    @Inject
    private GenericPublicController<UnidadeMedida, UnidadeMedidaUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new UnidadeMedidaUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new UnidadeMedida());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new UnidadeMedidaUsuario(), new UnidadeMedida(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(UnidadeMedida entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new UnidadeMedidaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(UnidadeMedida entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new UnidadeMedidaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new UnidadeMedida(), new UnidadeMedidaUsuario(), codigo);
    }
}
