
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.TipoOcorrencia;
import edu.utfpr.adfapi.model.TipoOcorrenciaUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/tipoocorrencia")
public class TipoOcorrenciaController {

    @Inject
    private GenericPublicController<TipoOcorrencia, TipoOcorrenciaUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new TipoOcorrenciaUsuario());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new TipoOcorrenciaUsuario(), new TipoOcorrencia(), codigo);
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new TipoOcorrencia());
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(TipoOcorrencia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new TipoOcorrenciaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(TipoOcorrencia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new TipoOcorrenciaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new TipoOcorrencia(), new TipoOcorrenciaUsuario(), codigo);
    }
}
