/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.startup;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.Restrito;
import edu.utfpr.adfapi.auth.UsuarioSessao;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rodrigo
 */
@Controller
public class DefaultController {
    @Inject
    private Result result;
    
    @Inject
    private UsuarioSessao sessao;
    
    //@Restrito
    //@Path("/")
    public void index() {
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Nenhuma URI","Erro não classificado")).serialize();
        //result.include("sessao", sessao);
    }
    
    @Path("/doc")
    public void doc() {
        
    }
    
    //@Path("/error")
    public void error(){
        result.include("sessao", sessao);
    }
    
    @Get("/export.json")
    public void export(){
        
    }
    
    @Get("/export/areas.json")
    public void exportAreas(){
        //result.use(Results.json()).withoutRoot().from(areaDAO.findAll()).include("solo", "imovel").serialize();
    }
    
    @Get("/export/amostras.json")
    public void exportAmostras(){
        //result.use(Results.json()).withoutRoot().from(amostraDAO.findAll()).include("pontos").serialize();
    }
    
    @Get("/export/grades.json")
    public void exportGrades(){
        //result.use(Results.json()).withoutRoot().from(gaDAO.findAll()).include("pontosAmostrais").serialize();
    }
    
}
