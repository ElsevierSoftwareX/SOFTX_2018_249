
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_safra", uniqueConstraints=@UniqueConstraint(columnNames={"saf_descricao", "saf_culcodigo", "saf_usucodigo"}, name="uk_safra"))
public class Safra implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="saf_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="saf_descricao", length=100, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="saf_datainicio", nullable=true) private Date inicio;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="saf_datafim", nullable=true) private Date fim;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="saf_datacadastro", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Cultura é um campo obrigatório")
    @JoinColumn (name="saf_culcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_safra_cultura")) 
    private Cultura cultura;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório") 
    @JoinColumn (name="saf_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_safra_usuario"))
    private Usuario usuario;

    public Safra() {
    }

    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFim() {
        return fim;
    }

    public void setFim(Date fim) {
        this.fim = fim;
    }

    public Cultura getCultura() {
        return cultura;
    }

    public void setCultura(Cultura cultura) {
        this.cultura = cultura;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date datacadastro) {
        this.dataCadastro = datacadastro;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Safra other = (Safra) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.inicio, other.inicio)) {
            return false;
        }
        if (!Objects.equals(this.cultura, other.cultura)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.descricao);
        hash = 53 * hash + Objects.hashCode(this.cultura);
        hash = 53 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
}
