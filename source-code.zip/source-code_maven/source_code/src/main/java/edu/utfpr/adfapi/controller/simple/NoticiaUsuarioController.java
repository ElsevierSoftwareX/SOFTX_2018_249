
package edu.utfpr.adfapi.controller.simple;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericSimpleController;
import edu.utfpr.adfapi.model.NoticiaUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/noticiausuario")
public class NoticiaUsuarioController {

    @Inject
    private GenericSimpleController<NoticiaUsuario> controller;
    
    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new NoticiaUsuario());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new NoticiaUsuario(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(NoticiaUsuario entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(NoticiaUsuario entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new NoticiaUsuario(), codigo);
    }
}
