/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth.model;

import edu.utfpr.adfapi.config.StringCharConverter;
import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_permissaorecurso", uniqueConstraints=@UniqueConstraint(columnNames={"per_reccodigo", "per_percodigo"}, name="uk_permissaorecurso"))
public class PermissaoRecurso implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="per_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) 
    @JoinColumn (name="per_reccodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_permissaorecurso_recurso")) 
    @NotNull (message="Recurso é um campo obrigatório")  private Recurso recurso;
    @ManyToOne(fetch = FetchType.EAGER) 
    @JoinColumn (name="per_percodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_permissaorecurso_permissao")) 
    @NotNull (message="Permissão é um campo obrigatório") private Permissao permissao;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="per_select", length=1, nullable=false) @NotNull (message="Get é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String get;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="per_update", length=1, nullable=false) @NotNull (message="Put é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String put;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="per_insert", length=1, nullable=false) @NotNull (message="Post é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String post;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="per_delete", length=1, nullable=false) @NotNull (message="Delete é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String delete;

    public PermissaoRecurso() {
    }

    public PermissaoRecurso(Recurso recurso, Permissao permissao, String get, String put, String post, String delete) {
        this.recurso = recurso;
        this.permissao = permissao;
        this.get = get;
        this.put = put;
        this.post = post;
        this.delete = delete;
    }
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Recurso getRecurso() {
        return recurso;
    }

    public void setRecurso(Recurso recurso) {
        this.recurso = recurso;
    }

    public Permissao getPermissao() {
        return permissao;
    }

    public void setPermissao(Permissao permissao) {
        this.permissao = permissao;
    }

    public String getGet() {
        return get;
    }

    public void setGet(String get) {
        this.get = get;
    }

    public String getPut() {
        return put;
    }

    public void setPut(String put) {
        this.put = put;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }

    
}
