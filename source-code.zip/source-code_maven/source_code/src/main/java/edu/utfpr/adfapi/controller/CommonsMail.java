package edu.utfpr.adfapi.controller;

import com.sun.mail.smtp.SMTPTransport;
import edu.utfpr.adfapi.model.Usuario;
import java.security.Security;
import java.util.Date;
import java.util.Properties;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import javax.mail.*;
import javax.mail.internet.*;

/**
 *
 * @author Jasse
 */
public class CommonsMail {
    public CommonsMail(){
    }

    public void enviaEmailSimples(Usuario usuario, String link) throws EmailException, MessagingException {
	//Funcional
        SimpleEmail sm = new SimpleEmail();
        sm.setHostName("smtp.gmail.com"); // o servidor SMTP para envio do e-mail
        sm.addTo(usuario.getEmail(), usuario.getNome()); //destinatário
        sm.setFrom("agriculturaldatabox@gmail.com", "Agricultural Adata Box API"); // remetente
        sm.setSubject("Recuperação de senha"); // assunto do e-mail
        sm.setMsg("Para recuperar sua senha siga o link a seguir: "+link); //conteudo do e-mail
        sm.setAuthentication("agriculturaldatabox", "boxdataagricultural");
        sm.setSmtpPort(465);
        sm.setSSL(true);
        sm.setTLS(true);
        sm.send();	         
    }
    
    public static void Send(String username, String password, String recipientEmail, String ccEmail, String title, String message) throws AddressException, MessagingException {
        Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

        Properties props = System.getProperties();
        props.setProperty("mail.smtps.host", "smtp.gmail.com");
        props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
        props.setProperty("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.port", "465");
        props.setProperty("mail.smtp.socketFactory.port", "465");
        props.setProperty("mail.smtps.auth", "true");

        props.put("mail.smtps.quitwait", "false");

        Session session = Session.getInstance(props, null);
        MimeMessage msg = new MimeMessage(session);

        // -- Set the FROM and TO fields --
        msg.setFrom(new InternetAddress(username + "@gmail.com"));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail, false));

        if (ccEmail.length() > 0) {
            msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse(ccEmail, false));
        }

        msg.setSubject(title);
        msg.setText(message, "utf-8");
        msg.setSentDate(new Date());

        SMTPTransport t = (SMTPTransport)session.getTransport("smtps");

        t.connect("smtp.gmail.com", username, password);
        t.sendMessage(msg, msg.getAllRecipients());      
        t.close();
    }
        /*
	public void enviaEmailComAnexo() throws EmailException{
		// cria o anexo 1.
		EmailAttachment anexo1 = new EmailAttachment();
		anexo1.setPath(&quot;teste/teste.txt&quot;); //caminho do arquivo (RAIZ_PROJETO/teste/teste.txt)
		anexo1.setDisposition(EmailAttachment.ATTACHMENT);
		anexo1.setDescription(&quot;Exemplo de arquivo anexo&quot;);
		anexo1.setName(&quot;teste.txt&quot;);		
		// cria o anexo 2.
		EmailAttachment anexo2 = new EmailAttachment();
		anexo2.setPath(&quot;teste/teste2.jsp&quot;); //caminho do arquivo (RAIZ_PROJETO/teste/teste2.jsp)
		anexo2.setDisposition(EmailAttachment.ATTACHMENT);
		anexo2.setDescription(&quot;Exemplo de arquivo anexo&quot;);
		anexo2.setName(&quot;teste2.jsp&quot;);		
		// configura o email
		MultiPartEmail email = new MultiPartEmail();
		email.setHostName(&quot;smtp.gmail.com&quot;); // o servidor SMTP para envio do e-mail
		email.addTo(&quot;teste@gmail.com&quot;, &quot;Guilherme&quot;); //destinatário
		email.setFrom(&quot;teste@gmail.com&quot;, &quot;Eu&quot;); // remetente
		email.setSubject(&quot;Teste -&gt; Email com anexos&quot;); // assunto do e-mail
		email.setMsg(&quot;Teste de Email utilizando commons-email&quot;); //conteudo do e-mail
		email.setAuthentication(&quot;teste&quot;, &quot;xxxxx&quot;);
		email.setSmtpPort(465);
		email.setSSL(true);
		email.setTLS(true);
		// adiciona arquivo(s) anexo(s)
		email.attach(anexo1);
		email.attach(anexo2);
		// envia o email
		email.send();
	}
	
	public void enviaEmailFormatoHtml() throws EmailException, MalformedURLException {
		HtmlEmail email = new HtmlEmail();
		// adiciona uma imagem ao corpo da mensagem e retorna seu id
		URL url = new URL(&quot;http://www.apache.org/images/asf_logo_wide.gif&quot;);
		String cid = email.embed(url, &quot;Apache logo&quot;);	
		// configura a mensagem para o formato HTML
		email.setHtmlMsg(&quot;&lt;html&gt;Logo do Apache - <img >&lt;/html&gt;&quot;);
		// configure uma mensagem alternativa caso o servidor não suporte HTML
		email.setTextMsg(&quot;Seu servidor de e-mail não suporta mensagem HTML&quot;);
		email.setHostName(&quot;smtp.gmail.com&quot;); // o servidor SMTP para envio do e-mail
		email.addTo(&quot;teste@gmail.com&quot;, &quot;Guilherme&quot;); //destinatário
		email.setFrom(&quot;teste@gmail.com&quot;, &quot;Eu&quot;); // remetente
		email.setSubject(&quot;Teste -&gt; Html Email&quot;); // assunto do e-mail
		email.setMsg(&quot;Teste de Email HTML utilizando commons-email&quot;); //conteudo do e-mail
		email.setAuthentication(&quot;teste&quot;, &quot;xxxxx&quot;);
		email.setSmtpPort(465);
		email.setSSL(true);
		email.setTLS(true);
		email.send();
	}

	public static void main(String[] args) throws EmailException, MalformedURLException {
		new CommonsMail();
	}*/
}
