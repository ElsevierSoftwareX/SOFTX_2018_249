/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_gradeamostral", uniqueConstraints=@UniqueConstraint(columnNames={"gra_descricao", "gra_tamx", "gra_tamy", "gra_arecodigo"}, name="uk_gradeamostral"))
public class GradeAmostral implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="gra_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column (name="gra_descricao", length=60, nullable=false) @NotNull(message="Descricao é um campo obrigatório") private String descricao;
    @Column (name="gra_tamx", columnDefinition="float", nullable=false) @NotNull (message="TamX é um campo obrigatório") private float tamx;
    @Column (name="gra_tamy", columnDefinition="float", nullable=false) @NotNull (message="TamY é um campo obrigatório") private float tamy;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="gra_nometabela", length=30) private String nomeTabela;
    @Temporal(TemporalType.DATE) @Column (name="gra_datacadastro", nullable=true) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="gra_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_gradeamostral_usuario")) private Usuario usuario; 
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn(name="gra_arecodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_gradeamostral_area")) private Area area;

    public GradeAmostral() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getTamx() {
        return tamx;
    }

    public void setTamx(float tamx) {
        this.tamx = tamx;
    }

    public float getTamy() {
        return tamy;
    }

    public void setTamy(float tamy) {
        this.tamy = tamy;
    }

    public String getNomeTabela() {
        return nomeTabela;
    }

    public void setNomeTabela(String nomeTabela) {
        this.nomeTabela = nomeTabela;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GradeAmostral other = (GradeAmostral) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.descricao);
        hash = 23 * hash + Float.floatToIntBits(this.tamx);
        hash = 23 * hash + Float.floatToIntBits(this.tamy);
        hash = 23 * hash + Objects.hashCode(this.usuario);
        hash = 23 * hash + Objects.hashCode(this.area);
        return hash;
    }
   
    public Long getUserCode(){
        return usuario.getCodigo();
    } 
   
}
