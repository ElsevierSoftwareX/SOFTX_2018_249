
package edu.utfpr.adfapi.controller;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.model.Classe;
import edu.utfpr.adfapi.model.Classificacao;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/classe")
public class ClasseController {

    @Inject
    private GenericSimpleDAO<Classificacao> depdao;
    @Inject
    private GenericSimpleController<Classe> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new Classe());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Classe(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Classe entity) {
        if (entity.getClassificacao() != null) {
            if (entity.getClassificacao().getCodigo() != null) {
                Classificacao dependency = depdao.find(entity.getClassificacao().getCodigo(), Classificacao.class);
                entity.setClassificacao(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Classe entity) {
        if (entity.getClassificacao() != null) {
            if (entity.getClassificacao().getCodigo() != null) {
                Classificacao dependency = depdao.find(entity.getClassificacao().getCodigo(), Classificacao.class);
                entity.setClassificacao(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Classe(), codigo);
    }
}
