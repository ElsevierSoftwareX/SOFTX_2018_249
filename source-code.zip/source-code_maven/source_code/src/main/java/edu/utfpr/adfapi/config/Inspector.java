
package edu.utfpr.adfapi.config;

import br.com.caelum.vraptor.validator.SimpleMessage;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 *
 * @author Jasse
 * @param <T>
 */
public class Inspector<T> {

    private List<Reflection> components = new ArrayList();
    private List<String> columns = new ArrayList();
    private List<String> jColumns = new ArrayList();
    private Class type;
    private T entity;

    public Inspector(Class type) {
        this.type = type;
        start();
    }

    public Inspector(T entity) {
        this.entity = entity;
        this.type = entity.getClass();
        start();
    }

    public Reflection getReflection(int pos) {
        return components.get(pos);
    }

    public Reflection getReflection(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection;
            }
        }
        return null;
    }

    public Method getGetMethod(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection.getGetMethod();
            }
        }
        return null;
    }

    public String getFieldType(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection.getField().getType().getSimpleName();
            }
        }
        return null;
    }

    private String getUserColumn(Class type) {// For complex entities using jdbc 
        List<Reflection> list = new Inspector(type).getComponents();
        for (Reflection reflection : list) {
            if (reflection.getjColumn() != null) {
                if (reflection.getjColumn().name().contains("usucodigo")) {
                    return reflection.getjColumn().name();
                }
            }
        }
        return null;
    }

    private String getColumn(Class type) {
        String result = getUserColumn(type);
        if (result != null) {
            return result;
        }
        for (Reflection reflection : components) {
            JoinColumn jColumn = reflection.getjColumn();
            if (jColumn != null) {
                return getColumn(reflection.getField().getType());
            }
        }
        return null;
    }

    public String getUserColumn() {
        return getColumn(type);
    }

    public Method getSetMethod(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection.getSetMethod();
            }
        }
        return null;
    }

    public String getFieldName(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection.getField().getName();
            }
        }
        return null;
    }

    public List<String> getColumns() {
        return columns;
    }

    public List<String> getJoinColumns() {
        return jColumns;
    }

    public List<String> getTableColumns() {
        columns.addAll(jColumns);
        columns.remove(this.getPrimaryKey());
        columns.add(this.getPrimaryKey());

        return columns;
    }

    public Object getMainResource() {
        if (entity == null) {
            return entity;
        }
        int count = 0;
        Field[] fields = new Field[2];
        for (Reflection reflection : components) {
            if (reflection.getjColumn() != null) {

                if (entity.getClass().getSimpleName().trim().toLowerCase().contains(reflection.getField().getType().getSimpleName().trim().toLowerCase())) {
                    fields[count++] = reflection.getField();

                    if (count > 1) {
                        boolean case1 = (fields[0].getName() + fields[1].getName()).equalsIgnoreCase(entity.getClass().getSimpleName()),
                                case2 = (fields[1].getName() + fields[0].getName()).equalsIgnoreCase(entity.getClass().getSimpleName());
                        if (case1 || case2) {
                            try {
                                Method getResource = (!fields[0].getName().equals("usuario")) ? getGetMethod(fields[0].getName()) : getGetMethod(fields[1].getName());
                                return getResource.invoke(entity, null);
                            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                                return null;
                            } catch (Exception e) {
                            }
                        }
                    }
                }
            }
        }
        return entity;// retorna ele mesmo se não é associativa
    }

    public List<SimpleMessage> getDependencyProblems(T entity) {//retorna erros de validacao de atributos que são classes também dentro da classe
        List<SimpleMessage> list = new ArrayList();
        int depSize = 0;
        Method getDependency = null;
        Field field = null;

        for (Reflection reflection : components) {
            if (reflection.getjColumn() != null) {
                getDependency = this.getGetMethod(reflection.getField().getName());
                field = reflection.getField();
                depSize++;
            }
        }

        try {

            if (depSize == 1 && (!field.getName().equals("usuario"))) {
                if (getDependency.invoke(entity, null) == null) {
                    list.add(new SimpleMessage(field.getName(), field.getType().getSimpleName() + " ausente ou inválido"));
                    return list;
                }
                else{
                    Method getCodigo = new Inspector(getDependency.invoke(entity, null)).getGetMethod("codigo");
                    if (getCodigo.invoke(getDependency.invoke(entity, null), null) == null) { 
                        list.add(new SimpleMessage(field.getName(), field.getType().getSimpleName() + " sem codigo"));
                    }
                }
            }
        } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(Inspector.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    public Column getColumn(String field) {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase(field)) {
                return reflection.getColumn();
            }
        }
        return null;
    }

    public List<Reflection> getComponents() {
        return this.components;
    }

    public String getPrimaryKey() {
        return getPrimaryKey(type);
    }

    public boolean hasGeometry() {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equalsIgnoreCase("theGeom")) {
                return true;
            }
        }
        return false;
    }

    public boolean hasUser() {
        for (Reflection reflection : components) {
            if (reflection.getField().getName().equals("usuario")) {
                return true;
            }
        }
        return false;
    }

    private boolean complex(Class type) {
        Inspector insp = new Inspector(type);
        List<Reflection> list = insp.getComponents();

        for (Reflection reflection : list) {
            Column column = reflection.getColumn();

            if (column != null) {
                if (column.name().equalsIgnoreCase("the_geom")) {
                    return true;
                }
            }
            else
            return complex(reflection.getField().getType());
        }  
        return false;
    }   

    public boolean isComplex() {
        return complex(type);
    }

    public String getTableName() {
        Table table = (Table) type.getAnnotation(Table.class);

        return table.name();
    }

    public String getQueryByCode(Long codigo) {
        String option = (this.hasGeometry()) ? ", st_astext(the_geom) as geom" : "";
        return "select *" + option + " from " + getTableName() + " where " + getPrimaryKey() + " = '" + codigo + "'";
    }
    
    public String getQueryByField(Long fieldCode, String field) {
        String option = (this.hasGeometry()) ? ", st_astext(the_geom) as geom" : "";
        return "select *" + option + " from " + getTableName() + " where " + field + " = '" + fieldCode + "'";
    }
    
    public String getQueryShared(Long codigo) {
        String option = (this.hasGeometry()) ? ", st_astext(the_geom) as geom" : "";
        return "select *" + option + " from " + getTableName() + " where " + getPrimaryKey() + " = '" + codigo + "'";
    }

    public String getQueryAllByUser(Long codigo) {
        String option = (this.hasGeometry()) ? ", st_astext(the_geom) as geom" : "";
        String query = "select *" + option + " from " + getTableName() + " where " + getUserColumn() + " = '" + codigo + "' order by (" + getPrimaryKey() + ") ASC";
        
        if (!hasUser()) {
            query = "select *" + option + " from " + getTableName() + " a, " + getDependencyTableName() + " b where a." + getForeignKey() + " =b." + getDependencyPrimaryKey() + " and b." + getUserColumn() + " = '" + codigo + "' order by (a." + getPrimaryKey() + ") ASC";
        }
        return query;
    }

    private String getPrimaryKey(Class type) {
        if (type == null) {
            return null;
        }

        String name = null;
        for (Field f : type.getDeclaredFields()) {
            Id id = null;
            Column column = null;

            Annotation[] as = f.getAnnotations();
            for (Annotation a : as) {
                if (a.annotationType() == Id.class) {
                    id = (Id) a;
                } else if (a.annotationType() == Column.class) {
                    column = (Column) a;
                }
            }

            if (id != null && column != null) {
                name = column.name();
                break;
            }
        }

        if (name == null && type.getSuperclass() != Object.class) {
            name = getPrimaryKey(type.getSuperclass());
        }
        return name;
    }

    public String getUserField() {
        Inspector insp = new Inspector(type);
        if (insp.hasUser()) {
            return "usuario";
        }
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {

            JoinColumn jColumn = reflection.getjColumn();
            if (jColumn != null) {
                Field field = reflection.getField();
                insp = new Inspector(field.getType());
                if (insp.hasUser()) {
                    return field.getName() + ".usuario";
                }
            }
        }
        return null;
    }

    private String getDependencyTableName(Class type) {
        Inspector insp = new Inspector(type);
        if (insp.hasUser()) {
            return insp.getTableName();
        }
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {
            if (reflection.getjColumn() != null) {
                insp = new Inspector(reflection.getField().getType());
                if (insp.hasUser()) {
                    Table table = (Table) reflection.getField().getType().getAnnotation(Table.class);
                    return table.name();
                }
            }
        }
        return null;
    }

    public String getDependencyTableName() {
        return getDependencyTableName(type);
    }

    public String getDependencyPrimaryKey() {
        Inspector insp = new Inspector(type);
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {

            if (reflection.getjColumn() != null) {
                insp = new Inspector(reflection.getField().getType());
                if (insp.hasUser()) {
                    return insp.getPrimaryKey();
                }
            }
        }
        return null;
    }

    public Method dependencyGetCodigo() {
        Inspector insp = new Inspector(type);
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {

            if (reflection.getjColumn() != null) {
                insp = new Inspector(reflection.getField().getType());
                if (insp.hasUser()) {
                    return insp.getGetMethod("codigo");
                }
            }
        }
        return null;
    }

    public Method getDependency() {// alias usada na query. Se não tem é só colocar ""
        Inspector insp = new Inspector(type);
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {

            if (reflection.getjColumn() != null) {
                insp = new Inspector(reflection.getField().getType());
                if (insp.hasUser()) {
                    return reflection.getGetMethod();
                }
            }
        }
        return null;
    }

    public String getForeignKey() {
        Inspector insp = new Inspector(type);
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {
            JoinColumn jColumn = reflection.getjColumn();
            if (jColumn != null) {
                insp = new Inspector(reflection.getField().getType());
                if (insp.hasUser()) {
                    return jColumn.name();
                }
            }
        }
        return null;
    }

    public String getUser() {
        Inspector insp = new Inspector(type);
        if (insp.hasUser()) {
            return "usuario";
        }
        List<Reflection> list = insp.getComponents();
        for (Reflection reflection : list) {

            JoinColumn jColumn = reflection.getjColumn();
            if (jColumn != null) {
                Field field = reflection.getField();
                insp = new Inspector(field.getType());
                if (insp.hasUser()) {
                    return field.getName() + ".usuario";
                }
            }
        }
        return null;
    }

    public int size() {
        return components.size();
    }

    private void start() {
        Method[] methods = type.getDeclaredMethods();
        Method getMethod = null, setMethod = null;
        Column column = null;
        JoinColumn jColumn = null;

        for (Field field : type.getDeclaredFields()) {
            String set = "set" + ("" + field.getName().charAt(0)).toUpperCase() + field.getName().substring(1);
            String get = "get" + ("" + field.getName().charAt(0)).toUpperCase() + field.getName().substring(1);

            for (Method method : methods) {
                if (set.equalsIgnoreCase(method.getName())) {
                    setMethod = method;
                } else if (get.equalsIgnoreCase(method.getName())) {
                    getMethod = method;
                }
            }
            Column myColumn = field.getAnnotation(Column.class);
            JoinColumn myJoinColumn = field.getAnnotation(JoinColumn.class);

            if (myColumn != null) {
                column = myColumn;
                jColumn = null;
                columns.add(column.name());
            } else if (myJoinColumn != null) {
                jColumn = myJoinColumn;
                column = null;
                jColumns.add(jColumn.name());
            }
            components.add(new Reflection(getMethod, setMethod, field, column, jColumn));
        }
    }
}
