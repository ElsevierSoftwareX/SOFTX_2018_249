/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_maquinaoperacao")
public class MaquinaOperacao implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="maq_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Maquina é um campo obrigatório")
    @JoinColumn (name="maq_maqcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_maquinaoperacao_maquina"))
    private Maquina maquina;
    @Column(name="maq_custoaluguel", nullable=true, columnDefinition="decimal(10, 2)") private double custoAluguel;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedCustoAluguel é um campo obrigatório")
    @JoinColumn (name="maq_unicodigo_custoaluguel", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_maquinaoperacao_unidademedidacustoaluguel"))
    private UnidadeMedida uniMedCustoAluguel;
    @Column(name="maq_horastrabalhadas", nullable=true, columnDefinition="decimal(10, 2)") private double horasTrabalhadas;
    @Column(name="maq_custooperacional", nullable=true, columnDefinition="decimal(10, 2)") private double custoOperacional;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedCustoOperacional é um campo obrigatório")
    @JoinColumn (name="maq_unicodigo_custooperacional", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_maquinaoperacao_unidademedidacustooperacional"))
    private UnidadeMedida uniMedCustoOperacional;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="OperacaoCampo é um campo obrigatório")
    @JoinColumn (name="maq_opecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_maquinaoperacao_operacaocampo"))
    private OperacaoCampo operacaoCampo;

    public MaquinaOperacao() {
    }
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Maquina getMaquina() {
        return maquina;
    }

    public void setMaquina(Maquina maquina) {
        this.maquina = maquina;
    }

    public OperacaoCampo getOperacaoCampo() {
        return operacaoCampo;
    }

    public void setOperacaoCampo(OperacaoCampo operacaoCampo) {
        this.operacaoCampo = operacaoCampo;
    }

    public double getCustoAluguel() {
        return custoAluguel;
    }

    public void setCustoAluguel(double custoAluguel) {
        this.custoAluguel = custoAluguel;
    }

    public UnidadeMedida getUniMedCustoAluguel() {
        return uniMedCustoAluguel;
    }

    public void setUniMedCustoAluguel(UnidadeMedida uniMedCustoAluguel) {
        this.uniMedCustoAluguel = uniMedCustoAluguel;
    }

    public double getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(double horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public double getCustoOperacional() {
        return custoOperacional;
    }

    public void setCustoOperacional(double custoOperacional) {
        this.custoOperacional = custoOperacional;
    }

    public UnidadeMedida getUniMedCustoOperacional() {
        return uniMedCustoOperacional;
    }

    public void setUniMedCustoOperacional(UnidadeMedida uniMedCustoOperacional) {
        this.uniMedCustoOperacional = uniMedCustoOperacional;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MaquinaOperacao other = (MaquinaOperacao) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.maquina, other.maquina)) {
            return false;
        }
        if (!Objects.equals(this.operacaoCampo, other.operacaoCampo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.maquina);
        hash = 23 * hash + Objects.hashCode(this.operacaoCampo);
        hash = 23 * hash + Objects.hashCode(this.uniMedCustoAluguel);
        hash = 23 * hash + Objects.hashCode(this.uniMedCustoOperacional);
        return hash;
    }
    
    public Long getUserCode(){
        return maquina.getUsuario().getCodigo();
    }
}
