/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth.model;

import edu.utfpr.adfapi.model.Usuario;

/**
 *
 * @author Jasse
 */
public class Token {
    private String id;
    private String nome;
    private String permission;

    public Token(Usuario user) {
        this.id = user.getCodigo()+"";
        this.nome = user.getNome();
    }
    
    public Token(Usuario user, String permission) {
        this.id = user.getCodigo()+"";
        this.nome = user.getNome();
        this.permission=permission;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    
}
