/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_culturausuario", uniqueConstraints=@UniqueConstraint(columnNames={"cul_usucodigo", "cul_culcodigo"}, name="uk_culturausuario"))
public class CulturaUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="cul_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Cultura é um campo obrigatório")
    @JoinColumn (name="cul_culcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_culturausuario_cultura")) private Cultura cultura;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="cul_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_culturausuario_usuario")) private Usuario usuario;


    public CulturaUsuario() {
    }

    public CulturaUsuario(Usuario usuario, Cultura cultura) {
        this.usuario = usuario;
        this.cultura = cultura;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Cultura getCultura() {
        return cultura;
    }

    public void setCultura(Cultura cultura) {
        this.cultura = cultura;
    }
    
    public Cultura getMainResource() {
        return cultura;
    }

    public Long getUserCode(){
        return usuario.getCodigo();
    }
    
    @Override
    public String toString() {
        return "CulturaUsuario{ Cultura=" + cultura.getDescricaoPT() + ", Usuario=" + usuario.getNome() + '}';
    }
}
