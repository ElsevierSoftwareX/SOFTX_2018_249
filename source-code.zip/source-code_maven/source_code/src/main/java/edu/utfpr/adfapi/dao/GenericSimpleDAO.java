
package edu.utfpr.adfapi.dao;

import edu.utfpr.adfapi.auth.model.Recurso;
import edu.utfpr.adfapi.config.CONFIG;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.config.Reflection;
import edu.utfpr.adfapi.model.Noticia;
import edu.utfpr.adfapi.model.NoticiaUsuario;
import edu.utfpr.adfapi.model.Usuario;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.JoinColumn;
import javax.persistence.NoResultException;
import javax.persistence.Query;

/**
 *
 * @author Jasse
 * @param <E>
 */
public class GenericSimpleDAO<E> implements DAO<E> {

    @Inject
    private EntityManager manager;
    private List<NoticiaUsuario> ulist = new ArrayList();
    public GenericSimpleDAO() {

    }

    @Override
    public E create(E entity) throws Exception {
        try {
            manager.persist(entity);
            return entity;
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public E update(E entity) {
        try {
            return manager.merge(entity);
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public E find(Long id, Class<E> type) { // Just find the entity with this ID
        try {
            return manager.find(type, id);
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public List<E> findAll(Class<E> type) {
        try {
            List<E> lista = manager.createQuery("from " + type.getSimpleName() + " u order by u.codigo").getResultList();
            return lista;
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public boolean delete(E entity) {
        try {
            manager.remove(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public List<E> findAllByUsuario(Long codigo, Class<E> type) {
        Inspector insp = new Inspector(type);
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u WHERE u." + insp.getUserField() + ".codigo =:codigo order by u.codigo");
            query.setParameter("codigo", codigo);
            List<E> lista = query.getResultList();

            return lista;
        } catch (Exception e) {
            throw e;
        }
    }

    public List<E> findAllByField(String field, String value, Class<E> type) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u where u." + field + " like :value order by u.codigo");
            query.setParameter("value", "%" + value + "%");
            List<E> lista = query.getResultList();
            return lista;
        } catch (Exception e) {
            throw e;
        }
    }

    public E findByDescricao(String field, String value, Class<E> type) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u where u." + field + ".codigo = :value");
            query.setParameter("value", "%" + value + "%");
            return (E) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    public E findByField(String field, Long value, Class<E> type) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u where u." + field + ".codigo = :value");
            query.setParameter("value", value);
            return (E) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public E findByFields(Map<String, Object> fields, Class<E> type) {
        try {
            String middle="";
            Set<String> keys= fields.keySet();
            int flag=0;
            for(String key: keys){
                flag++;
                if (flag < keys.size()) {
                    middle = middle + " u." + key + " =:" + key + " and ";
                } else {
                    middle = middle + " u." + key + " =:" + key + "";
                }
            }
            String sQuery= "from " + type.getSimpleName() + " u where "+middle;
            Query query = manager.createQuery(sQuery);
            for(String key: keys){
                query.setParameter(key, fields.get(key));
            }
            return (E) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public List<E> findAllByFields(Map<String, Object> fields, Class<E> type) {
        try {
            String middle="";
            Set<String> keys= fields.keySet();
            int flag=0;
            for(String key: keys){
                flag++;
                if (flag < keys.size()) {
                    middle = middle + " u." + key + " =:" + key + " and ";
                } else {
                    middle = middle + " u." + key + " =:" + key + "";
                }
            }
            String sQuery= "from " + type.getSimpleName() + " u where "+middle;
            Query query = manager.createQuery(sQuery);
            for(String key: keys){
                query.setParameter(key, fields.get(key));
            }
            return query.getResultList();
        }
        catch (Exception e) {
            throw e;
        }
    }

    public Recurso findByNome(String nome) {
        try {
            Query query = manager.createQuery("from Recurso r where r.nome = :nome");
            query.setParameter("nome", nome);
            return (Recurso) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    public List<E> findAllByUsuario(Long codigo, Class<E> type, String dependency) {
        try {
            Query query = manager.createQuery("from " + type.getSimpleName() + " u WHERE u." + dependency + ".usuario.codigo = :codigo order by u.codigo");
            query.setParameter("codigo", codigo);
            List<E> lista = query.getResultList();

            return lista;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public String validateDepsUser(E entity, Usuario usuario) {
        Inspector insp = new Inspector(entity);
        try {
            for (int i = 0; i < insp.size(); i++) {
                Reflection ref = insp.getReflection(i);
                JoinColumn jColumn = ref.getjColumn();

                if (jColumn != null && !ref.getField().getName().equals("usuario")) {
                    Inspector inspDep = new Inspector(ref.getField().getType());
                    Long depCode = (Long) inspDep.getGetMethod("codigo").invoke(ref.getGetMethod().invoke(entity, null), null);
                    
                    if(depCode==null) return ref.getField().getType().getSimpleName();
                    Object dep = find(depCode, (Class<E>) ref.getField().getType());

                    if(dep==null) return ref.getField().getType().getSimpleName();
                    ref.getSetMethod().invoke(entity, find(depCode, (Class<E>) dep.getClass()));//ref.getField().getType().newInstance()));

                    if (CONFIG.isShared(ref.getField().getType().getSimpleName())) {
                        String main = ref.getField().getType().getSimpleName();
                        Query query = manager.createQuery("from " + main + "Usuario" + " a WHERE a.usuario = ? and a." + main.toLowerCase() + " = ?");
                        query.setParameter(1, usuario);

                        query.setParameter(2, find(depCode, (Class<E>) dep.getClass()));
                        if (query.getResultList().isEmpty()) {
                            return ref.getField().getType().getSimpleName();
                        }
                        return "true";
                    }

                    Method getUsuario = ref.getField().getType().getDeclaredMethod("getUsuario", null);
                    Usuario user = (Usuario) getUsuario.invoke(ref.getGetMethod().invoke(entity, null), null);
                    if (!usuario.equals(user)) {
                        return ref.getField().getType().getSimpleName();
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException | InvocationTargetException e) {
            Logger.getLogger(GenericComplexDAO.class.getName()).log(Level.SEVERE, null, e);
        }       
        return "true";
    }
    
    public List<Noticia> findAllByUser(Usuario usuario, String dispositivo) {
        try {
            String sQuery = "select n from Noticia n, AbrangenciaNoticia a where a.noticia = n and a.DDD =:ddd and"
                    + " n.inicioPublicacao <= :now and n.fimPublicacao >= :now order by n.codigo";

            Query query = manager.createQuery(sQuery);
            query.setParameter("ddd", ddd(usuario.getTelefone()));
            query.setParameter("now", dateNow());
            List<Noticia> news = query.getResultList();
            List<Noticia> noticias =new ArrayList();

            sQuery = "select n from NoticiaUsuario n where n.usuario =:usuario and n.dataRecebimento" + dispositivo + " != null order by n.codigo";
            
            query = manager.createQuery(sQuery);
            query.setParameter("usuario", usuario);
            List<NoticiaUsuario> list = query.getResultList();
            dispositivo = dispositivo.equalsIgnoreCase("Mobile")? "Web":"Mobile";

            sQuery = "select n from NoticiaUsuario n where n.usuario =:usuario and n.dataRecebimento" + dispositivo + " != null order by n.codigo";
            
            query = manager.createQuery(sQuery);
            query.setParameter("usuario", usuario);

            ulist = query.getResultList();
            
            for (Noticia n : news) {
                boolean found=false;
                for (NoticiaUsuario nu : list) {
                    if (n == nu.getNoticia()) {
                        found = true;
                    }
                }
                if(!found) noticias.add(n);
            }
            return noticias;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public List<NoticiaUsuario> findPendentesByUser(Usuario usuario, String dispositivo) {
        try {
            String sQuery = "from NoticiaUsuario n where n.usuario =:usuario and n.dataRecebimento" + dispositivo + " = null and "
                    + "n.noticia.inicioPublicacao <= :now and n.noticia.fimPublicacao >= :now order by n.codigo";
            
            Query query = manager.createQuery(sQuery);
            query.setParameter("usuario", usuario);
            query.setParameter("now", dateNow());
            List<NoticiaUsuario> list = query.getResultList();

            return list;
        } 
        catch (Exception e) {
            throw e;
        }
    }
    
    public List<NoticiaUsuario> findAcessadasByUser(Usuario usuario, String dispositivo) {
        try {
            String sQuery = "from NoticiaUsuario n where n.usuario =:usuario and n.dataAcesso" + dispositivo + " != null and "
                    + "n.noticia.inicioPublicacao <= :now and n.noticia.fimPublicacao >= :now order by n.codigo";
            
            Query query = manager.createQuery(sQuery);
            query.setParameter("usuario", usuario);
            query.setParameter("now", dateNow());
            List<NoticiaUsuario> list = query.getResultList();

            return list;
        } 
        catch (Exception e) {
            throw e;
        }
    }
    
    public List<NoticiaUsuario> findNaoAcessadasByUser(Usuario usuario, String dispositivo) {
        try {
            String sQuery = "from NoticiaUsuario n where n.usuario =:usuario and n.dataAcesso" + dispositivo + " = null and n.dataRecebimento" + dispositivo +
                    " != null and n.noticia.inicioPublicacao <= :now and n.noticia.fimPublicacao >= :now order by n.codigo";
            
            Query query = manager.createQuery(sQuery);
            query.setParameter("usuario", usuario);
            query.setParameter("now", dateNow());
            List<NoticiaUsuario> list = query.getResultList();

            return list;
        } 
        catch (Exception e) {
            throw e;
        }
    }
    
    public List<NoticiaUsuario> existing(){
        return ulist;
    }
    
    public NoticiaUsuario findByUser(NoticiaUsuario nu) {
        try {
            String sQuery ="select n from NoticiaUsuario n where n.noticia = :noticia and n.usuario =:usuario";
            Query query = manager.createQuery(sQuery);
            query.setParameter("noticia", nu.getNoticia());
            query.setParameter("usuario", nu.getUsuario());

            return (NoticiaUsuario) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    private String ddd(String telefone){
        return telefone.substring(0, 2);
    }
    
    private Date dateNow(){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
            Calendar calendarNow = Calendar.getInstance();
            return dateFormat.parse(dateFormat.format(calendarNow.getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(PermissaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
