/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_unidademedida", uniqueConstraints=@UniqueConstraint(columnNames="uni_descricao", name="uk_unidademedida"))
public class UnidadeMedida implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="uni_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="uni_descricao", length=60, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column(name="uni_sigla", length=30, nullable=false) @NotNull (message="Sigla é um campo obrigatório") private String sigla;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="uni_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_unidademedida_usuario"))
    private Usuario usuario;

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UnidadeMedida other = (UnidadeMedida) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.sigla, other.sigla)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.descricao);
        hash = 29 * hash + Objects.hashCode(this.sigla);
        hash = 29 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public boolean hasAssociation(){
        return true;
    }
    
    public UnidadeMedidaUsuario getAssociation(){
        UnidadeMedidaUsuario entity  = new UnidadeMedidaUsuario();
        entity.setUsuario(usuario);
        entity.setUnidadeMedida(this);
        return entity;
    }
}
