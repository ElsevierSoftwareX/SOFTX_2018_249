/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_variedadeusuario", uniqueConstraints=@UniqueConstraint(columnNames={"var_usucodigo", "var_varcodigo"}, name="uk_variedadeusuario"))
public class VariedadeUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="var_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Variedade é um campo obrigatório")
    @JoinColumn (name="var_varcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_variedadeusuario_variedade")) private Variedade variedade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="var_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_variedadeusuario_usuario")) private Usuario usuario;


    public VariedadeUsuario() {
    }

    public VariedadeUsuario(Usuario usuario, Variedade variedade) {
        this.usuario = usuario;
        this.variedade = variedade;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Variedade getVariedade() {
        return variedade;
    }

    public void setVariedade(Variedade variedade) {
        this.variedade = variedade;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final VariedadeUsuario other = (VariedadeUsuario) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.variedade, other.variedade)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.variedade);
        hash = 97 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    public Variedade getMainResource() {
        return variedade;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
