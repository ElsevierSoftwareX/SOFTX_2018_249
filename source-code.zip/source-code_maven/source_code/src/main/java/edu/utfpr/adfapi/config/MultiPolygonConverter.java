/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

/**
 *
 * @author Jasse
 */

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import org.geolatte.geom.MultiPolygon;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;

@Converter
public class MultiPolygonConverter implements AttributeConverter<MultiPolygon, String> {

 /**
  * Convert Geometry object to a WKT String
  */
 @Override
 public String convertToDatabaseColumn(MultiPolygon the_geom) {
     
     return Wkt.toWkt(the_geom);
 }

 /**
  * Convert a String in WKT to Geometry MultiPolygon
  */
 @Override
 public MultiPolygon convertToEntityAttribute(String geom) {
     return (MultiPolygon)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
 }
}
