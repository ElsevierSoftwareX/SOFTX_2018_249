
package edu.utfpr.adfapi.controller.simple;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericSimpleController;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.dao.UsuarioDAO;
import edu.utfpr.adfapi.model.Configuration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/configuration")
public class ConfigurationController {

    @Inject
    private GenericSimpleController<Configuration> controller;
    @Inject
    private UsuarioDAO udao;
    @Inject
    private GenericSimpleDAO<Configuration> dao;
    @Inject
    private Result result;
    
    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new Configuration());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Configuration(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_FORM_URLENCODED})
    public void post(Configuration entity) {
        if (entity != null) {
            if (entity.getUsuario() != null) {
                if (entity.getUsuario().getCodigo() != null) {
                    entity.setUsuario(udao.find(entity.getUsuario().getCodigo()));
                    try {
                        dao.create(entity);
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Exception: " + e);
                    }
                } else {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                }
                this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Usuario sem código")).serialize();
            } else {
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
            }
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Usuário em falta")).serialize();
        } else {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Entidade nula")).serialize();
        }
    }

    @APIRestrito
    @Put("")
    @Consumes("application/json")
    public void put(Configuration entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Configuration(), codigo);
    }
}
