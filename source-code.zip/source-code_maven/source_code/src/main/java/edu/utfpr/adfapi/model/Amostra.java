/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_amostra", uniqueConstraints=@UniqueConstraint(columnNames={"amo_descricao", "amo_atrcodigo", "amo_usucodigo", "amo_arecodigo"}, name="uk_amostra"))
public class Amostra implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="amo_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="amo_descricao", length=100, nullable=false) @NotNull (message="Descrição é um campo obrigatório") private String descricao;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="amo_tabela", length=30, nullable=false) @NotNull (message="NomeTabela é um campo obrigatório") private String nomeTabela;
    @Temporal(TemporalType.DATE) @Column (name="amo_datacadastro", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;   
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuário é um campo obrigatório")
    @JoinColumn(name="amo_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_usuario")) 
    private Usuario usuario; 
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Atributo é um campo obrigatório")
    @JoinColumn(name="amo_atrcodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_atributo")) 
    private Atributo atributo;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Área é um campo obrigatório")
    @JoinColumn(name="amo_arecodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_area")) 
    private Area area;

    public Amostra() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNomeTabela() {
        return nomeTabela;
    }

    public void setNomeTabela(String nomeTabela) {
        this.nomeTabela = nomeTabela;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Atributo getAtributo() {
        return atributo;
    }

    public void setAtributo(Atributo atributo) {
        this.atributo = atributo;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Amostra other = (Amostra) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.atributo, other.atributo)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        return true;
    }   

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.descricao);
        hash = 89 * hash + Objects.hashCode(this.usuario);
        hash = 89 * hash + Objects.hashCode(this.atributo);
        hash = 89 * hash + Objects.hashCode(this.area);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
