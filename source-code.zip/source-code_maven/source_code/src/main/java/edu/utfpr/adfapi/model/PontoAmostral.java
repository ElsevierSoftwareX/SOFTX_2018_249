/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.geolatte.geom.Point;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_pontoamostral")
public class PontoAmostral implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="pon_codigo") private Long codigo;
    @Column (name="the_geom", columnDefinition="geometry(Point,4326)") private Point theGeom;
    @Transient @NotNull (message="Geometria é um campo obrigatório") private String geom;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="GradeAmostral é um campo obrigatório")
    @JoinColumn (name="pon_gracodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_pontoamostral_gradeamostral")) 
    private GradeAmostral gradeAmostral;

    public PontoAmostral() {
    }

    public PontoAmostral(GradeAmostral gradeAmostral, Point the_geom) {
        this.gradeAmostral = gradeAmostral;
        this.theGeom = the_geom;
    }

    public Long getCodigo() {
        return codigo;     
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Point getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (Point)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(Point geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }


    public GradeAmostral getGradeAmostral() {
        return gradeAmostral;
    }

    public void setGradeAmostral(GradeAmostral gradeAmostral) {
        this.gradeAmostral=gradeAmostral;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.gradeAmostral);
        hash = 97 * hash + Objects.hashCode(this.theGeom);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PontoAmostral other = (PontoAmostral) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.gradeAmostral, other.gradeAmostral)) {
            return false;
        }
        if (!Objects.equals(this.theGeom, other.theGeom)) {
            return false;
        }
        return true;
    }
    
    public Long getSuperUserCode(){
        if(gradeAmostral!=null){
            if(gradeAmostral.getCodigo()!=null) return gradeAmostral.getCodigo();
        }
        return null;
    }
    
    public Long getUserCode(){
        return gradeAmostral.getUsuario().getCodigo();
    }
}
