
package edu.utfpr.adfapi.dao;

import edu.utfpr.adfapi.auth.model.Permissao;
import edu.utfpr.adfapi.auth.model.PermissaoRecurso;
import edu.utfpr.adfapi.auth.model.Recurso;
import edu.utfpr.adfapi.model.Usuario;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Jasse
 */
public class PermissaoDAO {
    
    @Inject private EntityManager manager;
    private GenericSimpleDAO<Recurso> rdao;
    @Inject
    private GenericSimpleDAO<PermissaoRecurso> prdao;

    public PermissaoDAO() {
    }

    public Permissao create(Permissao entity) throws Exception {
        try {
            manager.persist(entity);
        } catch (Exception e) {
            throw new Exception("Permissao já existente!");
        }
        return entity;
    }
    public Permissao update (Permissao entity){
        return manager.merge(entity);
    }
    
    public Permissao find(Long id) {
        try {
            List<Recurso> recursos = new ArrayList();
            Permissao permissao = manager.find(Permissao.class, id);
            if(permissao ==null) return null;
            for (PermissaoRecurso pr : findByPermissao(permissao)) {

                Recurso recurso = pr.getRecurso();
                recurso.setPost(pr.getPost());
                recurso.setPut(pr.getPut());
                recurso.setGet(pr.getGet());
                recurso.setDelete(pr.getDelete());
                recursos.add(recurso);
            }
            permissao.setRecursos(recursos);
            if(isValid(permissao)) return permissao;
            return null;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public List<Permissao> findByAutorizante(Long autorizante, Long autorizado) {
        try {
            List<Permissao> permissoes = new ArrayList();
            List<Recurso> recursos = new ArrayList();
            String sQuery ="from Permissao p where p.autorizante.codigo =:autorizante and p.autorizado.codigo =:autorizado and"
                    + " p.dataInicio <= :now and p.dataExpiracao >= :now order by p.codigo";
            Query query = manager.createQuery(sQuery);
            query.setParameter("autorizante", autorizante);
            query.setParameter("autorizado", autorizado);
            query.setParameter("now", dateNow());
            List<Permissao> permitions = query.getResultList();

            for (Permissao permissao : permitions) {
                List<PermissaoRecurso> list = this.findByPermissao(permissao);
                for (PermissaoRecurso pr : list) {
                    Recurso recurso = pr.getRecurso();
                    recurso.setPost(pr.getPost());
                    recurso.setPut(pr.getPut());
                    recurso.setGet(pr.getGet());
                    recurso.setDelete(pr.getDelete());
                    recursos.add(recurso);
                }
                permissao.setRecursos(recursos);
                permissoes.add(permissao);
            }
            return permissoes;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public List<Permissao> findByAutorizante(Usuario autorizante) {
        try {
            List<Permissao> permissoes = new ArrayList();
            Set<Recurso> recursos = new HashSet();
            String sQuery ="from Permissao p where p.autorizante =:autorizante  and"
                    + " p.dataInicio <= :now and p.dataExpiracao >= :now order by p.codigo";
            Query query = manager.createQuery(sQuery);
            query.setParameter("autorizante", autorizante);
            query.setParameter("now", dateNow());
            List<Permissao> permitions = query.getResultList();

            for (Permissao permissao : permitions) {
                List<PermissaoRecurso> list = this.findByPermissao(permissao);
                for (PermissaoRecurso pr : list) {
                    Recurso recurso = pr.getRecurso();
                    recurso.setPost(pr.getPost());
                    recurso.setPut(pr.getPut());
                    recurso.setGet(pr.getGet());
                    recurso.setDelete(pr.getDelete());
                    recursos.add(recurso);
                }
                permissao.setRecursos(new ArrayList(recursos));
                permissoes.add(permissao);
            }
            return permissoes;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    public List<Permissao> findByAutorizado(Long autorizante, Long autorizado) {
        try {
            List<Permissao> permissoes = new ArrayList();
            List<Recurso> recursos = new ArrayList();
            String sQuery ="from Permissao p where p.autorizante.codigo =:autorizante and p.autorizado.codigo =:autorizado and"
                    + " p.dataInicio <= :now and p.dataExpiracao >= :now order by p.codigo";
            Query query = manager.createQuery(sQuery);
            query.setParameter("autorizante", autorizante);
            query.setParameter("autorizado", autorizado);
            query.setParameter("now", dateNow());
            List<Permissao> permitions = query.getResultList();

            for (Permissao permissao : permitions) {
                List<PermissaoRecurso> list = this.findByPermissao(permissao);
                for (PermissaoRecurso pr : list) {
                    Recurso recurso = pr.getRecurso();
                    recurso.setPost(pr.getPost());
                    recurso.setPut(pr.getPut());
                    recurso.setGet(pr.getGet());
                    recurso.setDelete(pr.getDelete());
                    recursos.add(recurso);
                }
                permissao.setRecursos(recursos);
                permissoes.add(permissao);
            }
            return permissoes;
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    /*public List<Permissao> findByAutorizante(Usuario autorizante) {
        try{
            Query query = manager.createQuery("from Permissao p where p.autorizante =:auto");
            query.setParameter("auto", autorizante);
            return query.getResultList();
        }
        catch (NoResultException e) {
            return null;
        }
        catch(Exception e){
            throw e;
        }
    }*/
    
    public List<PermissaoRecurso> findByPermissao(Permissao permissao) {
        try{
            Query query = manager.createQuery("from PermissaoRecurso p where p.permissao =:permissao order by p.codigo");
            query.setParameter("permissao", permissao);
            return query.getResultList();
        }
        catch (NoResultException e) {
            return null;
        }
        catch(Exception e){
            throw e;
        }
    }
    
    public List<PermissaoRecurso> findAllByPermissao(Permissao permissao) {
        try {
            Query query = manager.createQuery("from PermissaoRecurso u where u.permissao =:permissao order by u.codigo");
            query.setParameter("permissao",  permissao);
            List<PermissaoRecurso> lista = query.getResultList();
            return lista;
        } catch (Exception e) {
            throw e;
        }
    }

    public boolean delete(Permissao entity) {
        try {
            manager.remove(entity);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public List<Permissao> findAll() {
        return manager.createQuery("from Permissao").getResultList();
    }
    
    public List<Permissao> findAllByUser(Usuario autorizado) {

        try{
            String sQuery = "from Permissao p WHERE p.autorizado= :auto and p.dataInicio <= :now and p.dataExpiracao >= :now order by p.codigo";
            Query query = manager.createQuery(sQuery);
            query.setParameter("auto", autorizado);
            query.setParameter("now", dateNow());
            return query.getResultList();
        }
        catch (NoResultException e) {
            return null;
        }
        catch(Exception e){
            throw e;
        }
    }
    
    public boolean findAndDelete(Long id) {
        try {
            manager.remove(this.find(id));
        } catch (Exception e) {
            return false;
        }
        return true;
    }
    
    public Permissao find(Permissao permissao) {
        try {
            String squery = "from Permissao p where p.autorizante= :autorizante and p.autorizado =:autorizado and p.dataInicio =:inicio and p.dataExpiracao =:exp";
            Query query = manager.createQuery(squery);
            query.setParameter("autorizante", permissao.getAutorizante());
            query.setParameter("autorizado", permissao.getAutorizado());
            query.setParameter("inicio", permissao.getDataInicio());
            query.setParameter("exp", permissao.getDataExpiracao());
            return (Permissao) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } catch (Exception e) {
            throw e;
        }
    }
    
    private Date dateNow(){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
            Calendar calendarNow = Calendar.getInstance();
            return dateFormat.parse(dateFormat.format(calendarNow.getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(PermissaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean isValid(Permissao permissao) {
        if(permissao ==null) return false;
        return permissao.getDataInicio().before(dateNow()) && permissao.getDataExpiracao().after(dateNow());
    }
    
    public boolean createPR(Permissao permission, Recurso resource){
        try {
            Recurso entity = rdao.findByNome(resource.getNome());
            if (entity != null) {
                entity.setPost(resource.getPost());
                entity.setPut(resource.getPut());
                entity.setGet(resource.getGet());
                entity.setDelete(resource.getDelete());
                resource = entity;
            } else {
                resource = rdao.create(resource);
            }
            prdao.create(new PermissaoRecurso(resource, permission, resource.getGet(), resource.getPut(), resource.getPost(), resource.getDelete()));
            return true;
        } catch (Exception ex) {          
            Logger.getLogger(Permissao.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public void removeDep(Permissao permissao) {
        for (Recurso recurso : permissao.getRecursos()) {
            String depName = depName(recurso.getNome());
            if (!"".equals(depName)) {
                for (Recurso rec : permissao.getRecursos()) {
                    if (depName.equals(rec.getNome())) {
                        permissao.getRecursos().remove(rec);
                        depName = "found";
                        break;
                    }
                }
            }
            if ("found".equals(depName)) {
                break;
            }
        }
    }
    
    public String depName(String nome){
        String dep = "";
        switch (nome) {
            case "Amostra":
                dep = "PixelAmostra";
                break;
            case "ZonaManejo":
                dep = "PixelZonaManejo";
                break;
            case "Mapa":
                dep = "PixelMapa";
                break;
            case "GradeAmostral":
                dep = "PontoAmostral";
                break;
        }
        return dep;
    }
    
    /*public String mainName(String nome){
        String dep = "";
        switch (nome) {
            case "PixelAmostra":
                dep = "Amostra";
                break;
            case "PixelZonaManejo":
                dep = "ZonaManejo";
                break;
            case "Mapa":
                dep = "PixelMapa";
                break;
            case "GradeAmostral":
                dep = "PontoAmostral";
                break;
        }
        return dep;
    }*/
}
