/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.controller.HttpMethod;
import br.com.caelum.vraptor.controller.MethodNotAllowedHandler;
import br.com.caelum.vraptor.http.MutableRequest;
import br.com.caelum.vraptor.http.MutableResponse;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import java.util.Set;
import javax.enterprise.context.RequestScoped;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author UTFPR
 */

//@Component
@RequestScoped
public class Error405 implements MethodNotAllowedHandler{
private Result result;
 
    public Error405(Result result){
        this.result = result;
    }
 

    @Override
    public void deny(MutableRequest request, MutableResponse response, Set<HttpMethod> allowedMethods) {
        //result.redirectTo("/endereco-da-minha-url/");
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Método não permitido")).serialize();
    }
}