/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_mapazm", uniqueConstraints=@UniqueConstraint(columnNames={"map_mapcodigo", "map_zoncodigo"}, name="uk_mapazm"))
public class MapaZonaManejo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="map_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Mapa é um campo obrigatório")
    @JoinColumn (name="map_mapcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_mapazm_mapa")) 
    private Mapa mapa;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="ZonaManejo é um campo obrigatório")
    @JoinColumn (name="map_zoncodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_mapazm_zonamanejo")) 
    private ZonaManejo zonaManejo;
 

    public MapaZonaManejo() {
    }

    public MapaZonaManejo(Mapa mapa, ZonaManejo zonaManejo) {
        this.mapa = mapa;
        this.zonaManejo = zonaManejo;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Mapa getMapa() {
        return mapa;
    }

    public void setMapa(Mapa mapa) {
        this.mapa = mapa;
    }

    public ZonaManejo getZonaManejo() {
        return zonaManejo;
    }

    public void setZonaManejo(ZonaManejo zonaManejo) {
        this.zonaManejo = zonaManejo;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MapaZonaManejo other = (MapaZonaManejo) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.mapa, other.mapa)) {
            return false;
        }
        if (!Objects.equals(this.zonaManejo, other.zonaManejo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.mapa);
        hash = 37 * hash + Objects.hashCode(this.zonaManejo);
        return hash;
    }

    public Long getUserCode(){
        return mapa.getUsuario().getCodigo();
    }
}
