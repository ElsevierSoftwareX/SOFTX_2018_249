
package edu.utfpr.adfapi.controller.simple;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.auth.BeanValidator;
import edu.utfpr.adfapi.auth.JWTSigner;
import edu.utfpr.adfapi.auth.model.Permissao;
import edu.utfpr.adfapi.auth.model.PermissaoRecurso;
import edu.utfpr.adfapi.auth.model.Recurso;
import edu.utfpr.adfapi.config.CONFIG;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.controller.GenericSimpleController;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.dao.PermissaoDAO;
import edu.utfpr.adfapi.model.Usuario;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/permissao")
public class PermissaoController {

    @Inject
    private GenericSimpleController<Permissao> controller;
    @Inject
    private PermissaoDAO pdao;
    @Inject
    private GenericSimpleDAO<Recurso> rdao;
    @Inject
    private GenericSimpleDAO<PermissaoRecurso> adao;
    @Inject
    private GenericSimpleDAO<Usuario> udao;
    @Inject
    private Result result;
    @Inject
    private HttpServletRequest req;
    @Inject
    private JWTSigner jwts;
    @Inject
    private BeanValidator validator;

    @APIRestrito
    @Get("")
    public void get() {
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
        result.use(Results.json()).withoutRoot().from(new SimpleMessage("1", "URI nao encontrada. Verifique sua requisicao")).serialize();
    }

    @APIRestrito
    @Get("/criadas")
    public void getAllCreated() {
        List<Permissao> list = pdao.findByAutorizante(controller.getTheUserFromToken());
        if (list.isEmpty()) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(list).include("autorizado")
                    .exclude("recursos", "autorizado.dataCadastro", "autorizado.dataExpiracao").serialize();
        }
    }

    @APIRestrito
    @Get("/recebidas")
    public void getAllReceived() {
        List<Permissao> list = jwts.getSimplePerm(req.getHeader("Authorization"));
        if (list.isEmpty()) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(list).include("autorizante")
                    .exclude("recursos", "autorizante.dataCadastro", "autorizante.dataExpiracao").serialize();
        }
    }

    @APIRestrito
    @Get("/recebidas/{codigo}")
    public void getOneReceived(Long codigo) {
        Permissao permissao = jwts.getPermissao(req.getHeader("Authorization"), codigo);
        if (permissao == null) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado. Não existe ou pertence a outro usuário")).serialize();
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(permissao).include("autorizante", "recursos")
                    .exclude("recursos.nomeTabela", "recursos.chavePrimaria", "recursos.nomeIdUsuario").serialize();
        }
    }

    @APIRestrito
    @Get("/criadas/{codigo}")
    public void getOneCreated(Long codigo) {
        Permissao permissao = pdao.find(codigo);
        if (permissao == null) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
        } else {
            if (!permissao.getAutorizante().equals(controller.getTheUserFromToken())) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissão", "Recurso associado a outro usuário")).serialize();
            } else {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                result.use(Results.json()).withoutRoot().from(permissao).include("autorizado", "recursos")
                        .exclude("recursos.nomeTabela", "recursos.chavePrimaria", "recursos.nomeIdUsuario").serialize();
            }
        }
    }

    @APIRestrito
    @Get("/autorizante/{autorizante}")
    public void getByAuth(Long autorizante) {
        List<Permissao> list = pdao.findByAutorizante(autorizante, controller.getTheUserFromToken().getCodigo());

        if (list.isEmpty()) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(list).include("autorizante", "recursos").serialize();
        }
    }

    @APIRestrito
    @Get("/autorizado/{autorizado}")
    public void getByAutorizado(Long autorizado) {
        List<Permissao> list = pdao.findByAutorizante(controller.getTheUserFromToken().getCodigo(), autorizado);

        if (list.isEmpty()) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(list).include("autorizante", "recursos").serialize();
        }
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Permissao permissao) {
        try {
            permissao.setAutorizante(controller.getUserFromToken());
            if (validator.temErros(permissao)) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                result.use(Results.json()).withoutRoot().from(validator.getErros(permissao)).serialize();
                return;
            }

            if (pdao.find(permissao) != null) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CONFLICT);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Permissao já existente")).serialize();
                return;
            }
            Usuario autorizado = udao.find(permissao.getAutorizado().getCodigo(), Usuario.class);
            if (autorizado == null) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado <autorizado>")).serialize();
                return;
            }
            permissao = pdao.create(permissao);
            for (Recurso recurso : permissao.getRecursos()) {
                String nome = recurso.getNome();
                if (!nome.equals("TipoOcorrencia") && !CONFIG.isShared(nome)) {
                    String dep = depName(recurso.getNome());
                    recurso = setFields(recurso);
                    Recurso depRes = new Recurso();
                    if (dep.length() > 0) {
                        depRes.setNome(dep);
                        depRes = setFields(depRes);
                    }

                    if (validator.temErros(recurso)) {
                        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                        result.use(Results.json()).withoutRoot().from(validator.getErros(recurso)).serialize();
                        return;
                    }

                    createPR(permissao, recurso);
                    if (dep.length() > 0) {
                        depRes = setMethods(depRes, recurso);
                        depRes.setNome(dep);
                        depRes = setFields(depRes);
                        createPR(permissao, depRes);
                    }
                }

            }

            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
            result.use(Results.json()).withoutRoot().from(permissao).include("autorizado", "recursos").
                    exclude("recursos.chavePrimaria", "recursos.nomeIdUsuario", "recursos.nomeTabela").serialize();

        } catch (Exception e) {
            exception(e);
        }
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        Permissao permissao = pdao.find(codigo);
        if (permissao == null) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
        } else {
            if (!permissao.getAutorizante().equals(controller.getTheUserFromToken())) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso associado a outro usuário")).serialize();
            } else {
                List<PermissaoRecurso> list = pdao.findAllByPermissao(permissao);
                for (PermissaoRecurso pr : list) {
                    try {
                        adao.delete(pr);
                    } catch (Exception e) {
                        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "A API não pode executar a operação. Problemas com dependencias")).serialize();
                        return;
                    }
                }
                pdao.delete(permissao);
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Recurso removido")).serialize();
            }
        }
    }

    private String depName(String nome) {
        String dep = "";
        switch (nome) {
            case "Amostra":
                dep = "PixelAmostra";
                break;
            case "ZonaManejo":
                dep = "PixelZonaManejo";
                break;
            case "Mapa":
                dep = "PixelMapa";
                break;
            case "GradeAmostral":
                dep = "PontoAmostral";
                break;
        }
        return dep;
    }

    private boolean createPR(Permissao permission, Recurso resource) {
        try {
            Recurso entity = rdao.findByNome(resource.getNome());
            if (entity != null) {
                entity.setPost(resource.getPost());
                entity.setPut(resource.getPut());
                entity.setGet(resource.getGet());
                entity.setDelete(resource.getDelete());
                resource = entity;
            } else {
                resource = rdao.create(resource);
            }
            adao.create(new PermissaoRecurso(resource, permission, resource.getGet(), resource.getPut(), resource.getPost(), resource.getDelete()));
            return true;
        } catch (Exception ex) {

            Logger.getLogger(PermissaoController.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    private Recurso setMethods(Recurso recurso, Recurso alvo) {
        try {
            recurso.setPost(alvo.getPost());
            recurso.setPut(alvo.getPut());
            recurso.setGet(alvo.getGet());
            recurso.setDelete(alvo.getDelete());
            return recurso;
        } catch (Exception e) {
            return null;
        }
    }

    private Recurso setFields(Recurso resource) {
        String nome = resource.getNome();
        try {
            Inspector insp = new Inspector(Class.forName("edu.utfpr.adfapi.model." + nome));
            if (CONFIG.isShared(nome)) {
                resource.setVisibilidade("Partilhado");
            } else {
                resource.setVisibilidade("Não partilhado");
            }
            resource.setChavePrimaria(insp.getPrimaryKey());
            resource.setNomeIdUsuario(insp.getUserColumn());
            resource.setNomeTabela(insp.getTableName());
            return resource;

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PermissaoController.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public void exception(Exception e) {
        String message = "";
        for (Throwable t = e.getCause(); t != null; t = t.getCause()) {
            String[] cases = {"unique constraint", "foreign key constraint"};

            int i;
            for (i = 0; i < cases.length; i++) {
                if (t.toString().contains(cases[i])) {
                    break;
                }
            }
            switch (i) {
                case 0: {
                    message = "Chave duplicada: " + unique(t.toString()) + "ja existe";
                    break;
                }

                case 1: {
                    message = "Chave ausente: " + this.foreignKey(t.toString());
                    message = message.replace("is not present in table", "nao esta presente na tabela");
                    message = message.replace("tb_", "");
                    break;
                }
                default: {
                }
            }
        }

        if ("".equals(message)) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", e.getMessage())).serialize();
            return;
        }
        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", message)).serialize();
    }

    private String unique(String key) {
        for (int i = 0; i < key.length(); i++) {
            if (key.charAt(i) == '(') {
                return key.substring(i - 1, key.length() - 15);
            }
        }
        return key;
    }

    private String foreignKey(String key) {
        for (int i = 0; i < key.length(); i++) {
            if (key.charAt(i) == '(') {
                return key.substring(i - 1, key.length() - 1);
            }
        }
        return key;
    }
}
