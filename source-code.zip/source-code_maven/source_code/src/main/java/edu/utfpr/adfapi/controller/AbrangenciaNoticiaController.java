
package edu.utfpr.adfapi.controller;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.dao.UsuarioDAO;
import edu.utfpr.adfapi.model.AbrangenciaNoticia;
import edu.utfpr.adfapi.model.Noticia;
import edu.utfpr.adfapi.model.NoticiaUsuario;
import edu.utfpr.adfapi.model.Usuario;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/abrangencianoticia")
public class AbrangenciaNoticiaController {

    @Inject
    private GenericSimpleDAO<AbrangenciaNoticia> dao;
    @Inject
    private GenericSimpleDAO<Noticia> depdao;
    @Inject
    private GenericSimpleDAO<NoticiaUsuario> adao;
    @Inject
    private UsuarioDAO udao;
    @Inject
    private Result result;
    @Inject
    private GenericSimpleController<AbrangenciaNoticia> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new AbrangenciaNoticia());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new AbrangenciaNoticia(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(AbrangenciaNoticia entity) {
        if (entity.getNoticia() != null) {
            if (entity.getNoticia().getCodigo() != null) {
                Noticia dependency = depdao.find(entity.getNoticia().getCodigo(), Noticia.class);
                if (dependency != null) {
                    Map<String, Object> fields = new HashMap();
                    fields.put("DDD", entity.getDDD());
                    fields.put("noticia", entity.getNoticia());
                    AbrangenciaNoticia existing = dao.findByFields(fields, AbrangenciaNoticia.class);
                    if (existing == null) {
                        entity.setNoticia(dependency);
                        if (dependency.getUsuario() == controller.getUserFromToken()) {
                            if (validaDDD(entity.getDDD())) {
                                for (Usuario u : udao.findAllByDDD(entity.getDDD())) {
                                    NoticiaUsuario nu = new NoticiaUsuario();
                                    nu.setNoticia(entity.getNoticia());
                                    nu.setUsuario(u);
                                    try {
                                        adao.create(nu);
                                    } catch (Exception e) {
                                        SimpleMessage message = new SimpleMessage("Erro", "Problemas no post de NoticiaUsuario. Reporte a equipe de desenvolvimento.");
                                        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                                        result.use(Results.json()).withoutRoot().from(message).serialize();
                                        return;
                                    }
                                }
                            }
                        }
                    } else {
                        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CONFLICT);
                        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Recurso já existente. Verifique a notícia e o DDD")).serialize();
                        return;
                    }
                }
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(AbrangenciaNoticia entity) {
        if (entity.getNoticia() != null) {
            if (entity.getNoticia().getCodigo() != null) {
                Noticia dependency = depdao.find(entity.getNoticia().getCodigo(), Noticia.class);
                entity.setNoticia(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new AbrangenciaNoticia(), codigo);
    }

    private boolean validaDDD(String ddd) {
        try {
            Integer.parseInt(ddd);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
