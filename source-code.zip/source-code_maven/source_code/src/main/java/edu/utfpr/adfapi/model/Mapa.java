/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import edu.utfpr.adfapi.config.StringCharConverter;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_mapa")
public class Mapa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="map_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="map_descricao", length=100, nullable=false) @NotNull private String descricao;
    @Temporal(TemporalType.DATE) 
    @Column (name="map_datacriacao", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;   
    @Column (name="map_tamx", columnDefinition="float", nullable=false) @NotNull (message="TamanhoX é um campo obrigatório") private float tamanhoX;
    @Column (name="map_tamy", columnDefinition="float", nullable=false) @NotNull (message="TamanhoY é um campo obrigatório") private float tamanhoY;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="map_tipogeometria", length=30, nullable=false) @NotNull (message="TipoGeometria é um campo obrigatório") private String tipoGeometria;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="map_tipointerpolador", length=30, nullable=false) @NotNull(message="TipoInterpolador é um campo obrigatório") private String tipoInterpolador;   
    @Column (name="map_expoente", columnDefinition="float") private float expoente;
    @Column (name="map_raio", columnDefinition="float") private float raio;
    @Column (name="map_npontos", columnDefinition="int") private int numeroPontos;
    @Column (name="map_efeitoPepita", columnDefinition="float") private float efeitoPepita;
    @Column (name="map_patamar", columnDefinition="float") private float patamar;
    @Column (name="map_alcance", columnDefinition="float") private float alcance;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="map_modelo", length=100) private String modelo;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="map_compprincipal", length=1) 
    @Convert(converter = StringCharConverter.class) private String compPrincipal;
    @Temporal(TemporalType.DATE) @Column (name="map_data") private Date data; 
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="map_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_usuario")) private Usuario usuario; 
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Amostra é um campo obrigatório")
    @JoinColumn(name="map_amocodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_amostra")) private Amostra amostra;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn(name="map_arecodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_amostra_area")) private Area area;

    public Mapa() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCriacao) {
        this.dataCadastro = dataCriacao;
    }

    public float getTamanhoX() {
        return tamanhoX;
    }

    public void setTamanhoX(float tamanhoX) {
        this.tamanhoX = tamanhoX;
    }

    public float getTamanhoY() {
        return tamanhoY;
    }

    public void setTamanhoY(float tamanhoY) {
        this.tamanhoY = tamanhoY;
    }

    public String getTipoGeometria() {
        return tipoGeometria;
    }

    public void setTipoGeometria(String tipoGeometria) {
        this.tipoGeometria = tipoGeometria;
    }

    public String getTipoInterpolador() {
        return tipoInterpolador;
    }

    public void setTipoInterpolador(String tipoInterpolador) {
        this.tipoInterpolador = tipoInterpolador;
    }

    public float getExpoente() {
        return expoente;
    }

    public void setExpoente(float expoente) {
        this.expoente = expoente;
    }

    public float getRaio() {
        return raio;
    }

    public void setRaio(float raio) {
        this.raio = raio;
    }

    public int getNumeroPontos() {
        return numeroPontos;
    }

    public void setNumeroPontos(int numeroPontos) {
        this.numeroPontos = numeroPontos;
    }

    public float getEfeitoPepita() {
        return efeitoPepita;
    }

    public void setEfeitoPepita(float efeitoPepita) {
        this.efeitoPepita = efeitoPepita;
    }

    public float getPatamar() {
        return patamar;
    }

    public void setPatamar(float patamar) {
        this.patamar = patamar;
    }

    public float getAlcance() {
        return alcance;
    }

    public void setAlcance(float alcance) {
        this.alcance = alcance;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCompPrincipal() {
        return compPrincipal;
    }

    public void setCompPrincipal(String compPrincipal) {
        this.compPrincipal = compPrincipal;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Amostra getAmostra() {
        return amostra;
    }

    public void setAmostra(Amostra amostra) {
        this.amostra = amostra;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Mapa other = (Mapa) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.amostra, other.amostra)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.descricao);
        hash = 97 * hash + Float.floatToIntBits(this.tamanhoX);
        hash = 97 * hash + Float.floatToIntBits(this.tamanhoY);
        hash = 97 * hash + Objects.hashCode(this.tipoGeometria);
        hash = 97 * hash + Objects.hashCode(this.usuario);
        hash = 97 * hash + Objects.hashCode(this.amostra);
        hash = 97 * hash + Objects.hashCode(this.area);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
