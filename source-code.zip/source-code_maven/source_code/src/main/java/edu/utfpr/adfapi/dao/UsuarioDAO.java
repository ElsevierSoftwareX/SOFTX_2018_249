
package edu.utfpr.adfapi.dao;

import edu.utfpr.adfapi.auth.model.Permissao;
import edu.utfpr.adfapi.model.NoticiaUsuario;
import edu.utfpr.adfapi.model.Usuario;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.enterprise.context.RequestScoped;
import javax.swing.JOptionPane;

/**
 *
 * @author Jasse
 */
@RequestScoped
public class UsuarioDAO {

    @Inject private EntityManager manager;
    
    public UsuarioDAO() {
    }

    
    public Usuario create(Usuario entity) {
        try {
            manager.persist(entity);
        } catch (Exception e) {
            return null;
        }
        return entity;
    }

    public Usuario update(Usuario entity) {
        manager.merge(entity);
        return entity;
    }

    public Usuario find(Long id) {
        return manager.find(Usuario.class, id);
    }

    public boolean delete(Usuario entity) {
        try {
            manager.remove(entity);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public List<Usuario> findAllUsers() {
        return manager.createNamedQuery("Usuario.findAll").getResultList();
    }
    
    public List<Usuario> findAllByDDD(String ddd) {
        Query query = manager.createQuery("from Usuario u where substring(u.telefone, length(u.telefone)-8, 2) =:ddd");
        query.setParameter("ddd", ddd);
        return query.getResultList();
    }

    public Usuario findByEmail(String email) throws Exception {
        Query q = manager.createQuery("SELECT u FROM Usuario u WHERE u.email = :email");
        q.setParameter("email", email);
        //Usuario u = null;
        try {
            return (Usuario) q.getSingleResult();
        } catch (NoResultException e) {
            throw new Exception(e.getMessage());
        }
    }
    
    public Usuario getByTelefone(String telefone) throws Exception {
        Query q = manager.createQuery("from Usuario u where u.telefone = :telefone");
        q.setParameter("telefone", telefone);
        try {
            return (Usuario) q.getSingleResult();
        } catch (NoResultException e) {
            JOptionPane.showMessageDialog(null, "null....");
            return null;
        }      
    }

    public List<Usuario> getByNome(String nome){
        Query q = manager.createQuery("SELECT u FROM Usuario u WHERE lower(u.nome) LIKE lower(:nome)");
        q.setParameter("nome", "%" + nome + "%");
        List<Usuario> u = q.getResultList();
        return u;
    }

    public List<Usuario> getByCidade(Long cidadeId){
        Query q = manager.createQuery("SELECT u FROM Usuario u WHERE u.cidade.codigo = :codigo");
        q.setParameter("codigo", cidadeId);
        List<Usuario> u = q.getResultList();
        return u;
    }
    
    public Usuario getByToken(String token) throws Exception{
        Query q = manager.createQuery("SELECT u FROM Usuario u WHERE u.token = :token");
        q.setParameter("token", token);
        try {
            return (Usuario) q.getSingleResult();
        } catch (NoResultException e) {
            throw new Exception(e.getMessage());
        }
    } 
   
    public List<Permissao> getPermissoes(Long autorizado) throws Exception {
        Query q = manager.createQuery("SELECT u FROM Permissao u WHERE u.autorizado = :autorizado");
        q.setParameter("autorizado", autorizado);
        return q.getResultList();
    }
}
