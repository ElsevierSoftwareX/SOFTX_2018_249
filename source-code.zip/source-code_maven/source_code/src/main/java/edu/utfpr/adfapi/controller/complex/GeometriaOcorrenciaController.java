
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.GeometriaOcorrencia;
import edu.utfpr.adfapi.model.Ocorrencia;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/geometriaocorrencia")
public class GeometriaOcorrenciaController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<Ocorrencia> depdao;
    @Inject
    private GenericComplexDAO<GeometriaOcorrencia> dao;
    @Inject
    private Result result;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new GeometriaOcorrencia());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new GeometriaOcorrencia(), codigo);
    }

    @APIRestrito
    @Get("/ocorrencia/{codigo}")
    public void getByField(Long codigo) {
        Ocorrencia existing = depdao.find(codigo, new Ocorrencia());
        if (existing == null) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso fornecido <Ocorrencia não encontrado")).serialize();
        } else {
            if (!(Objects.equals(controller.getUserFromToken(), existing.getUsuario()))) {
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("OperacaoCampo", "Recurso fornecido <Ocorrencia> associado a outro usuário")).serialize();
            } else {
                List<GeometriaOcorrencia> toSend = dao.findByField(codigo, new GeometriaOcorrencia(), "geo_ococodigo");
                if (toSend.isEmpty()) {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                    this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
                } else {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                    this.result.use(Results.json()).withoutRoot().from(toSend).include(controller.fields(new GeometriaOcorrencia())).serialize();
                }
            }
        }
    }
    
    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(GeometriaOcorrencia entity) {
        if (entity.getOcorrencia() != null) {
            if (entity.getOcorrencia().getCodigo() != null) {
                Ocorrencia dependency = depdao.find(entity.getOcorrencia().getCodigo(), new Ocorrencia());
                entity.setOcorrencia(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(GeometriaOcorrencia entity) {
        if (entity.getOcorrencia() != null) {
            if (entity.getOcorrencia().getCodigo() != null) {
                Ocorrencia dependency = depdao.find(entity.getOcorrencia().getCodigo(), new Ocorrencia());
                entity.setOcorrencia(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new GeometriaOcorrencia(), codigo);
    }
}
