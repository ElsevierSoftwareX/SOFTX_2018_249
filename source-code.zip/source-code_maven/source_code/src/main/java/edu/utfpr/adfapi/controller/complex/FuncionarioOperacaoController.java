
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.FuncionarioOperacao;
import edu.utfpr.adfapi.model.OperacaoCampo;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/funcionariooperacao")
public class FuncionarioOperacaoController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<OperacaoCampo> depdao;
    @Inject
    private GenericComplexDAO<FuncionarioOperacao> dao;
    @Inject
    private Result result;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new FuncionarioOperacao());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new FuncionarioOperacao(), codigo);
    }
    
    @APIRestrito
    @Get("/operacaocampo/{codigo}")
    public void getByField(Long codigo) {
        OperacaoCampo existing = depdao.find(codigo, new OperacaoCampo());
        if (existing == null) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso fornecido <OperacaoCampo> não encontrado")).serialize();
        } else {
            if (!(Objects.equals(controller.getUserFromToken(), existing.getUsuario()))) {
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("OperacaoCampo", "Recurso fornecido <OperacaoCampo> associado a outro usuário")).serialize();
            } else {
                List<FuncionarioOperacao> toSend = dao.findByField(codigo, new FuncionarioOperacao(), "fun_opecodigo");
                if (toSend.isEmpty()) {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                    this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
                } else {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                    this.result.use(Results.json()).withoutRoot().from(toSend).include(controller.fields(new FuncionarioOperacao())).serialize();
                }
            }
        }
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(FuncionarioOperacao entity) {
        if (entity.getOperacaoCampo() != null) {
            if (entity.getOperacaoCampo().getCodigo() != null) {
                OperacaoCampo dependency = depdao.find(entity.getOperacaoCampo().getCodigo(), new OperacaoCampo());
                entity.setOperacaoCampo(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(FuncionarioOperacao entity) {
        if (entity.getOperacaoCampo() != null) {
            if (entity.getOperacaoCampo().getCodigo() != null) {
                OperacaoCampo dependency = depdao.find(entity.getOperacaoCampo().getCodigo(), new OperacaoCampo());
                entity.setOperacaoCampo(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new FuncionarioOperacao(), codigo);
    }
}
