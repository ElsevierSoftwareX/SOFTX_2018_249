/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_empresa", uniqueConstraints=@UniqueConstraint(columnNames={"emp_nome", "emp_estado", "emp_cidade", "emp_usucodigo"}, name="uk_empresa"))
public class Empresa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="emp_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="emp_nome", length=100, nullable=false) @NotNull (message="Nome é um campo obrigatório") private String nome;
    @Size(max=3, message ="Maximo 3 carateres") 
    @Column(name="emp_estado", length=3, nullable=true) private String estado; 
    @Size(max=100, message ="Maximo 100 carateres") 
    @Column(name="emp_cidade", length=100, nullable=true) private String cidade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="emp_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_empresa_usuario")) private Usuario usuario;

    public Empresa() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.nome);
        hash = 89 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public boolean hasAssociation(){
        return true;
    }
    
    public EmpresaUsuario getAssociation(){
        EmpresaUsuario entity  = new EmpresaUsuario();
        entity.setUsuario(usuario);
        entity.setEmpresa(this);
        return entity;
    } 
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
