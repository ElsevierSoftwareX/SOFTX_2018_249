/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import edu.utfpr.adfapi.config.StringCharConverter;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_tipooperacao", uniqueConstraints={
    @UniqueConstraint(columnNames={"tip_pt_descricao","tip_usucodigo"}, name="uk_tipooperacao1"),
    @UniqueConstraint(columnNames={"tip_en_descricao","tip_usucodigo"}, name="uk_tipooperacao2"),
    @UniqueConstraint(columnNames={"tip_es_descricao","tip_usucodigo"}, name="uk_tipooperacao3")
})
public class TipoOperacao implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="tip_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="tip_pt_descricao", length=100, nullable=false) @NotNull (message="DescricaoPT é um campo obrigatório") private String descricaoPT;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="tip_en_descricao", length=100, nullable=true) private String descricaoEN; 
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="tip_es_descricao", length=100, nullable=true) private String descricaoES; 
    @Temporal(TemporalType.DATE) @Column (name="tip_datacadastro", nullable=true) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="tip_semente", length=1, nullable=false) @NotNull (message="Semente é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String semente;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="tip_insumo", length=1, nullable=false) @NotNull (message="Insumo é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String insumo;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="tip_maquina", length=1, nullable=false) @NotNull (message="Maquina é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String maquina;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="tip_entrega", length=1, nullable=false) @NotNull (message="Entrega é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String entrega;
    @Size(max=1, message ="Maximo 1 caratere")
    @Column (name="tip_funcionario", length=1, nullable=false) @NotNull (message="Funcionario é um campo obrigatório") 
    @Convert(converter = StringCharConverter.class) private String funcionario;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="tip_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_tipooperacao_usuario"))
    private Usuario usuario;

    public TipoOperacao() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricaoPT() {
        return descricaoPT;
    }

    public void setDescricaoPT(String descricaoPT) {
        this.descricaoPT = descricaoPT;
    }

    public String getDescricaoEN() {
        return descricaoEN;
    }

    public void setDescricaoEN(String descricaoEN) {
        this.descricaoEN = descricaoEN;
    }

    public String getDescricaoES() { 
        return descricaoES;
    }

    public void setDescricaoES(String descricaoES) {
        this.descricaoES = descricaoES;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getSemente() {
        return semente;
    }

    public void setSemente(String semente) {
        this.semente = semente;
    }

    public String getInsumo() {
        return insumo;
    }

    public void setInsumo(String insumo) {
        this.insumo = insumo;
    }

    public String getMaquina() {
        return maquina;
    }

    public void setMaquina(String maquina) {
        this.maquina = maquina;
    }

    public String getEntrega() {
        return entrega;
    }

    public void setEntrega(String entrega) {
        this.entrega = entrega;
    }

    public String getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(String funcionario) {
        this.funcionario = funcionario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 13 * hash + Objects.hashCode(this.codigo);
        hash = 13 * hash + Objects.hashCode(this.descricaoPT);
        hash = 13 * hash + Objects.hashCode(this.usuario);
        return hash;
    }  

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TipoOperacao other = (TipoOperacao) obj;
        if (this.funcionario != other.funcionario) {
            return false;
        }
        if (!Objects.equals(this.descricaoPT, other.descricaoPT)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }
 
    public boolean hasAssociation(){
        return true;
    }
    
    public TipoOperacaoUsuario getAssociation(){
        TipoOperacaoUsuario entity  = new TipoOperacaoUsuario();
        entity.setUsuario(usuario);
        entity.setTipoOperacao(this);
        return entity;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
