/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import java.io.Serializable;

/**
 *
 * @author Jasse
 */
public class FieldSet implements Serializable{
    private String field;
    private String type;

    public FieldSet() {
    }

    public FieldSet(String field, String type) {
        this.field = field;
        this.type = type;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    @Override
    public String toString() {
        return "FieldSet{"  + field + " : " + type +'}';
    }
}
