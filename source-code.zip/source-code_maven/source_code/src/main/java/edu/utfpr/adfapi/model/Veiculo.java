/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_veiculo", uniqueConstraints=@UniqueConstraint(columnNames={"vei_placa", "vei_usucodigo", "vei_descricao"}, name="uk_veiculo"))
public class Veiculo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="vei_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="vei_descricao", length=60, nullable=false) @NotNull (message="Descricao é um campo obrigatório") private String descricao;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="vei_placa", length=60, nullable=false) @NotNull (message="Placa é um campo obrigatório") private String placa;   
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="vei_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_veiculo_usuario")) private Usuario usuario;

    public Veiculo() {
    }

    public Veiculo(String descricao, String placa, Usuario usuario) {
        this.descricao = descricao;
        this.placa = placa;
        this.usuario = usuario;
    }

    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Veiculo other = (Veiculo) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.placa, other.placa)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.descricao);
        hash = 59 * hash + Objects.hashCode(this.placa);
        hash = 59 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public boolean hasAssociation(){
        return true;
    }
    
    public VeiculoUsuario getAssociation(){
        VeiculoUsuario entity  = new VeiculoUsuario();
        entity.setUsuario(usuario);
        entity.setVeiculo(this);
        return entity;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
