
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.Amostra;
import edu.utfpr.adfapi.model.PixelAmostra;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/pixelamostra")
public class PixelAmostraController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<Amostra> depdao;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new PixelAmostra());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new PixelAmostra(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes(MediaType.APPLICATION_JSON)
    public void post(PixelAmostra entity) {
        if (entity.getAmostra() != null) {
            if (entity.getAmostra().getCodigo() != null) {
                Amostra dependency = depdao.find(entity.getAmostra().getCodigo(), new Amostra());
                entity.setAmostra(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes(MediaType.APPLICATION_JSON)
    public void put(PixelAmostra entity) {
        if (entity.getAmostra() != null) {
            if (entity.getAmostra().getCodigo() != null) {
                Amostra dependency = depdao.find(entity.getAmostra().getCodigo(), new Amostra());
                entity.setAmostra(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new PixelAmostra(), codigo);
    }
}
