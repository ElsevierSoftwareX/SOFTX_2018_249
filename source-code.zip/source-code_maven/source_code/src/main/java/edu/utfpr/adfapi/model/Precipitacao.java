/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import edu.utfpr.adfapi.auth.model.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_precipitacao")
public class Precipitacao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="pre_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="pre_obs", length=100) private String observacao;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="pre_tipocoleta", length=100, nullable=false) @NotNull (message="TipoColeta é um campo obrigatório") private String tipoColeta;
    @Column(name="pre_volume", length=100, nullable=false, columnDefinition="float") private float volume;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="pre_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_precipitacao_usuario"))
    private Usuario usuario;
    @Temporal(TemporalType.TIMESTAMP) @Column (name="pre_inicio", nullable=false, columnDefinition = "timestamp with time zone not null") @NotNull (message="Inicio é um campo obrigatório") private Date inicio;
    @Temporal(TemporalType.TIMESTAMP) @Column (name="pre_fim", nullable=false) @NotNull (message="Fim é um campo obrigatório") private Date fim;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn (name="pre_arecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_precipitacao_area")) 
    private Area area;
    
    public Precipitacao() {
    }

    public Precipitacao(String observacao, String tipoColeta, float volume, Area area, Usuario usuario, Date inicio, Date fim) {
        this.observacao = observacao;
        this.tipoColeta = tipoColeta;
        this.volume = volume;
        this.area = area;
        this.usuario = usuario;
        this.inicio = inicio;
        this.fim = fim;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getTipoColeta() {
        return tipoColeta;
    }

    public void setTipoColeta(String tipocoleta) {
        this.tipoColeta = tipocoleta;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFim() {
        return fim;
    }

    public void setFim(Date fim) {
        this.fim = fim;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Precipitacao other = (Precipitacao) obj;
        if (!Objects.equals(this.observacao, other.observacao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.inicio, other.inicio)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + Objects.hashCode(this.observacao);
        hash = 23 * hash + Objects.hashCode(this.tipoColeta);
        hash = 23 * hash + Float.floatToIntBits(this.volume);
        hash = 23 * hash + Objects.hashCode(this.area);
        hash = 23 * hash + Objects.hashCode(this.usuario);
        hash = 23 * hash + Objects.hashCode(this.inicio);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
    
}
