/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Erminio Jasse
 */
@Entity
@Table (name="tb_tiposolo", uniqueConstraints={
    @UniqueConstraint(columnNames="tip_pt_descricao", name="uk_solodescricaoPT"),
    @UniqueConstraint(columnNames="tip_en_descricao", name="uk_solodescricaoEN"),
    @UniqueConstraint(columnNames="tip_es_descricao", name="uk_solodescricaoES")
})
public class Solo implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="tip_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="tip_pt_descricao", length=60) @NotNull (message="Descrição é um campo obrigatório") private String descricaoPT;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="tip_en_descricao", length=60) private String descricaoEN;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="tip_es_descricao", length=60) private String descricaoES;
    @Temporal(TemporalType.DATE) @Column (name="tip_datacadastro", nullable=true) @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="tip_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_tiposolo_usuario"))
    private Usuario usuario;

    public Solo() {
    }

    public Solo(String descricaoPT, String descricaoEN, String descricaoES, Date dataCadastro, Usuario usuario) {
        this.descricaoPT = descricaoPT;
        this.descricaoEN = descricaoEN;
        this.descricaoES = descricaoES;
        this.dataCadastro = dataCadastro;
        this.usuario = usuario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricaoPT() {
        return descricaoPT;
    }

    public void setDescricaoPT(String descricaoPT) {
        this.descricaoPT = descricaoPT;
    }

    public String getDescricaoEN() {
        return descricaoEN;
    }

    public void setDescricaoEN(String descricaoEN) {
        this.descricaoEN = descricaoEN;
    }

    public String getDescricaoES() {
        return descricaoES;
    }

    public void setDescricaoES(String descricaoES) {
        this.descricaoES = descricaoES;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public boolean valida(){
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.descricaoPT);
        hash = 47 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Solo other = (Solo) obj;
        if (!Objects.equals(this.descricaoPT, other.descricaoPT)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }
   
    public boolean isAssociatedUser(){
        return true;
    }
    
    public boolean hasAssociation(){
        return true;
    }
    
    public SoloUsuario getAssociation(Solo solo){
        SoloUsuario entity  = new SoloUsuario();
        entity.setSolo(solo);
        entity.setUsuario(usuario);
        return entity;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
