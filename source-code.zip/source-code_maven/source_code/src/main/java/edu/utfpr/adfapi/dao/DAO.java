/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.dao;

import java.util.List;

/**
 *
 * @author Jasse
 */
public interface DAO<T> {

    public T create(T entity) throws Exception;

    public T update(T entity);

    public T find(Long id, Class<T> type);

    public boolean delete(T entity);

    public List<T> findAll(Class<T> type);
    
    public List<T> findAllByUsuario(Long id, Class<T> type);
}
