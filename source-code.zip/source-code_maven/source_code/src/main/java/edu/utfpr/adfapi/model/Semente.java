/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_semente")
public class Semente implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="sem_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="OperacaoCampo é um campo obrigatório")
    @JoinColumn (name="sem_opecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_semente_operacaocampo"))
    private OperacaoCampo operacaoCampo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Variedade é um campo obrigatório")
    @JoinColumn (name="sem_varcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_semente_varirdade"))
    private Variedade variedade;
    @Column(name="sem_quantidade", nullable=false, columnDefinition="decimal(10, 2)") @NotNull (message="Quantidade é um campo obrigatório") private double quantidade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedQuantidade é um campo obrigatório")
    @JoinColumn (name="sem_unicodigo_quantidade", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_semente_unidademedidaquantidade"))
    private UnidadeMedida uniMedQuantidade;
    @Column(name="sem_espacamento", nullable=false, columnDefinition="decimal(10, 2)") @NotNull (message="Espacamento é um campo obrigatório") private double espacamento;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedEspacamento é um campo obrigatório")
    @JoinColumn (name="sem_unicodigo_espacamento", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_semente_unidademedidaespacamento"))
    private UnidadeMedida uniMedEspacamento;
    @Column(name="sem_custototal", nullable=false, columnDefinition="decimal(15, 2)") @NotNull (message="CustoTotal é um campo obrigatório") private double custoTotal;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedCustoTotal é um campo obrigatório")
    @JoinColumn (name="sem_unicodigo_custototal", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_semente_unidademedidacusto"))
    private UnidadeMedida uniMedCustoTotal;
 

    public Semente() {
    }
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Variedade getVariedade() {
        return variedade;
    }

    public void setVariedade(Variedade variedade) {
        this.variedade = variedade;
    }

    public OperacaoCampo getOperacaoCampo() {
        return operacaoCampo;
    }

    public void setOperacaoCampo(OperacaoCampo operacaocampo) {
        this.operacaoCampo = operacaocampo;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public UnidadeMedida getUniMedQuantidade() {
        return uniMedQuantidade;
    }

    public void setUniMedQuantidade(UnidadeMedida uniMedQuantidade) {
        this.uniMedQuantidade = uniMedQuantidade;
    }

    public double getEspacamento() {
        return espacamento;
    }

    public void setEspacamento(double espacamento) {
        this.espacamento = espacamento;
    }

    public UnidadeMedida getUniMedEspacamento() {
        return uniMedEspacamento;
    }

    public void setUniMedEspacamento(UnidadeMedida uniMedEspacamento) {
        this.uniMedEspacamento = uniMedEspacamento;
    }

    public double getCustoTotal() {
        return custoTotal;
    }

    public void setCustoTotal(double custoTotal) {
        this.custoTotal = custoTotal;
    }

    public UnidadeMedida getUniMedCustoTotal() {
        return uniMedCustoTotal;
    }

    public void setUniMedCustoTotal(UnidadeMedida uniMedCustoTotal) {
        this.uniMedCustoTotal = uniMedCustoTotal;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Semente other = (Semente) obj;
        if (Double.doubleToLongBits(this.custoTotal) != Double.doubleToLongBits(other.custoTotal)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.variedade, other.variedade)) {
            return false;
        }
        if (!Objects.equals(this.operacaoCampo, other.operacaoCampo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.variedade);
        hash = 59 * hash + Objects.hashCode(this.operacaoCampo);
        hash = 59 * hash + (int) (Double.doubleToLongBits(this.custoTotal) ^ (Double.doubleToLongBits(this.custoTotal) >>> 32));
        hash = 59 * hash + Objects.hashCode(this.uniMedCustoTotal);
        return hash;
    }

    public Long getUserCode(){
        return operacaoCampo.getUsuario().getCodigo();
    }  
}
