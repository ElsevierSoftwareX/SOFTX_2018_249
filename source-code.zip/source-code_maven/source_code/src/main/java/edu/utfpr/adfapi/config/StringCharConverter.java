package edu.utfpr.adfapi.config;

/**
 *
 * @author Jasse
 */

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class StringCharConverter implements AttributeConverter<String, Character> {

 @Override
 public Character convertToDatabaseColumn(String string) {
     
     return string.trim().charAt(0);
 }

 @Override
 public String convertToEntityAttribute(Character character) {
     return character.toString();
 }
}
