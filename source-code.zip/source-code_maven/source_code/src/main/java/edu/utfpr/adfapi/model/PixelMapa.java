/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.geolatte.geom.Polygon;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_pixelmapa")
public class PixelMapa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="pix_codigo") private Long codigo;
    @Column (name="pix_valor", columnDefinition="float") private float valor;
    @Column (name="the_geom", columnDefinition = "geometry(POLYGON, 4326)") private Polygon theGeom;
    @Transient @NotNull (message="Geometria é um campo obrigatório") private String geom;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Mapa é um campo obrigatório")
    @JoinColumn (name="pix_mapcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_pixelmapa_mapa")) 
    private Mapa mapa;

    public PixelMapa() {
    }

    public PixelMapa(Mapa mapa, float valor, Polygon the_geom, String geom) {
        this.mapa = mapa;
        this.valor=valor;
        this.theGeom = the_geom;
        this.geom = geom;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Polygon getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (Polygon)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(Polygon geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }

    public Mapa getMapa() {
        return mapa;
    }

    public void setMapa(Mapa mapa) {
        this.mapa=mapa;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PixelMapa other = (PixelMapa) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.mapa, other.mapa)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 17 * hash + Objects.hashCode(this.mapa);
        hash = 17 * hash + Objects.hashCode(this.theGeom);
        return hash;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Long getSuperUserCode(){
        if(mapa!=null){
            if(mapa.getCodigo()!=null) return mapa.getCodigo();
        }
        return null;
    }
    
    public Long getUserCode(){
        return mapa.getUsuario().getCodigo();
    }
}
