/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_logsafra")
public class LogSafra implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="log_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="log_descricao", length=60, nullable=false) @NotNull private String descricao;
    @Temporal(TemporalType.DATE) @Column (name="log_datainicio", nullable=true) private Date inicio;
    @Temporal(TemporalType.DATE) @Column (name="log_datafim", nullable=true) private Date fim;
    @Temporal(TemporalType.DATE) @Column (name="log_datacadastro", nullable=true) private Date dataCadastro;
    @Column (name="log_usucodigo", nullable=true, columnDefinition="Integer") private Integer codigoUsuario;
    @Column (name="log_culcodigo", nullable=true, columnDefinition="Integer") private Integer codigoCultura;
    @Temporal(TemporalType.DATE) @Column (name="log_dataalteracao", nullable=true) private Date dataAlteracao;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="log_tipomodificacao", length=60, nullable=false) @NotNull private String tipoAlteracao;
    @ManyToOne(fetch = FetchType.EAGER)  @NotNull
    @JoinColumn (name=" log_usucodigoalteracao", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_logsafra_usuarioalteracao"))
    private Usuario usuario;

    public LogSafra() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFim() {
        return fim;
    }

    public void setFim(Date fim) {
        this.fim = fim;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Integer getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(Integer codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public Integer getCodigoCultura() {
        return codigoCultura;
    }

    public void setCodigoCultura(Integer codigoCultura) {
        this.codigoCultura = codigoCultura;
    }

    public Date getDataAlteracao() {
        return dataAlteracao;
    }

    public void setDataAlteracao(Date dataAlteracao) {
        this.dataAlteracao = dataAlteracao;
    }

    public String getTipoAlteracao() {
        return tipoAlteracao;
    }

    public void setTipoAlteracao(String tipoAlteracao) {
        this.tipoAlteracao = tipoAlteracao;
    }

    public Usuario getUsuarioAlterou() {
        return usuario;
    }

    public void setUsuarioAlterou(Usuario usuarioAlterou) {
        this.usuario = usuarioAlterou;
    }
   
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
