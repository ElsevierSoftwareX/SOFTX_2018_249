
package edu.utfpr.adfapi.controller.simple;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericSimpleController;
import edu.utfpr.adfapi.dao.GenericSimpleDAO;
import edu.utfpr.adfapi.dao.PermissaoDAO;
import edu.utfpr.adfapi.model.Noticia;
import edu.utfpr.adfapi.model.NoticiaUsuario;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/noticia")
public class NoticiaController {

    @Inject
    private GenericSimpleController<Noticia> controller;
    @Inject
    private GenericSimpleDAO<Noticia> dao;
    @Inject
    private GenericSimpleDAO<NoticiaUsuario> adao;
    @Inject
    private Result result;
    @Inject
    private HttpServletRequest req;
    
    @APIRestrito
    @Get("/pendentes")
    public void getPendentes() {        
        String dispositivo = req.getHeader("Autorizante") == null?"Mobile":"Web";

        List<NoticiaUsuario> list = dao.findPendentesByUser(controller.getUserFromToken(), dispositivo);
        List<Noticia> news = new ArrayList();
        for (NoticiaUsuario nu : list) {
            news.add(nu.getNoticia());
            if (dispositivo.equalsIgnoreCase("Mobile")) {           
                nu.setDataRecebimentoMobile(dateNow());
            } else {
                nu.setDataRecebimentoWeb(dateNow());
            }

            try {  
                adao.update(nu);
            } catch (Exception ex) {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Problemas com NoticiaUsuario. Reporte a equipe de desenvolvimento.")).serialize();
                return;
            }
        }
        if(list.isEmpty()){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        }
        else{
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(news).serialize();
        }     
    }
    
    @APIRestrito
    @Get("/acessadas")
    public void getAcessadas() {       
        String dispositivo = req.getHeader("Autorizante") == null?"Mobile":"Web";
        List<NoticiaUsuario> list = dao.findAcessadasByUser(controller.getUserFromToken(), dispositivo);
        List<Noticia> news = new ArrayList();
        for (NoticiaUsuario nu : list) {
            news.add(nu.getNoticia());
        }
        if(list.isEmpty()){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        }
        else{
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(news).serialize();
        }     
    }
    
    @APIRestrito
    @Get("/naoacessadas")
    public void getNaoAcessadas() {
        String dispositivo = req.getHeader("Autorizante") == null?"Mobile":"Web";
        List<NoticiaUsuario> list = dao.findNaoAcessadasByUser(controller.getUserFromToken(), dispositivo);
        List<Noticia> news = new ArrayList();
        for (NoticiaUsuario nu : list) {
            news.add(nu.getNoticia());
        }
        if(list.isEmpty()){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
        }
        else{
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            result.use(Results.json()).withoutRoot().from(news).serialize();
        } 
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Noticia(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Noticia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Noticia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity);
    }

    @APIRestrito
    @Put("/acesso")
    @Consumes({MediaType.APPLICATION_JSON})
    public void putAcesso(Noticia entity) {
        if (entity != null) {
            if (entity.getDataAcesso() == null) {
                entity.setDataAcesso(dateNow());
            } 
                if (entity.getCodigo() != null) {
                    Noticia noticia = dao.find(entity.getCodigo(), Noticia.class);
                    if (noticia != null) {
                        Map<String, Object> fields = new HashMap();
                        fields.put("usuario", controller.getUserFromToken());
                        fields.put("noticia", entity);
                        NoticiaUsuario existing = adao.findByFields(fields, NoticiaUsuario.class);
                        if (existing != null) {
                            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CONFLICT);
                            if (req.getHeader("Autorizante") == null) {
                                if(existing.getDataAcessoMobile()!=null){
                                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Conflito", "Notícia já acessada antes")).serialize();
                                    return;
                                }
                                existing.setDataAcessoMobile(entity.getDataAcesso());
                            } else {
                                if(existing.getDataAcessoWeb()!=null){
                                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Conflito", "Notícia já acessada antes")).serialize();
                                    return;
                                }
                                existing.setDataAcessoWeb(entity.getDataAcesso());
                            }
                            adao.update(existing);
                            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Data de acesso atualizada")).serialize();
                        } else {
                            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
                        }
                    }
                } else {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Recurso sem código. Forneça o código")).serialize();
                }
        } else {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Notícia é um campo obrigatório")).serialize();
        }
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        Noticia entity = dao.find(codigo, Noticia.class);
        if (!Objects.equals(entity.getUsuario(), controller.getUserFromToken())) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Permissão", "Recurso associado a outro usuário")).serialize();
            return;
        }
        Map<String, Object> fields = new HashMap();
        fields.put("noticia", entity);
        List<NoticiaUsuario> news = adao.findAllByFields(fields, NoticiaUsuario.class);
        try {
            for (NoticiaUsuario nu : news) {
                adao.delete(nu);
            }
            dao.delete(entity);
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Recurso removido")).serialize();
        } catch (Exception ex) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            this.result.use(Results.json()).withoutRoot().from(entity).include("Erro", "A API não pode executar a operação").serialize();
        }
    }
    
    private Date dateNow(){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
            Calendar calendarNow = Calendar.getInstance();
            return dateFormat.parse(dateFormat.format(calendarNow.getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(PermissaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
