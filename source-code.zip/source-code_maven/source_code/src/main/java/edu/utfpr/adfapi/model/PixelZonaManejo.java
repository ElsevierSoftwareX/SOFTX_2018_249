/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.geolatte.geom.Polygon;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_pixelzm")
public class PixelZonaManejo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="pix_codigo") private Long codigo;
    @Column (name="pix_valor", columnDefinition="float") private float valor;
    @Column (name="the_geom", columnDefinition = "geometry(Polygon, 4326)") private Polygon theGeom; 
    @Transient @NotNull (message="Geometria é um campo obrigatório") private String geom;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="ZonaManejo é um campo obrigatório")
    @JoinColumn (name="pix_zoncodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_pixelzonamanejo_zonamanejo")) 
    private ZonaManejo zonaManejo;

    public PixelZonaManejo() {
    }

    public PixelZonaManejo(ZonaManejo zonaManejo, float valor, Polygon the_geom, String geom) {
        this.zonaManejo = zonaManejo;
        this.valor=valor;
        this.theGeom = the_geom;
        this.geom = geom;
    }


    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Polygon getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (Polygon)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(Polygon geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }

    
    public ZonaManejo getZonaManejo() {
        return zonaManejo;
    }

    public void setZonaManejo(ZonaManejo zonaManejo) {
        this.zonaManejo=zonaManejo;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PixelZonaManejo other = (PixelZonaManejo) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.zonaManejo, other.zonaManejo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.zonaManejo);
        hash = 97 * hash + Objects.hashCode(this.theGeom);
        return hash;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Long getSuperUserCode(){
        if(zonaManejo!=null){
            if(zonaManejo.getCodigo()!=null) return zonaManejo.getCodigo();
        }
        return null;
    }
    
    public Long getUserCode(){
        return zonaManejo.getUsuario().getCodigo();
    }
}
