/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.geolatte.geom.GeometryCollection;
import org.geolatte.geom.codec.Wkt;
import org.geolatte.geom.crs.CoordinateReferenceSystems;


/**
 *
 * @author Jasse
 */  
@Entity
@Table (name="tb_geometriaocorrencia", uniqueConstraints=@UniqueConstraint(columnNames={"the_geom", "geo_ococodigo"}, name="uk_geometria"))
public class GeometriaOcorrencia implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="geo_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="geo_obs", length=100, nullable=true) private String observacao;
    @Column(name="geo_valor", columnDefinition="Decimal", nullable = false) @NotNull(message="Valor é um campo obrigatório") private double valor;
    @Column(name="the_geom", columnDefinition="geometry(GeometryCollection, 4326)", nullable=false) private GeometryCollection theGeom;
    @Transient @NotNull(message="Geometria é um campo obrigatório") private String geom;
    @ManyToOne (fetch=FetchType.EAGER) @NotNull (message="Ocorrencia é um campo obrigatório")
    @JoinColumn(name="geo_ococodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_geometria_ocorrencia")) 
    private Ocorrencia ocorrencia;
    
    
    public GeometriaOcorrencia() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Ocorrencia getOcorrencia() {
        return ocorrencia;
    }

    public void setOcorrencia(Ocorrencia ocorrencia) {
        this.ocorrencia = ocorrencia;
    }

    public GeometryCollection getTheGeom() {
        return theGeom;
    }
        
    public void setTheGeom(String geom){
        this.theGeom = (GeometryCollection)Wkt.fromWkt(geom,CoordinateReferenceSystems.WGS84);
        this.geom = geom;
    }
    
    public String getGeom() {
        return geom;
    }
    
    public void setGeom(GeometryCollection geometry) {
        this.theGeom = geometry;
        this.geom = geometry.toString();
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.observacao);
        hash = 37 * hash + (int) (Double.doubleToLongBits(this.valor) ^ (Double.doubleToLongBits(this.valor) >>> 32));
        hash = 37 * hash + Objects.hashCode(this.ocorrencia);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GeometriaOcorrencia other = (GeometriaOcorrencia) obj;
        if (Double.doubleToLongBits(this.valor) != Double.doubleToLongBits(other.valor)) {
            return false;
        }
        if (!Objects.equals(this.observacao, other.observacao)) {
            return false;
        }
        if (!Objects.equals(this.ocorrencia, other.ocorrencia)) {
            return false;
        }
        return true;
    }
  
}
