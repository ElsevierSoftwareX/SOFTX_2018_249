/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.exceptions;

import br.com.caelum.vraptor.AroundCall;
import br.com.caelum.vraptor.Intercepts;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.interceptor.SimpleInterceptorStack;
import br.com.caelum.vraptor.jpa.JPATransactionInterceptor;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.startup.DefaultController;
import javax.inject.Inject;

/**
 *
 * @author Jasse
 */
@Intercepts(before = JPATransactionInterceptor.class)
public class ExceptionInterceptor {
    @Inject
    private Result result;

    @AroundCall
    public void intercept(SimpleInterceptorStack stack) {
        try {
            stack.next();
        } catch (Exception e) {
//            result.use(Results.json()).from(new Exception("Um erro aconteceu, :(")).serialize();
            result.redirectTo(DefaultController.class).error();
        }
    }
}
