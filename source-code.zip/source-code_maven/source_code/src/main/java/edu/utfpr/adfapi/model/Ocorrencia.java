
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_ocorrencia", uniqueConstraints=@UniqueConstraint(columnNames={"oco_descricao", "oco_tipcodigo", "oco_arecodigo"}, name="uk_ocorrencia"))
public class Ocorrencia implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="oco_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column (name="oco_descricao", length=100, nullable=false) @NotNull (message="Descrição é um campo obrigatório") private String descricao;    
    @Size(max=30, message ="Maximo 30 carateres")
    @Column (name="oco_permanente", length=30, nullable=false) @NotNull (message="Permanente é um campo obrigatório") private String permanente;
    @Temporal(TemporalType.DATE) @Column (name="oco_datacadastro", nullable=false) @NotNull (message="DataCadastro é um campo obrigatório") private Date data;  
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="oco_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_ocorrencia_usuario")) private Usuario usuario;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="Área é um campo obrigatório")
    @JoinColumn(name="oco_arecodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_ocorrencia_area")) 
    private Area area;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="TipoOcorrencia é um campo obrigatório")
    @JoinColumn(name="oco_tipcodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_ocorrencia_tipoocorrencia")) 
    private TipoOcorrencia tipoOcorrencia;
    
    public Ocorrencia() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getPermanente() {
        return permanente;
    }

    public void setPermanente(String permanente) {
        this.permanente = permanente;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public TipoOcorrencia getTipoOcorrencia() {
        return tipoOcorrencia;
    }

    public void setTipoOcorrencia(TipoOcorrencia tipoOcorrencia) {
        this.tipoOcorrencia = tipoOcorrencia;
    }
    
    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.descricao);
        hash = 53 * hash + Objects.hashCode(this.permanente);
        hash = 53 * hash + Objects.hashCode(this.tipoOcorrencia);
        hash = 53 * hash + Objects.hashCode(this.area);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ocorrencia other = (Ocorrencia) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.permanente, other.permanente)) {
            return false;
        }
        if (!Objects.equals(this.tipoOcorrencia, other.tipoOcorrencia)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        return true;
    } 
}
