/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.startup;

/**
 *
 * @author Jasse
 */

public class SendEmail {

    /*public boolean send() {//Messaging
        String to = "jasseck@gmail.com";//change accordingly  
        String from = "jasseck@gmail.com";//change accordingly  
        String host = "localhost";//or IP address  

        //Get the session object  
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        Session session = Session.getDefaultInstance(properties);

        //compose the message  
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Teste");
            message.setText("Hello, this is example of sending email  ");

            // Send message  
            Transport.send(message);
            //System.out.println("message sent successfully....");  
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

            return false;
            //mex.printStackTrace();}  
        }
    }*/
}