
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.GradeAmostral;
import edu.utfpr.adfapi.model.PontoAmostral;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/pontoamostral")
public class PontoAmostralController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<GradeAmostral> depdao;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new PontoAmostral());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void getPontoAmostral(Long codigo) {
        controller.get(new PontoAmostral(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(PontoAmostral entity) {
        if (entity.getGradeAmostral() != null) {
            if (entity.getGradeAmostral().getCodigo() != null) {
                GradeAmostral dependency = depdao.find(entity.getGradeAmostral().getCodigo(), new GradeAmostral());
                entity.setGradeAmostral(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(PontoAmostral entity) {
        if (entity.getGradeAmostral() != null) {
            if (entity.getGradeAmostral().getCodigo() != null) {
                GradeAmostral dependency = depdao.find(entity.getGradeAmostral().getCodigo(), new GradeAmostral());
                entity.setGradeAmostral(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new PontoAmostral(), codigo);
    }
}
