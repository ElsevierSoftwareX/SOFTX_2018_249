
package edu.utfpr.adfapi.controller;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.auth.BeanValidator;
import edu.utfpr.adfapi.auth.JWTSigner;
import edu.utfpr.adfapi.auth.model.Permissao;
import edu.utfpr.adfapi.model.Usuario;
import edu.utfpr.adfapi.dao.UsuarioDAO;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author UTFPR
 */

@Controller
@Path("/usuario")
public class UsuarioController {

    @Inject private Result result;
    @Inject private HttpServletRequest req;
    @Inject private UsuarioDAO dao;
    @Inject private JWTSigner jwts;
    @Inject private BeanValidator validator;

   
    @APIRestrito
    @Get("")
    public void get() {
        Usuario entity=dao.find(jwts.getUserId(req.getHeader("Authorization")));         
        result.use(Results.json()).withoutRoot().from(entity).serialize();   
    }
    
    @APIRestrito
    @Get("/teste")
    public void getTeste() {
        List<Permissao> list = jwts.getPermissoes(req.getHeader("Authorization"));
        result.use(Results.json()).withoutRoot().from(list).include("autorizante","autorizado", "recursos").
            exclude("recursos.nomeTabela", "recursos.chavePrimaria", "recursos.nomeIdUsuario").serialize();
    }

    @APIRestrito
    @Get("/fone/{telefone}")
    public void get(String telefone) {
        try {
            Usuario entity = dao.getByTelefone(telefone);
            result.use(Results.http()).setStatusCode(200);
            result.use(Results.json()).withoutRoot().from(entity).exclude("email", "dataCadastro", "dataExpiracao").serialize();

        } catch (Exception e) {
            result.use(Results.http()).setStatusCode(404);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
        }
    }
    
    @Post("")
    @Consumes(MediaType.APPLICATION_JSON)
    public void post(Usuario entity) {
        setDatas(entity);
        if (validator.temErros(entity)){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
            result.use(Results.json()).withoutRoot().from(validator.getErros(entity)).serialize();
        }
        else 
        try {
            entity = dao.create(entity);
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_CREATED);
            result.use(Results.json()).withoutRoot().from(entity).serialize();
        } catch (Exception ex) { //Já existe
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Problemas ao salvar o recurso. Possivelmente já existe")).serialize();
        } 
    }

    
    @Post("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    public void login(String telefone, String password) {
        try {
            Usuario u = dao.getByTelefone(telefone);
            if (u != null) {
                if (u.getSenha().equals(password)) {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                    result.use(Results.json()).withoutRoot().from(jwts.generateToken(u)).serialize();
                } else {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_UNAUTHORIZED);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Autenticação", "Dados de acesso inválidos")).serialize();
                }
            } else {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_UNAUTHORIZED);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Autenticação", "Dados de acesso inválidos")).serialize();
            }
        } catch (Exception e) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Error", "A API não pode processar a operação. Tente mais tarde")).serialize();
        }
    }

    @Get("/senha/{telefone}")
    public void password(String telefone) {
        
        try {
            Usuario u = dao.getByTelefone(telefone);
            if (u != null) {
                if (u.getEmail()!=null) {
                    CommonsMail cm = new CommonsMail();
                    CommonsMail.Send("agriculturaldatabox", "boxdataagricultural", "jasseck@gmail.com", "agriculturaldatabox@gmail.com", "Recuperação de senha -  AGDAPI", "Para recuperar sua senha siga o seguinte link");
                    //cm.enviaEmailSimples(u, "http://www.ppat.com.br/api/doc.html");
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Link de recuperação de senha enviado para seu email")).serialize();
                } else {
                    result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
                    result.use(Results.json()).withoutRoot().from(new SimpleMessage("Email", "Usuário sem email.")).serialize();
                }
            } else {
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_UNAUTHORIZED);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso não encontrado")).serialize();
            }
            
        } catch (Exception e) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro","Ocorreu um erro interno: "+e)).serialize();
        }
    }

    
    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Usuario entity) {
        if(!(Objects.equals(jwts.getUserId(req.getHeader("Authorization")), entity.getCodigo()))){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro","Recurso associado a outro usuario")).serialize();
        }
        else
        if (validator.temErros(entity)){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_BAD_REQUEST);
            result.use(Results.json()).withoutRoot().from(validator.getErros(entity)).serialize();
        }
        else{
            try{
                entity = dao.update(entity);
                result.use(Results.json()).withoutRoot().from(entity).serialize();
            }
            catch(Exception e){
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Problemas ao atualizar o recurso.")).serialize(); 
            }      
        }  
    }

        @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        Usuario entity = dao.find(codigo);
        if(entity==null){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Sem permissão sobre este recurso")).serialize();
        }
        else
        if(!(Objects.equals(jwts.getUserId(req.getHeader("Authorization")), entity.getCodigo()))){
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro","Recurso associado a outro usuario")).serialize();
        }
        else
            try{
                dao.delete(entity);
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Sucesso", "Recurso removido")).serialize();
            }
            catch(Exception e){
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "O recurso deve estar associado a outro no banco")).serialize();
            } 
    }
    
    private Usuario setDatas(Usuario entity){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSZ");
            Calendar calendarNow = Calendar.getInstance();
            Calendar calendarNextYear = Calendar.getInstance();
            Date today= dateFormat.parse(dateFormat.format(calendarNow.getTime()));
            calendarNextYear.add(Calendar.YEAR, 1);
            Date nextYear = dateFormat.parse(dateFormat.format(calendarNextYear.getTime()));
            entity.setDataCadastro(today);
            entity.setDataExpiracao(nextYear);
            
            return entity;
        } catch (ParseException ex) {
            return null;
        }    
    }
}
