/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

/**
 *
 * @author Rodrigo
 */
public class CONFIG {
    public static final String JWTKEY = "ESSA#SENHA%deve&ser@alterada";
    
    public static final String BASE_URL = "http://localhost:8080/SDUM/";
    
    public static final int DEFAULT_SRID = 4326;
    
    public static final boolean isShared(String resource){
        switch(resource.toLowerCase()){
            case "solo":
            case "marca": 
            case "cultura": 
            case "variedade":  
            case "veiculo": 
            case "insumo": 
            case "empresa":       
            case "tipooperacao":
            case "unidademedida":
            case "tipoocorrencia":
            case "categorianoticia":
                return true;
        }
        return false;
    }
}
