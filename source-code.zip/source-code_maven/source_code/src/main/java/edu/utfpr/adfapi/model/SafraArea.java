/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import edu.utfpr.adfapi.auth.model.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_safraarea")
public class SafraArea implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="saf_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Safra é um campo obrigatório")
    @JoinColumn (name="saf_safcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_safraarea_safra"))
    private Safra safra;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="saf_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_safraarea_usuario"))
    private Usuario usuario;    
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Area é um campo obrigatório")
    @JoinColumn (name="saf_arecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_safraarea_area")) 
    private Area area;

    public SafraArea() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Safra getSafra() {
        return safra;
    }

    public void setSafra(Safra safra) {
        this.safra = safra;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SafraArea other = (SafraArea) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        if (!Objects.equals(this.safra, other.safra)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.area);
        hash = 97 * hash + Objects.hashCode(this.safra);
        hash = 97 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public String toString() {
        return "SafraArea{" + "codigo=" + codigo + ", safra=" + safra + ", usuario=" + usuario + ", area=" + area + '}';
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
