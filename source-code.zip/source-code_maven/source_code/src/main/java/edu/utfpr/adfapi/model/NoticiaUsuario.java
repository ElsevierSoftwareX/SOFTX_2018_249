
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_noticiausuario", uniqueConstraints=@UniqueConstraint(columnNames={"not_notcodigo", "not_usucodigo"}, name="uk_noticiausuario"))
public class NoticiaUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="not_codigo") private Long codigo;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_datarecebimentoweb", nullable=true) private Date dataRecebimentoWeb;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_datarecebimentomobile", nullable=true) private Date dataRecebimentoMobile;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_dataacessoweb", nullable=true) private Date dataAcessoWeb;
    @Temporal(TemporalType.TIMESTAMP) 
    @Column (name="not_dataacessomobile", nullable=true) private Date dataAcessoMobile;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Noticia é um campo obrigatório")
    @JoinColumn (name="not_notcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_noticiausuario_noticia")) 
    private Noticia noticia;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório") 
    @JoinColumn (name="not_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_noticiausuario_usuario"))
    private Usuario usuario;

    
    public NoticiaUsuario() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Date getDataRecebimentoWeb() {
        return dataRecebimentoWeb;
    }

    public void setDataRecebimentoWeb(Date dataRecebimentoWeb) {
        this.dataRecebimentoWeb = dataRecebimentoWeb;
    }

    public Date getDataRecebimentoMobile() {
        return dataRecebimentoMobile;
    }

    public void setDataRecebimentoMobile(Date dataRecebimentoMobile) {
        this.dataRecebimentoMobile = dataRecebimentoMobile;
    }

    public Date getDataAcessoWeb() {
        return dataAcessoWeb;
    }

    public void setDataAcessoWeb(Date dataAcessoWeb) {
        this.dataAcessoWeb = dataAcessoWeb;
    }

    public Date getDataAcessoMobile() {
        return dataAcessoMobile;
    }

    public void setDataAcessoMobile(Date dataAcessoMobile) {
        this.dataAcessoMobile = dataAcessoMobile;
    }

    public Noticia getNoticia() {
        return noticia;
    }

    public void setNoticia(Noticia noticia) {
        this.noticia = noticia;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.noticia);
        hash = 29 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final NoticiaUsuario other = (NoticiaUsuario) obj;
        if (!Objects.equals(this.noticia, other.noticia)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }
}
