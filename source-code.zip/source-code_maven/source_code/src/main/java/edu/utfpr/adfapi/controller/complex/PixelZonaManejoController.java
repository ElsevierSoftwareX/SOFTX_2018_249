
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.PixelZonaManejo;
import edu.utfpr.adfapi.model.ZonaManejo;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/pixelzonamanejo")
public class PixelZonaManejoController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<ZonaManejo> depdao;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new PixelZonaManejo());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new PixelZonaManejo(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(PixelZonaManejo entity) {
        if (entity.getZonaManejo() != null) {
            if (entity.getZonaManejo().getCodigo() != null) {
                ZonaManejo dependency = depdao.find(entity.getZonaManejo().getCodigo(), new ZonaManejo());
                entity.setZonaManejo(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(PixelZonaManejo entity) {
        if (entity.getZonaManejo() != null) {
            if (entity.getZonaManejo().getCodigo() != null) {
                ZonaManejo dependency = depdao.find(entity.getZonaManejo().getCodigo(), new ZonaManejo());
                entity.setZonaManejo(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new PixelZonaManejo(), codigo);
    }
}
