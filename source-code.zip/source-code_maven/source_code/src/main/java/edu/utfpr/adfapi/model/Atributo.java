/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_atributo", uniqueConstraints=@UniqueConstraint(columnNames={"atr_pt_descricao", "atr_pt_sigla", "atr_pt_unicodigo"}, name="uk_atributo"))
public class Atributo implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="atr_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="atr_pt_descricao", length=60, nullable = false) 
    @NotNull (message="Descrição é um campo obrigatório") private String descricaoPT;
    @ManyToOne(fetch=FetchType.EAGER) @NotNull (message="UnidadeMedida é um campo obrigatório")
    @JoinColumn (name="atr_pt_unicodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_Atributo_unidademedidapt"))
    private UnidadeMedida unidadeMedidaPT;
    @NotNull (message="Sigla é um campo obrigatório") 
    @Size(max=5, message ="Maximo 5 carateres")
    @Column(name="atr_pt_sigla", length=5, nullable = false) private String siglaPT;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="atr_en_descricao", length=60, nullable = true) private String descricaoEN;
    @ManyToOne(fetch=FetchType.EAGER) 
    @JoinColumn (name="atr_en_unicodigo", nullable=true, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_Atributo_unidademedidaen"))
    private UnidadeMedida unidadeMedidaEN;
    @NotNull @Size(max=5, message ="Maximo 5 carateres")
    @Column(name="atr_en_sigla", length=5, nullable = true) private String siglaEN;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="atr_es_descricao", length=60, nullable = false) private String descricaoES;
    @ManyToOne(fetch=FetchType.EAGER) 
    @JoinColumn (name="atr_es_unicodigo", nullable=true, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_Atributo_unidademedidaes"))
    private UnidadeMedida unidadeMedidaES;
    @NotNull @Size(max=5, message ="Maximo 5 carateres")
    @Column(name="atr_es_sigla", length=5, nullable = true) 
    private String siglaES;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="atr_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_atributo_usuario"))
    private Usuario usuario;

    public Atributo() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricaoPT() {
        return descricaoPT;
    }

    public void setDescricaoPT(String descricaoPT) {
        this.descricaoPT = descricaoPT;
    }

    public UnidadeMedida getUnidadeMedidaPT() {
        return unidadeMedidaPT;
    }

    public void setUnidadeMedidaPT(UnidadeMedida unidadeMedidaPT) {
        this.unidadeMedidaPT = unidadeMedidaPT;
    }

    public String getSiglaPT() {
        return siglaPT;
    }

    public void setSiglaPT(String siglaPT) {
        this.siglaPT = siglaPT;
    }

    public String getDescricaoEN() {
        return descricaoEN;
    }

    public void setDescricaoEN(String descricaoEN) {
        this.descricaoEN = descricaoEN;
    }

    public UnidadeMedida getUnidadeMedidaEN() {
        return unidadeMedidaEN;
    }

    public void setUnidadeMedidaEN(UnidadeMedida unidadeMedidaEN) {
        this.unidadeMedidaEN = unidadeMedidaEN;
    }

    public String getSiglaEN() {
        return siglaEN;
    }

    public void setSiglaEN(String siglaEN) {
        this.siglaEN = siglaEN;
    }

    public String getDescricaoES() {
        return descricaoES;
    }

    public void setDescricaoES(String descricaoES) {
        this.descricaoES = descricaoES;
    }

    public UnidadeMedida getUnidadeMedidaES() {
        return unidadeMedidaES;
    }

    public void setUnidadeMedidaES(UnidadeMedida unidadeMedidaES) {
        this.unidadeMedidaES = unidadeMedidaES;
    }

    public String getSiglaES() {
        return siglaES;
    }

    public void setSiglaES(String siglaES) {
        this.siglaES = siglaES;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Atributo other = (Atributo) obj;
        if (!Objects.equals(this.descricaoPT, other.descricaoPT)) {
            return false;
        }
        if (!Objects.equals(this.descricaoEN, other.descricaoEN)) {
            return false;
        }
        if (!Objects.equals(this.descricaoES, other.descricaoES)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }  

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.descricaoPT);
        hash = 67 * hash + Objects.hashCode(this.unidadeMedidaPT);
        hash = 67 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
