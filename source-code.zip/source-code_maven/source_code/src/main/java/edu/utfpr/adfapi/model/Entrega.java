/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_entrega")
public class Entrega implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="ent_codigo") private Long codigo;    
    @Temporal(TemporalType.TIMESTAMP) @Column (name="ent_data", nullable=false) @NotNull(message="DataEntrega é um campo obrigatório") private Date dataEntrega;
    @Column(name="ent_quantidade", columnDefinition="decimal(10, 2)") private double quantidade;    
    @Column(name="ent_umidade", columnDefinition="decimal(10, 2)") private double umidade;
    @Column(name="ent_quantidadetotaldesconto", columnDefinition="decimal(10, 2)") private double quantidadeDesconto;
    @Column(name="ent_quantidadetotalliquido", columnDefinition="decimal(10, 2)") private double quantidadeLiquido;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ent_motorista", length=100) private String motorista;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="ent_obs", length=100) private String observacao;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="OperacaoCampo é um campo obrigatório")
    @JoinColumn (name="ent_opecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_entrega_operacaocampo"))
    private OperacaoCampo operacaoCampo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Empresa é um campo obrigatório")
    @JoinColumn (name="ent_empcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_entrega_empresa"))
    private Empresa empresa;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Veiculo é um campo obrigatório")
    @JoinColumn (name="ent_veicodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_entrega_veiculo"))
    private Veiculo veiculo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedQuantidade é um campo obrigatório")
    @JoinColumn (name="ent_unicodigo_quantidade", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_entrega_unidademedidaquantidade"))
    private UnidadeMedida uniMedQuantidade;
    

    public Entrega() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public OperacaoCampo getOperacaoCampo() {
        return operacaoCampo;
    }

    public void setOperacaoCampo(OperacaoCampo operacaoCampo) {
        this.operacaoCampo = operacaoCampo;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public UnidadeMedida getUniMedQuantidade() {
        return uniMedQuantidade;
    }

    public void setUniMedQuantidade(UnidadeMedida uniMedQuantidade) {
        this.uniMedQuantidade = uniMedQuantidade;
    }

    public double getUmidade() {
        return umidade;
    }

    public void setUmidade(double umidade) {
        this.umidade = umidade;
    }

    public double getQuantidadeDesconto() {
        return quantidadeDesconto;
    }

    public void setQuantidadeDesconto(double quantidadeDesconto) {
        this.quantidadeDesconto = quantidadeDesconto;
    }

    public double getQuantidadeLiquido() {
        return quantidadeLiquido;
    }

    public void setQuantidadeLiquido(double quantidadeLiquido) {
        this.quantidadeLiquido = quantidadeLiquido;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Entrega other = (Entrega) obj;
        if (!Objects.equals(this.motorista, other.motorista)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.empresa, other.empresa)) {
            return false;
        }
        if (!Objects.equals(this.operacaoCampo, other.operacaoCampo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + Objects.hashCode(this.empresa);
        hash = 83 * hash + Objects.hashCode(this.operacaoCampo);
        hash = 83 * hash + Objects.hashCode(this.veiculo);
        hash = 83 * hash + Objects.hashCode(this.uniMedQuantidade);
        hash = 83 * hash + Objects.hashCode(this.motorista);
        return hash;
    }
}
