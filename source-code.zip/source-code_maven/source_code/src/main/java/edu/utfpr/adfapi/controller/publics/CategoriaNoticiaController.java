
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.CategoriaNoticia;
import edu.utfpr.adfapi.model.CategoriaNoticiaUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/categorianoticia")
public class CategoriaNoticiaController {

    @Inject
    private GenericPublicController<CategoriaNoticia, CategoriaNoticiaUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new CategoriaNoticiaUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new CategoriaNoticia());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new CategoriaNoticiaUsuario(), new CategoriaNoticia(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(CategoriaNoticia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new CategoriaNoticiaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(CategoriaNoticia entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new CategoriaNoticiaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new CategoriaNoticia(), new CategoriaNoticiaUsuario(), codigo);
    }
}
