/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import edu.utfpr.adfapi.auth.model.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_agendaoperacao", uniqueConstraints=@UniqueConstraint(columnNames={"age_descricao","age_tipcodigo", "age_dataprevisaooperacao", "age_safcodigo","age_arecodigo"}, name="uk_agendaoperacao"))
public class AgendaOperacao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name="age_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="age_descricao", length=100, nullable=false) @NotNull (message="Descrição é um campo obrigatório") private String descricao;
    @Temporal(TemporalType.TIMESTAMP) @Column (name="age_datacadastro", nullable=false)  @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @Temporal(TemporalType.DATE) @Column (name="age_dataprevisaooperacao", nullable=true) private Date dataPrevisaoOperacao;
    @Size(max=200, message ="Maximo 200 carateres")
    @Column(name="age_obs", length=200, nullable=true) private String observacao;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn (name="age_tipcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_agendaoperacao_tipooperacao"))
    @NotNull (message="TipoOperação é um campo obrigatório") private TipoOperacao tipoOperacao;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn (name="age_safcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_agendaoperacao_safra"))
    @NotNull (message="Safra é um campo obrigatório") private Safra safra;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn (name="age_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_agendaoperacao_usuario"))
    @NotNull(message="Usuario é um campo obrigatório") private Usuario usuario;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn (name="age_arecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_agendaoperacao_area")) 
    @NotNull (message="Area é um campo obrigatório") private Area area;
    
    
    public AgendaOperacao() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Date getDataPrevisaoOperacao() {
        return dataPrevisaoOperacao;
    }

    public void setDataPrevisaoOperacao(Date dataPrevisaoOperacao) {
        this.dataPrevisaoOperacao = dataPrevisaoOperacao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public TipoOperacao getTipoOperacao() {
        return tipoOperacao;
    }

    public void setTipoOperacao(TipoOperacao tipoOperacao) {
        this.tipoOperacao = tipoOperacao;
    }

    public Safra getSafra() {
        return safra;
    }

    public void setSafra(Safra safra) {
        this.safra = safra;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AgendaOperacao other = (AgendaOperacao) obj;
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.dataCadastro, other.dataCadastro)) {
            return false;
        }
        if (!Objects.equals(this.safra, other.safra)) {
            return false;
        }
        if (!Objects.equals(this.area, other.area)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.descricao);
        hash = 83 * hash + Objects.hashCode(this.dataCadastro);
        hash = 83 * hash + Objects.hashCode(this.safra);
        hash = 83 * hash + Objects.hashCode(this.area);
        hash = 83 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
