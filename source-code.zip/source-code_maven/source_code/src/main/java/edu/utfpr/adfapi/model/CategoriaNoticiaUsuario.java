/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_categorianoticiausuario", uniqueConstraints=@UniqueConstraint(columnNames={"cat_catcodigo", "cat_usucodigo"}, name="uk_categorianoticiausuario"))
public class CategoriaNoticiaUsuario implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cat_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull(message="CategoriaNoticia é um campo obrigatório")
    @JoinColumn (name="cat_catcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_categorianoticiausuario_categoria"))
    private CategoriaNoticia categoriaNoticia;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull(message="Usuario é um campo obrigatório")
    @JoinColumn (name="cat_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_categorianoticiausuario_usuario"))
    private Usuario usuario;

    public CategoriaNoticiaUsuario() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public CategoriaNoticia getCategoriaNoticia() {
        return categoriaNoticia;
    }

    public void setCategoriaNoticia(CategoriaNoticia categoriaNoticia) {
        this.categoriaNoticia = categoriaNoticia;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 41 * hash + Objects.hashCode(this.categoriaNoticia);
        hash = 41 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CategoriaNoticiaUsuario other = (CategoriaNoticiaUsuario) obj;
        if (!Objects.equals(this.categoriaNoticia, other.categoriaNoticia)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    
}
