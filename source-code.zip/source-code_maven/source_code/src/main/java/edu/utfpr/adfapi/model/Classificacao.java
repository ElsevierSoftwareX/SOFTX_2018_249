/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_classificacao", uniqueConstraints=@UniqueConstraint(columnNames={"cla_entcodigo", "cla_atrcodigo", "cla_tipcodigo"}, name="uk_classificacao"))
public class Classificacao implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="cla_codigo") 
    private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Entidade é um campo obrigatório") 
    @JoinColumn (name="cla_entcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_classificacao_entidadeclassificadora")) 
    private Entidade entidade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Atributo é um campo obrigatório")
    @JoinColumn (name="cla_atrcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_classificacao_atributo")) 
    private Atributo atributo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Solo é um campo obrigatório")
    @JoinColumn (name="cla_tipcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_classificacao_tiposolo")) 
    private Solo solo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="cla_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_classificacao_usuario")) 
    private Usuario usuario;

    public Classificacao() {
    }

    public Classificacao(Entidade entidade, Atributo atributo, Solo solo, Usuario usuario) {
        this.entidade = entidade;
        this.atributo = atributo;
        this.solo = solo;
        this.usuario = usuario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Entidade getEntidade() {
        return entidade;
    }

    public void setEntidadeClassificadora(Entidade entidade) {
        this.entidade = entidade;
    }

    public Atributo getAtributo() {
        return atributo;
    }

    public void setAtributo(Atributo atributo) {
        this.atributo = atributo;
    }

    public Solo getSolo() {
        return solo;
    }

    public void setSolo(Solo solo) {
        this.solo = solo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.entidade);
        hash = 89 * hash + Objects.hashCode(this.atributo);
        hash = 89 * hash + Objects.hashCode(this.solo);
        hash = 89 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Classificacao other = (Classificacao) obj;
        if (!Objects.equals(this.entidade, other.entidade)) {
            return false;
        }
        if (!Objects.equals(this.atributo, other.atributo)) {
            return false;
        }
        if (!Objects.equals(this.solo, other.solo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
