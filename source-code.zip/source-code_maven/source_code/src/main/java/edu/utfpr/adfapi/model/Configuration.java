
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_configuration", uniqueConstraints={
    @UniqueConstraint(columnNames="con_campo", name="uk_campo"),
    @UniqueConstraint(columnNames="con_valor", name="uk_valor")
})
public class Configuration implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="con_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 20 carateres")
    @Column(name="con_campo", length=60) @NotNull (message="Campo é um campo obrigatório") private String campo;
    @Size(max=60, message ="Maximo 100 carateres")
    @Column(name="con_valor", length=60) @NotNull (message="Campo é um campo obrigatório") private String valor;
    @Size(max=60, message ="Maximo 20 carateres")
    @Column(name="con_tipodados", length=20) private String tipoDados;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="con_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_config_usuario"))
    private Usuario usuario;

    public Configuration() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getCampo() {
        return campo;
    }

    public void setCampo(String campo) {
        this.campo = campo;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getTipoDados() {
        return tipoDados;
    }

    public void setTipoDados(String tipoDados) {
        this.tipoDados = tipoDados;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
