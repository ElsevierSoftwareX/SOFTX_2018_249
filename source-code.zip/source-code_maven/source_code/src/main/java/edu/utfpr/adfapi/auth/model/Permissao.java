
package edu.utfpr.adfapi.auth.model;

import edu.utfpr.adfapi.model.Usuario;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_permissao", uniqueConstraints=@UniqueConstraint(columnNames={"per_autorizadocodigo", "per_autorizantecodigo", "per_datainicio", "per_dataexpiracao"}, name="uk_permissao"))
public class Permissao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="per_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Autorizado é um campo obrigatório")
    @JoinColumn (name="per_autorizadocodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_permissao_autorizado")) 
    private Usuario autorizado;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuário é um campo obrigatório")
    @JoinColumn (name="per_autorizantecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_permissao_autorizante"))
    private Usuario autorizante;
    @Temporal(TemporalType.DATE) @Column (name="per_datainicio", nullable=false) @NotNull (message="Data inicio é um campo obrigatório") 
    private Date dataInicio;
    @Temporal(TemporalType.DATE) @Column (name="per_dataexpiracao", nullable=true) @NotNull (message="Data expiracao é um campo obrigatório")
    private Date dataExpiracao;
    @Transient private List<Recurso> recursos;
    
    
    public Permissao() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getAutorizado() {
        return autorizado;
    }

    public void setAutorizado(Usuario autorizado) {
        this.autorizado = autorizado;
    }

    public Usuario getAutorizante() {
        return autorizante;
    }

    public void setAutorizante(Usuario autorizante) {
        this.autorizante = autorizante;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataExpiracao() {
        return dataExpiracao;
    }

    public void setDataExpiracao(Date dataExpiracao) {
        this.dataExpiracao = dataExpiracao;
    }

    public List<Recurso> getRecursos() {
        return recursos;
    }

    public void setRecursos(List<Recurso> recursos) {
        this.recursos = recursos;
    }
    
    public void addRecurso(Recurso recurso){
        recursos.add(recurso);
    }
    
    public void removeRecurso(Recurso recurso){
        recursos.remove(recurso);
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.autorizado);
        hash = 41 * hash + Objects.hashCode(this.autorizante);
        hash = 41 * hash + Objects.hashCode(this.dataInicio);
        hash = 41 * hash + Objects.hashCode(this.dataExpiracao);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Permissao other = (Permissao) obj;
        if (!Objects.equals(this.autorizado, other.autorizado)) {
            return false;
        }
        if (!Objects.equals(this.autorizante, other.autorizante)) {
            return false;
        }
        if (!Objects.equals(this.dataInicio, other.dataInicio)) {
            return false;
        }
        if (!Objects.equals(this.dataExpiracao, other.dataExpiracao)) {
            return false;
        }
        return true;
    }    
}
