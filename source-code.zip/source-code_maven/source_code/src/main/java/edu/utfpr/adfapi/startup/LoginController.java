/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.startup;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import edu.utfpr.adfapi.auth.Restrito;
import edu.utfpr.adfapi.auth.UsuarioSessao;
import edu.utfpr.adfapi.dao.UsuarioDAO;
import edu.utfpr.adfapi.model.Usuario;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/")
public class LoginController {
    
    @Inject private Result result; 
    @Inject private UsuarioDAO uDAO;
    @Inject private UsuarioSessao sessao;
     
    @Get("/login")
    public void loginForm(){

    }
    
    //@Get("/index")
    public void index(){

    }
    
    @Get("/")
    public void login(){
        //result.forwardTo(this).loginForm();
        result.redirectTo("/login");
    }
    
    @Post("/")
    public void login(@NotNull @Valid String email, @NotNull @Valid String senha){
        try {
            Usuario u = uDAO.findByEmail(email);
            if(u.getSenha().equals(senha)){
                sessao.setUsuario(u);
                //result.include("sessao",sessao);
                result.redirectTo(DefaultController.class).index();
            }else{
                result.include("erro","Usuário ou senha inválidos").forwardTo(this).loginForm();
            }
        } catch (Exception ex) {
            result.include("erro",ex.getMessage()).forwardTo(this).loginForm();
        }
    }
    
    @Path("/register")
    public void cadastraForm(){
        //result.include("paises", paisDAO.findAll());
    }
    
    
    @Restrito
    @Get("/logout")
    public void logout(){
        //sessao.logoff();
        sessao.setUsuario(null);
        result.forwardTo(this).loginForm();
    }
    
    @Post("/create")
    public void create(){
        Usuario u= new Usuario();
        u.setDataCadastro(new Date(System.currentTimeMillis()));
        u.setDataExpiracao(new Date(System.currentTimeMillis()));
        u.setEmail("jasseck@gmail.com");
        u.setNome("Jasse");
        u.setSenha("senhamesmo");
        u.setTelefone("822517650");
        try {
            uDAO.create(u);
        } catch (Exception ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
}
