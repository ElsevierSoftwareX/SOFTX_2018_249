
package edu.utfpr.adfapi.controller.complex;

import br.com.caelum.vraptor.*;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericComplexController;
import edu.utfpr.adfapi.dao.GenericComplexDAO;
import edu.utfpr.adfapi.model.OperacaoCampo;
import edu.utfpr.adfapi.model.Semente;
import java.util.List;
import java.util.Objects;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/semente")
public class SementeController {

    @Inject
    private GenericComplexController controller;
    @Inject
    private GenericComplexDAO<OperacaoCampo> depdao;
    @Inject
    private GenericComplexDAO<Semente> dao;
    @Inject
    private Result result;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new Semente());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new Semente(), codigo);
    }
    
    @APIRestrito
    @Get("/operacaocampo/{codigo}")
    public void getByField(Long codigo) {
        OperacaoCampo existing = depdao.find(codigo, new OperacaoCampo());
        if (existing == null) {
            this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
            this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Recurso fornecido <OperacaoCampo> não encontrado")).serialize();
        } else {
            if (!(Objects.equals(controller.getUserFromToken(), existing.getUsuario()))) {
                this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("OperacaoCampo", "Recurso fornecido <OperacaoCampo> associado a outro usuário")).serialize();
            } else {
                List<Semente> toSend = dao.findByField(codigo, new Semente(), "sem_opecodigo");
                if (toSend.isEmpty()) {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_NOT_FOUND);
                    this.result.use(Results.json()).withoutRoot().from(new SimpleMessage("2", "Nenhum recurso encontrado")).serialize();
                } else {
                    this.result.use(Results.http()).setStatusCode(HttpServletResponse.SC_OK);
                    this.result.use(Results.json()).withoutRoot().from(toSend).include(controller.fields(new Semente())).serialize();
                }
            }
        }
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Semente entity) {
        if (entity.getOperacaoCampo() != null) {
            if (entity.getOperacaoCampo().getCodigo() != null) {
                OperacaoCampo dependency = depdao.find(entity.getOperacaoCampo().getCodigo(), new OperacaoCampo());
                entity.setOperacaoCampo(dependency);
            }
        }
        controller.post(entity);
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Semente entity) {
        if (entity.getOperacaoCampo() != null) {
            if (entity.getOperacaoCampo().getCodigo() != null) {
                OperacaoCampo dependency = depdao.find(entity.getOperacaoCampo().getCodigo(), new OperacaoCampo());
                entity.setOperacaoCampo(dependency);
            }
        }
        controller.put(entity);
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Semente(), codigo);
    }
}
