/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_insumooperacao")
public class InsumoOperacao implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ins_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Insumo é um campo obrigatório")
    @JoinColumn (name="ins_inscodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumooperacao_insumo"))
    private Insumo insumo;   
    @Column(name="ins_quantidade", nullable=false, columnDefinition="decimal(15, 2)") @NotNull(message="Quantidade é um campo obrigatório") 
    private double quantidade;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedQuantidade é um campo obrigatório")
    @JoinColumn (name="ins_unicodigo_quantidade", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumooperacao_unidademedidaquantidade"))
    private UnidadeMedida uniMedQuantidade;
    @Column(name="ins_custototal", nullable=false, columnDefinition="decimal(15, 2)") @NotNull (message="CustoTotal é um campo obrigatório") 
    private double custoTotal;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UniMedCustoTotal é um campo obrigatório")
    @JoinColumn (name="ins_unicodigo_custototal", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumo_unidademedidacusto"))
    private UnidadeMedida uniMedCustoTotal;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="OperacaoCampo é um campo obrigatório")
    @JoinColumn (name="ins_opecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_insumooperacao_operacaocampo"))
    private OperacaoCampo operacaoCampo;
   

    public InsumoOperacao() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Insumo getInsumo() {
        return insumo;
    }

    public void setInsumo(Insumo insumo) {
        this.insumo = insumo;
    }

    public OperacaoCampo getOperacaoCampo() {
        return operacaoCampo;
    }

    public void setOperacaoCampo(OperacaoCampo operacaoCampo) {
        this.operacaoCampo = operacaoCampo;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public UnidadeMedida getUniMedQuantidade() {
        return uniMedQuantidade;
    }

    public void setUniMedQuantidade(UnidadeMedida uniMedQuantidade) {
        this.uniMedQuantidade = uniMedQuantidade;
    }

    public double getCustoTotal() {
        return custoTotal;
    }

    public void setCustoTotal(double custoTotal) {
        this.custoTotal = custoTotal;
    }

    public UnidadeMedida getUniMedCustoTotal() {
        return uniMedCustoTotal;
    }

    public void setUniMedCustoTotal(UnidadeMedida uniMedCustoTotal) {
        this.uniMedCustoTotal = uniMedCustoTotal;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final InsumoOperacao other = (InsumoOperacao) obj;
        if (Double.doubleToLongBits(this.custoTotal) != Double.doubleToLongBits(other.custoTotal)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.insumo, other.insumo)) {
            return false;
        }
        if (!Objects.equals(this.operacaoCampo, other.operacaoCampo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.insumo);
        hash = 59 * hash + Objects.hashCode(this.operacaoCampo);
        hash = 59 * hash + (int) (Double.doubleToLongBits(this.quantidade) ^ (Double.doubleToLongBits(this.quantidade) >>> 32));
        hash = 59 * hash + Objects.hashCode(this.uniMedQuantidade);
        hash = 59 * hash + (int) (Double.doubleToLongBits(this.custoTotal) ^ (Double.doubleToLongBits(this.custoTotal) >>> 32));
        hash = 59 * hash + Objects.hashCode(this.uniMedCustoTotal);
        return hash;
    }
    
    public Long getUserCode(){
        return operacaoCampo.getCodigo();
    }
     
}
