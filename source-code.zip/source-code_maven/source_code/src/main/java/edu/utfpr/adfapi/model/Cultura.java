/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_cultura", uniqueConstraints={
    @UniqueConstraint(columnNames="cul_pt_descricao", name="uk_cultura_pt"),
    @UniqueConstraint(columnNames="cul_en_descricao", name="uk_cultura_en"),
    @UniqueConstraint(columnNames="cul_es_descricao", name="uk_cultura_es")
})
public class Cultura implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="cul_codigo") private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="cul_pt_descricao", length=60) @NotNull (message="Descricao é um campo obrigatório") private String descricaoPT;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="cul_en_descricao", length=60) private String descricaoEN;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="cul_es_descricao", length=60) private String descricaoES;
    @Temporal(TemporalType.DATE) @Column (name="cul_datacadastro", nullable=true)  @NotNull (message="DataCadastro é um campo obrigatório") private Date dataCadastro;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn(name="cul_usucodigo", columnDefinition="Integer", nullable=false, foreignKey=@ForeignKey(name="fk_cultura_usuario"))
    private Usuario usuario;

    public Cultura() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescricaoPT() {
        return descricaoPT;
    }

    public void setDescricaoPT(String descricaoPT) {
        this.descricaoPT = descricaoPT;
    }

    public String getDescricaoEN() {
        return descricaoEN;
    }

    public void setDescricaoEN(String descricaoEN) {
        this.descricaoEN = descricaoEN;
    }

    public String getDescricaoES() {
        return descricaoES;
    }

    public void setDescricaoES(String descricaoES) {
        this.descricaoES = descricaoES;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cultura other = (Cultura) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        return Objects.equals(this.descricaoPT, other.descricaoPT);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.descricaoPT);
        hash = 79 * hash + Objects.hashCode(this.usuario);
        return hash;
    }

    @Override
    public String toString() {
        return "Cultura{" + "codigo=" + codigo + ", descricao=" + descricaoPT + ", DataCadastro: "+dataCadastro+'}';
    }
    
    public boolean hasAssociation(){
        return true;
    }
    
    public CulturaUsuario getAssociation(){
        CulturaUsuario entity  = new CulturaUsuario();
        entity.setUsuario(usuario);
        entity.setCultura(this);
        return entity;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
