
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_abrangencianoticia", uniqueConstraints=@UniqueConstraint(columnNames={"abr_descricao", "abr_notcodigo"}, name="uk_abrangencianoticia"))
public class AbrangenciaNoticia implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="abr_codigo") private Long codigo;
    @Size(min=2, max=2, message ="DDD são dois carateres numérícos (ex. 45)")
    @Column(name="abr_descricao", length=100, nullable=false) @NotNull (message="DDD é um campo obrigatório") private String DDD;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull(message="Notícia é um campo obrigatório")
    @JoinColumn (name="abr_notcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_abrangencianoticia_noticia"))
    private Noticia noticia;

    public AbrangenciaNoticia() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDDD() {
        return DDD;
    }

    public void setDDD(String DDD) {
        this.DDD = DDD;
    }

    public Noticia getNoticia() {
        return noticia;
    }

    public void setNoticia(Noticia noticia) {
        this.noticia = noticia;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.DDD);
        hash = 17 * hash + Objects.hashCode(this.noticia);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AbrangenciaNoticia other = (AbrangenciaNoticia) obj;
        if (!Objects.equals(this.DDD, other.DDD)) {
            return false;
        }
        if (!Objects.equals(this.noticia, other.noticia)) {
            return false;
        }
        return true;
    }

    
}
