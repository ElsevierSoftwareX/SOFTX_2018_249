/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import edu.utfpr.adfapi.model.Area;
import java.io.Serializable;
import java.util.Iterator;
import javax.ejb.DependsOn;
import javax.swing.JOptionPane;
 
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

/**
 *
 * @author UTFPR
 */

@DependsOn("entityManagerFactory")
public class GeoInterceptor extends EmptyInterceptor{
 
      private static final long serialVersionUID = 1L;
 
      @Override
      public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
             /*System.out.println("onDelete Method is getting called");
             System.out.println("==== DETAILS OF ENTITY ARE ====");
             if(entity instanceof Area){
      
            }*/
      }
 
     @Override
     public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
            //System.out.println("onLoad Method is getting called");
            JOptionPane.showMessageDialog(null, "So para ver se funciona");
 
            //System.out.println("==== DETAILS OF ENTITY ARE ====");
            if(entity instanceof Area){
                JOptionPane.showMessageDialog(null, "So para ver se funciona");
               /*System.out.println("Id of an Entity is :" + id);
               System.out.println("Property Names ");
 
               for(int i=0;i<propertyNames.length;i++)
               {
                  System.out.println(propertyNames[i] );
               }
  
               Book book = (Book) entity;
 
              System.out.println("BOOK STATE is ");
              System.out.println(book);*/
        }
        return true;
     }
 
     @Override
     public boolean onSave(Object entity, Serializable id, Object[] state,
            String[] propertyNames, Type[] types) {
        System.out.println("onsave Method is getting called");
        System.out.println("==== DETAILS OF ENTITY ARE ====");
        if(entity instanceof Area){
            /*System.out.println("Id of an Entity is :" + id);
            System.out.println("Property Names ");
 
            for(int i=0;i<propertyNames.length;i++)
            {
                System.out.println(propertyNames[i] );
 
                if("name".equals(propertyNames[i]))
                {
                    state[i]= "Hibernate Tutorial Updated";
                }
            }
 
            Book book = (Book)entity;
            System.out.println("BOOK STATE is ");
            System.out.println(book);*/
        }
        return true;
    }    
}
