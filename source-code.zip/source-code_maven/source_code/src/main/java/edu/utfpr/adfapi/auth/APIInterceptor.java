
package edu.utfpr.adfapi.auth;

import br.com.caelum.vraptor.Accepts;
import br.com.caelum.vraptor.AroundCall;
import br.com.caelum.vraptor.Intercepts;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.controller.ControllerMethod;
import br.com.caelum.vraptor.interceptor.SimpleInterceptorStack;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.validator.Validator;
import br.com.caelum.vraptor.view.Results;
import edu.utfpr.adfapi.config.CONFIG;
import java.util.regex.Pattern;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jasse
 */
@Intercepts
@RequestScoped
public class APIInterceptor {

    @Inject
    private Result result;
    @Inject
    private HttpServletRequest req;
    @Inject
    private HttpServletResponse resp;
    @Inject
    private JWTSigner jwts;

    public APIInterceptor() {
    }

    private boolean verifyAuthenticationHeader() {
        try {
            if (req.getRequestURI().toLowerCase().contains(("campos/Usuario").toLowerCase()) && req.getMethod().equalsIgnoreCase("post")) {
                return true;
            }
            if (req.getRequestURI().toLowerCase().contains(("login").toLowerCase())) {
                return true;
            }
            Integer.parseInt(jwts.getUserId(req.getHeader("Authorization")).toString());
            jwts.verifyToken(req.getHeader("Authorization"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Accepts
    public boolean accepts(ControllerMethod method) {
        return method.containsAnnotation(APIRestrito.class);
    }

    @AroundCall
    public void filtrar(SimpleInterceptorStack stack) {
        String method = req.getMethod();   
 
        if (!(method.equalsIgnoreCase("Get") || method.equalsIgnoreCase("Post") || method.equalsIgnoreCase("Put") || method.equalsIgnoreCase("Delete"))) {
            resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Metodo nao permitido. Use Post, Get, Put ou Delete")).serialize();
        } else if (!"application/json".equals(req.getContentType()) && !(method.equalsIgnoreCase("Get")) && !(method.equalsIgnoreCase("Delete"))) {
            resp.setStatus(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Formato não suportado")).serialize();
        }
        else  if(req.getRequestURI().toLowerCase().contains(("configuration").toLowerCase())){
            if(req.getHeader("Authorization").equals("CorrespondeUmToken")){
                stack.next();
            }else{
                result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Não possui permissão para este recurso.")).serialize();
            }
        }       
        else if (!this.verifyAuthenticationHeader()) {
            result.use(Results.http()).setStatusCode(HttpServletResponse.SC_UNAUTHORIZED);
            result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Sua autenticação falhou. Verifique suas credenciais")).serialize();
        } else{ 
            String recurso = getRecurso();
            Long user = jwts.getUserId(req.getHeader("Authorization"));
            if(recurso.equalsIgnoreCase("permissao") || recurso.equalsIgnoreCase("info") || CONFIG.isShared(recurso)){// || recurso.equals("TipoOcorrencia")
                stack.next();
            } else
            if (getAutorizante() != null) {
                if (!"".equals(getRecurso())) {
                    if (jwts.isValid(req.getHeader("Authorization"), getRecurso(), req.getMethod(), getAutorizante()) || getAutorizante()==user) {
                        stack.next();
                    } else {
                        result.use(Results.http()).setStatusCode(HttpServletResponse.SC_FORBIDDEN);
                        result.use(Results.json()).withoutRoot().from(new SimpleMessage("Erro", "Não possui permissão para este recurso.")).serialize();
                    }
                }
            }
            else
                stack.next();
            } 
    }

    private Long getAutorizante() {
        if (req.getHeader("Autorizante") == null) {
            return null;
        }
        return Long.parseLong(req.getHeader("Autorizante"));
    }

    private String getRecurso() {
        String[] objetos = req.getRequestURI().split(Pattern.quote("/"));
        try {
            return objetos[2];
        } catch (ArrayIndexOutOfBoundsException e) {
            return "";
        }
    }
}
