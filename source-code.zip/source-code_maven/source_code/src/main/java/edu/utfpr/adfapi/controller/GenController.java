/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.controller;

import java.util.List;

/**
 *
 * @author Jasse
 * @param <T>
 */
public interface GenController<T> {
    
    public void post(T entity);

    public void put(T entity);

    public void get(T entity);
    
    public void get(T entity, Long codigo);

    public void delete(T entity, Long codigo);
}
