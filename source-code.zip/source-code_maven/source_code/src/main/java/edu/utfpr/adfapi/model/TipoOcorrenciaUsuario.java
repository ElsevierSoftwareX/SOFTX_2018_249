/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_tipoocorrenciausuario", uniqueConstraints=@UniqueConstraint(columnNames={"tip_usucodigo", "tip_tipcodigo"}, name="uk_tipoocorrenciausuario"))
public class TipoOcorrenciaUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="tip_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="tip_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_tipoocorrenciausuario_usuario")) 
    private Usuario usuario;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Tipoocorrencia é um campo obrigatório")
    @JoinColumn (name="tip_tipcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_tipoocorrenciausuario_tipoocorrencia")) 
    private TipoOcorrencia tipoOcorrencia;


    public TipoOcorrenciaUsuario() {
    }

    public TipoOcorrenciaUsuario(Usuario usuario, TipoOcorrencia tipoOcorrencia) {
        this.usuario = usuario;
        this.tipoOcorrencia = tipoOcorrencia;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public TipoOcorrencia getTipoOcorrencia() {
        return tipoOcorrencia;
    }

    public void setTipoOcorrencia(TipoOcorrencia tipoOcorrencia) {
        this.tipoOcorrencia = tipoOcorrencia;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TipoOcorrenciaUsuario other = (TipoOcorrenciaUsuario) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.tipoOcorrencia, other.tipoOcorrencia)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.usuario);
        hash = 79 * hash + Objects.hashCode(this.tipoOcorrencia);
        return hash;
    }
    
    public TipoOcorrencia getMainResource() {
        return tipoOcorrencia;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
