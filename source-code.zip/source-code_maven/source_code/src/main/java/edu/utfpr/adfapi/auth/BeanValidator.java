/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.SimpleMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

/**
 *
 * @author Jasse
 * @param <T>
 */
public class BeanValidator<T> {

    @Inject private Validator validator;
 
    public BeanValidator() {
    }

    public List <SimpleMessage> getErros(T entity) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        Set<ConstraintViolation<T>> restricoes = validator.validate(entity);

        List <SimpleMessage> erros=new ArrayList();
        for (ConstraintViolation violation : restricoes) {
            erros.add(new SimpleMessage(entity.getClass().getSimpleName()+"."+violation.getPropertyPath().toString(), violation.getMessage()));
        }
        return erros;
    }

    public boolean temErros(T entity) {
        if(entity==null) return true;
        
        return !this.getErros(entity).isEmpty();
    }       
}
