
package edu.utfpr.adfapi.controller.publics;

import br.com.caelum.vraptor.*;
import edu.utfpr.adfapi.auth.APIRestrito;
import edu.utfpr.adfapi.controller.GenericPublicController;
import edu.utfpr.adfapi.model.Empresa;
import edu.utfpr.adfapi.model.EmpresaUsuario;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Jasse
 */
@Controller
@Path("/empresa")
public class EmpresaController {

    @Inject
    private GenericPublicController<Empresa, EmpresaUsuario> controller;

    @APIRestrito
    @Get("")
    public void get() {
        controller.get(new EmpresaUsuario());
    }

    @APIRestrito
    @Get("/descricao/{value}")
    public void get(String value) {
        controller.get(value, new Empresa());
    }

    @APIRestrito
    @Get("/{codigo}")
    public void get(Long codigo) {
        controller.get(new EmpresaUsuario(), new Empresa(), codigo);
    }

    @APIRestrito
    @Post("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void post(Empresa entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.post(entity, new EmpresaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Put("")
    @Consumes({MediaType.APPLICATION_JSON})
    public void put(Empresa entity) {
        if (entity.getUsuario() == null) {
            entity.setUsuario(controller.getUserFromToken());
        }
        controller.put(entity, new EmpresaUsuario(), entity.getCodigo());
    }

    @APIRestrito
    @Delete("/{codigo}")
    public void delete(Long codigo) {
        controller.delete(new Empresa(), new EmpresaUsuario(), codigo);
    }
}
