/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jasse
 */

@Entity
@Table (name="tb_veiculousuario", uniqueConstraints=@UniqueConstraint(columnNames={"vei_usucodigo", "vei_veicodigo"}, name="uk_veiculousuario"))
public class VeiculoUsuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Column(name="vei_codigo") private Long codigo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Veiculo é um campo obrigatório")
    @JoinColumn (name="vei_veicodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_veiculousuario_veiculo")) private Veiculo veiculo;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Usuario é um campo obrigatório")
    @JoinColumn (name="vei_usucodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_veiculousuario_usuario")) private Usuario usuario;


    public VeiculoUsuario() {
    }

    public VeiculoUsuario(Usuario usuario, Veiculo veiculo) {
        this.usuario = usuario;
        this.veiculo = veiculo;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final VeiculoUsuario other = (VeiculoUsuario) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.veiculo, other.veiculo)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + Objects.hashCode(this.veiculo);
        hash = 73 * hash + Objects.hashCode(this.usuario);
        return hash;
    }
    
    public Veiculo getMainResource() {
        return veiculo;
    }
    
    public Long getUserCode(){
        return usuario.getCodigo();
    }
}
