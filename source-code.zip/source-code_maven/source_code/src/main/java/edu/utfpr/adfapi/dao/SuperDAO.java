
package edu.utfpr.adfapi.dao;

import edu.utfpr.adfapi.model.Usuario;
import edu.utfpr.adfapi.config.Inspector;
import edu.utfpr.adfapi.config.Reflection;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.JoinColumn;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;

/**
 *
 * @author Jasse
 * @param <T>
 */
public class SuperDAO {

    @Inject
    private EntityManager manager;

    public SuperDAO() {
    }

    public <T> T create(T entity) {
        if (entity == null) return null;
        try {
            manager.persist(entity);
        } catch (Exception e) {
            throw e;
        }
        return entity;
    }

    public <T> boolean delete(T entity) throws Exception {
        Inspector insp = new Inspector(entity);
        Method getCodigo = insp.getGetMethod("codigo");
        Query query = manager.createNativeQuery("delete from " + insp.getTableName() + " where " + insp.getPrimaryKey() + " =?");
        
        try {
            query.setParameter(1, getCodigo.invoke(entity, null));
            query.executeUpdate();
            return true;
        } catch (Exception e) {
          throw e;  
        }
    }

    public <T> T find(Long codigo, T entity) {
        
        SessionImplementor si = (SessionImplementor) manager.unwrap(Session.class);
        int count=0;
        try {
            Connection conn = si.getJdbcConnectionAccess().obtainConnection();

            ResultSet rs = conn.prepareStatement((new Inspector(entity)).getQueryByCode(codigo)).executeQuery();
            while (rs.next()) { 
                setSimpleLine((T) entity, rs); 
                count++;
            }
            conn.close();
        } catch (Exception e) {
            Logger.getLogger(SuperDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        if(count==0) return null;
        return entity;
    }

    public <T> List<T> findAllByUser(Long codigo, T entity) {
        ArrayList<T> list = new ArrayList<>();
        SessionImplementor si = (SessionImplementor) manager.unwrap(Session.class);

        try {
            Connection conn = si.getJdbcConnectionAccess().obtainConnection();
            ResultSet rs = conn.prepareStatement((new Inspector(entity)).getQueryAllByUser(codigo)).executeQuery();
            
            while (rs.next()) {
                entity=(T) entity.getClass().newInstance();
                setSimpleLine((T) entity, rs);
                
                list.add(entity);
            }
            conn.close();
        }
        catch (IllegalArgumentException | InstantiationException | SQLException | IllegalAccessException ex) {
            Logger.getLogger(SuperDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }

    public <T> T update(T entity) throws Exception {
        Inspector insp = new Inspector(entity);

        String middle = " ";
        List<Reflection> components = insp.getComponents();
        Reflection refGeom = null, refKey = null;

        for (Reflection reflection : components) {
            if ("geom".equals(reflection.getField().getName())) {
                refGeom = reflection;
            } else if (reflection.getColumn() != null) {
                if (reflection.getColumn().name().contains("_codigo")) {
                    refKey = reflection;
                }
            }
        }
        components.remove(refKey);
        components.remove(refGeom);

        for (Reflection reflection : components) {
            if (reflection.getColumn() != null) {
                middle = middle + reflection.getColumn().name() + " = ?, ";
            } else if (reflection.getjColumn() != null) {
                middle = middle + reflection.getjColumn().name() + " = ?, ";
            }
        }
        middle = middle.substring(0, middle.length() - 2);
        String theQuery = "update " + insp.getTableName() + " set " + middle + " where " + refKey.getColumn().name() + " = ?";
        Query query = manager.createNativeQuery(theQuery);

        for (int i = 0; i < components.size(); i++) {
            Method getMethod = components.get(i).getGetMethod();
            query.setParameter(i + 1, getMethod.invoke(entity, null));
        }
        query.setParameter(components.size() + 1, refKey.getGetMethod().invoke(entity, null));//pega o codigo

        try {
            query.executeUpdate();  
            return entity;
        } catch (Exception e) {
            throw e;
        }
    }

    public <T> void setSimpleLine(T entity, ResultSet rs) {
        Inspector insp = new Inspector(entity);
 
        try {

            for (int i = 0; i < insp.size(); i++) {

                Reflection ref = insp.getReflection(i);
                Method setMethod = ref.getSetMethod();
                String field = ref.getField().getName();
                Column column = ref.getColumn();
                JoinColumn jColumn = ref.getjColumn();

                if (column != null && jColumn == null) {
                    String choice = insp.getFieldType(field);
                    if (field.equalsIgnoreCase("geom")) {
                    } else if (field.equalsIgnoreCase("theGeom")) {
                        Method setTheGeom = insp.getSetMethod("theGeom");
                        setTheGeom.invoke(entity, rs.getString("geom"));
                    } else {
                        setLine(entity, choice, setMethod, rs, column);
                    }
                } else if (column == null && jColumn != null) {
                    setMethod.invoke(entity, find(rs.getLong(jColumn.name()), (T) ref.getField().getType().newInstance()));
                }
            }
        } catch (SQLException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | InstantiationException e) {
            Logger.getLogger(SuperDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public <T> Usuario getDepUser(T entity, Long codigo) {
        Inspector insp = new Inspector(entity);

        try {
            for (int i = 0; i < insp.size(); i++) {
                Reflection ref = insp.getReflection(i);

                Column column = ref.getColumn();
                JoinColumn jColumn = ref.getjColumn();

                if (column == null && jColumn != null) {
                    if (insp.getDependency().equals(ref.getGetMethod())) {
                        Method getUsuario = ref.getField().getType().getMethod("getUsuario", null);
                        return (Usuario) getUsuario.invoke(find(codigo, (T) ref.getField().getType().newInstance()));
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException e) {
            Logger.getLogger(SuperDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return null;
    }

    private <T> void setLine(T entity, String choice, Method setMethod, ResultSet rs, Column column) {

        choice=choice.replace(choice.charAt(0)+"", (choice.charAt(0)+"").toUpperCase());
        try {
            switch (choice) {
                case "Long": {
                    setMethod.invoke(entity, rs.getLong(column.name()));
                    break;
                }
                case "String": {
                    setMethod.invoke(entity, rs.getString(column.name()));
                    break;
                }
                case "Integer": {
                    setMethod.invoke(entity, rs.getInt(column.name()));
                    break;
                }
                case "Date": {
                    setMethod.invoke(entity, rs.getDate(column.name()));
                    break;
                }
                case "char": {
                    setMethod.invoke(entity, (char)rs.getString(column.name()).charAt(0));
                    break;
                }
                case "Double": {
                    setMethod.invoke(entity, rs.getDouble(column.name()));
                    break;
                }
                case "Float": {
                    setMethod.invoke(entity, rs.getFloat(column.name()));
                    break;
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | SQLException | SecurityException ex) {
            Logger.getLogger(SuperDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean hasGeom(Class type) {

        Inspector insp = new Inspector(type); 
        List<Reflection> list = insp.getComponents();
        Field field=null;
        int count=0;
        for(Reflection reflection : list){
            JoinColumn jColumn = reflection.getjColumn();
            if(jColumn != null && (!reflection.getField().getName().equalsIgnoreCase("usuario"))) count++;
        }
        
        if(count==0) return false;
        
        for (Reflection reflection : list) {
            field = reflection.getField();
            Column column = reflection.getColumn();
            JoinColumn jColumn = reflection.getjColumn();
            if (column != null && jColumn == null) {
                if (field.getName().equalsIgnoreCase("theGeom")) {
                    return true;
                }
            }
        }
        return hasGeom(field.getType());
    }
}
