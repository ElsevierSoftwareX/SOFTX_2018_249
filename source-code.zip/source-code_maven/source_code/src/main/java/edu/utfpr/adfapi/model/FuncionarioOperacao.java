/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table (name="tb_funcionariooperacao", uniqueConstraints=@UniqueConstraint(columnNames={"fun_funcao", "fun_opecodigo"}, name="uk_funcionariooperacao"))
public class FuncionarioOperacao implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="fun_codigo") private Long codigo;
    @Size(max=100, message ="Maximo 100 carateres")
    @Column(name="fun_funcao", length=100, nullable=true) private String funcao;
    @Column(name="fun_horastrabalhadas", nullable=false, columnDefinition="decimal(10, 3)") @NotNull (message="HorasTrabalhadas é um campo obrigatório") private double horasTrabalhadas;
    @Column(name="fun_valortotal", nullable=false, columnDefinition="decimal(10, 2)") @NotNull(message="ValorTotal é um campo obrigatório") private double valorTotal;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Funcionario é um campo obrigatório")
    @JoinColumn (name="fun_funcodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_funcionariooperacao_funcionario"))
    private Funcionario funcionario;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="UnidadeMedida é um campo obrigatório")
    @JoinColumn (name="fun_unicodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_funcionariooperacao_unidademedida"))
    private UnidadeMedida unidadeMedida;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="OperacaoCampo é um campo obrigatório")
    @JoinColumn (name="fun_opecodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_funcionariooperacao_operacaocampo"))
    private OperacaoCampo operacaoCampo;

    public FuncionarioOperacao() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public double getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(double horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public UnidadeMedida getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setUnidadeMedida(UnidadeMedida unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    public OperacaoCampo getOperacaoCampo() {
        return operacaoCampo;
    }

    public void setOperacaoCampo(OperacaoCampo operacaoCampo) {
        this.operacaoCampo = operacaoCampo;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FuncionarioOperacao other = (FuncionarioOperacao) obj;
        if (!Objects.equals(this.funcao, other.funcao)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.funcionario, other.funcionario)) {
            return false;
        }
        if (!Objects.equals(this.operacaoCampo, other.operacaoCampo)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.horasTrabalhadas) ^ (Double.doubleToLongBits(this.horasTrabalhadas) >>> 32));
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.valorTotal) ^ (Double.doubleToLongBits(this.valorTotal) >>> 32));
        hash = 89 * hash + Objects.hashCode(this.funcionario);
        hash = 89 * hash + Objects.hashCode(this.operacaoCampo);
        return hash;
    }

    public boolean valida(){
        return this.funcao!=null && !this.funcao.equalsIgnoreCase("");
    }
    
    public Long getUserCode(){
        return operacaoCampo.getCodigo();
    }
}
