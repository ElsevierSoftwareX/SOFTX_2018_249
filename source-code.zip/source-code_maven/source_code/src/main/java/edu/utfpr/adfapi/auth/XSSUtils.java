/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.auth;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml4;

/**
 *
 * @author UTFPR
 */
public class XSSUtils {

    private XSSUtils(){

    }

    public static String stripXSS(String value) {
        return value == null ? value : escapeHtml4(value);
    }
}
