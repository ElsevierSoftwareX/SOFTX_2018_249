/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Jasse
 */
@Entity
@Table(name="tb_classe", uniqueConstraints=@UniqueConstraint(columnNames={"cla_nivel", "cla_clacodigo"}, name="uk_classe"))
public class Classe implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cla_codigo")private Long codigo;
    @Size(max=60, message ="Maximo 60 carateres")
    @Column(name="cla_nivel", length=60, nullable = false) @NotNull (message="Nível é um campo obrigatório") private String nivel;
    @Column(name="cla_valormin", columnDefinition="float") private float valorMinimo;
    @Column(name="cla_valormax", columnDefinition="float") private float valorMaximo;
    @Size(max=30, message ="Maximo 30 carateres")
    @Column(name="cla_cor", length=30) private String cor;
    @ManyToOne(fetch = FetchType.EAGER) @NotNull (message="Classificação é um campo obrigatório") 
    @JoinColumn (name="cla_clacodigo", nullable=false, columnDefinition="Integer", foreignKey=@ForeignKey(name="fk_classe_classificacao")) 
    private Classificacao classificacao;

    public Classe() {
    }

    public Classe(String nivel, float valorMinimo, float valorMaximo, String cor, Classificacao classificacao) {
        this.nivel = nivel;
        this.valorMinimo = valorMinimo;
        this.valorMaximo = valorMaximo;
        this.cor = cor;
        this.classificacao = classificacao;
    }

    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public double getValorMaximo() {
        return valorMaximo;
    }

    public void setValorMaximo(float valorMaximo) {
        this.valorMaximo = valorMaximo;
    }

    public double getValorMinimo() {
        return valorMinimo;
    }

    public void setValorMinimo(float valorMinimo) {
        this.valorMinimo = valorMinimo;
    }

    public Classificacao getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(Classificacao classificacao) {
        this.classificacao = classificacao;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Classe other = (Classe) obj;
        if (!Objects.equals(this.nivel, other.nivel)) {
            return false;
        }
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.classificacao, other.classificacao)) {
            return false;
        }
        return true;
    }  

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.nivel);
        hash = 29 * hash + Objects.hashCode(this.classificacao);
        return hash;
    }
    
    public Long getSuperUserCode(){
        if(classificacao!=null){
            if(classificacao.getCodigo()!=null) return classificacao.getCodigo();
        }
        return null;
    }
    
    public Long getUserCode(){
        return classificacao.getCodigo();
    }
}
