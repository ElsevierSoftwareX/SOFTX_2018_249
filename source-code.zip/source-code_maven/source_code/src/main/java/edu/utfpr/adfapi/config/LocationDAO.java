/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.utfpr.adfapi.config;

/**
 *
 * @author UTFPR
 */

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Point;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.swing.JOptionPane;

/**
 *
 * @author Toaster
 */
@Stateless
public class LocationDAO {

    @PersistenceContext EntityManager em;


    public List<Location> allLocations() {
        try{
                    List<Location> resultList = em.createNamedQuery("Location.findAll", Location.class).getResultList();
        JOptionPane.showMessageDialog(null, "Size: "+ resultList.size());
        return resultList;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "BUGG: "+ e);
        }
        return null;
    }

    public void persistLocation() {
        GeometryFactory gf = new GeometryFactory();    
        Point point = gf.createPoint(new Coordinate(-45.98, -19.57));
        point.setSRID(4326);
        
       
        Location location = new Location();

        location.setLocation(point);
        location.setDescription("Ponto de teste");
        em.persist(location);
    }
}
